const fs = require('fs');
const path = require('path');
const Logger = require('../structures/Logger');

const log = new Logger('CommandHandler');

async function loadCommands(client) {
  const prefixDir = path.join(__dirname, '../commands/prefix');
  const slashDir = path.join(__dirname, '../commands/slash');

  let prefixCount = 0;
  let slashCount = 0;

  if (fs.existsSync(prefixDir)) {
    for (const file of fs.readdirSync(prefixDir).filter(f => f.endsWith('.js'))) {
      try {
        const cmd = require(path.join(prefixDir, file));
        if (cmd.name) {
          client.commands.set(cmd.name, cmd);
          if (cmd.aliases) cmd.aliases.forEach(a => client.commands.set(a, cmd));
          prefixCount++;
        }
      } catch (err) {
        log.error(`Failed to load prefix command: ${file}`, err);
      }
    }
  }

  if (fs.existsSync(slashDir)) {
    for (const file of fs.readdirSync(slashDir).filter(f => f.endsWith('.js'))) {
      try {
        const cmd = require(path.join(slashDir, file));
        if (cmd.data) {
          client.slashCommands.set(cmd.data.name, cmd);
          slashCount++;
        }
      } catch (err) {
        log.error(`Failed to load slash command: ${file}`, err);
      }
    }
  }

  log.success(`Loaded ${prefixCount} prefix commands and ${slashCount} slash commands`);
}

module.exports = { loadCommands };
