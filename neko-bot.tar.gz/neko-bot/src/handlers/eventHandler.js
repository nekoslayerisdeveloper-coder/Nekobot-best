const fs = require('fs');
const path = require('path');
const Logger = require('../structures/Logger');

const log = new Logger('EventHandler');

async function loadEvents(client) {
  const eventsDir = path.join(__dirname, '../events');
  let count = 0;

  for (const file of fs.readdirSync(eventsDir).filter(f => f.endsWith('.js'))) {
    try {
      const event = require(path.join(eventsDir, file));
      if (event.once) {
        client.once(event.name, (...args) => event.execute(client, ...args));
      } else {
        client.on(event.name, (...args) => event.execute(client, ...args));
      }
      count++;
    } catch (err) {
      log.error(`Failed to load event: ${file}`, err);
    }
  }

  log.success(`Loaded ${count} events`);
}

module.exports = { loadEvents };
