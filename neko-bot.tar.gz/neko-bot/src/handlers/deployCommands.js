require('dotenv').config();
const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');

const commands = [];
const slashDir = path.join(__dirname, '../commands/slash');

for (const file of fs.readdirSync(slashDir).filter(f => f.endsWith('.js'))) {
  const cmd = require(path.join(slashDir, file));
  if (cmd.data) commands.push(cmd.data.toJSON());
}

const rest = new REST({ version: '10' }).setToken(process.env.BOT_TOKEN);

(async () => {
  try {
    console.log(`Deploying ${commands.length} slash commands...`);
    await rest.put(
      Routes.applicationCommands(process.env.CLIENT_ID),
      { body: commands }
    );
    console.log('Slash commands deployed globally!');
  } catch (err) {
    console.error('Deploy failed:', err);
  }
})();
