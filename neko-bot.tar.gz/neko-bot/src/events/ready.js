const { ActivityType } = require('discord.js');
const Logger = require('../structures/Logger');
const chalk = require('chalk');

const log = new Logger('Ready');

const STATUSES = (client) => [
  { name: `${client.guilds.cache.size} Servers`, type: ActivityType.Watching },
  { name: 'Owner: NekoSlayer', type: ActivityType.Watching },
  { name: '-inv', type: ActivityType.Watching },
  { name: '/cmds', type: ActivityType.Watching },
  { name: 'Ticket Support', type: ActivityType.Watching },
  { name: 'AI Enabled', type: ActivityType.Watching },
  { name: 'VPS System Enabled', type: ActivityType.Watching },
];

module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    log.success(`Logged in as ${client.user.tag}`);
    console.log(chalk.magenta(`
  ╔══════════════════════════════════════╗
  ║   🐱  NekoBot v2.0 — Premium         ║
  ║   Owner: NekoSlayer                  ║
  ║   Guilds: ${String(client.guilds.cache.size).padEnd(27)}║
  ║   Users:  ${String(client.users.cache.size).padEnd(27)}║
  ╚══════════════════════════════════════╝`));

    let index = 0;
    const rotate = () => {
      const statuses = STATUSES(client);
      const s = statuses[index % statuses.length];
      client.user.setActivity(s.name, { type: s.type });
      index++;
    };
    rotate();
    setInterval(rotate, parseInt(process.env.STATUS_INTERVAL || '10000'));

    // Cache all guild invites
    for (const guild of client.guilds.cache.values()) {
      try {
        const invites = await guild.invites.fetch();
        client.inviteCache.set(guild.id, new Map(invites.map(i => [i.code, i.uses])));
      } catch {}
    }

    log.success('Invite cache populated');
    log.success('NekoBot is fully online!');
  },
};
