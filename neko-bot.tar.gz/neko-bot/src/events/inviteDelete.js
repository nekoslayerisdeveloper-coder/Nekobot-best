module.exports = {
  name: 'inviteDelete',
  async execute(client, invite) {
    const cache = client.inviteCache.get(invite.guild.id);
    if (cache) cache.delete(invite.code);
  },
};
