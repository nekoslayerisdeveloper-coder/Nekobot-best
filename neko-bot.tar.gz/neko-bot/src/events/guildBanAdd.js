const { logEvent } = require('../utils/logSystem');

module.exports = {
  name: 'guildBanAdd',
  async execute(client, ban) {
    await logEvent(client, ban.guild, 'ban', {
      user: ban.user.tag,
      id: ban.user.id,
      reason: ban.reason || 'No reason provided',
    }).catch(() => {});
  },
};
