const Logger = require('../structures/Logger');
const { automodCheck } = require('../utils/automod');
const { addXP } = require('../utils/xpSystem');

const log = new Logger('MessageCreate');

module.exports = {
  name: 'messageCreate',
  async execute(client, message) {
    if (message.author.bot || !message.guild) return;

    // Automod check
    await automodCheck(client, message);

    // XP gain
    await addXP(client, message);

    // Prefix commands
    const prefix = client.prefix;
    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/\s+/);
    const commandName = args.shift().toLowerCase();

    const command = client.commands.get(commandName);
    if (!command) return;

    // Cooldown
    if (!client.cooldowns.has(command.name)) {
      client.cooldowns.set(command.name, new Map());
    }
    const now = Date.now();
    const timestamps = client.cooldowns.get(command.name);
    const cooldown = (command.cooldown || 3) * 1000;
    if (timestamps.has(message.author.id)) {
      const expiry = timestamps.get(message.author.id) + cooldown;
      if (now < expiry) {
        const remaining = ((expiry - now) / 1000).toFixed(1);
        const { cooldown: cooldownEmbed } = require('../utils/embeds');
        return message.reply({ embeds: [cooldownEmbed(remaining)] });
      }
    }
    timestamps.set(message.author.id, now);
    setTimeout(() => timestamps.delete(message.author.id), cooldown);

    try {
      await command.execute(client, message, args);
    } catch (err) {
      log.error(`Command error: ${command.name}`, err);
      message.reply({ content: '❌ An error occurred while running this command.' }).catch(() => {});
    }
  },
};
