const { sendLeaveCard } = require('../utils/welcomeCard');
const { trackLeaveInvite } = require('../utils/inviteTracker');
const { logEvent } = require('../utils/logSystem');
const Logger = require('../structures/Logger');

const log = new Logger('MemberRemove');

module.exports = {
  name: 'guildMemberRemove',
  async execute(client, member) {
    try {
      await trackLeaveInvite(client, member);
      await sendLeaveCard(client, member);
      await logEvent(client, member.guild, 'leave', {
        user: member.user.tag,
        id: member.user.id,
      });
    } catch (err) {
      log.error('MemberRemove error', err);
    }
  },
};
