const { logEvent } = require('../utils/logSystem');

module.exports = {
  name: 'messageUpdate',
  async execute(client, oldMsg, newMsg) {
    if (!oldMsg.guild || oldMsg.author?.bot) return;
    if (oldMsg.content === newMsg.content) return;
    await logEvent(client, oldMsg.guild, 'messageEdit', {
      author: oldMsg.author?.tag || 'Unknown',
      channel: oldMsg.channel?.name || 'Unknown',
      before: oldMsg.content || '[no content]',
      after: newMsg.content || '[no content]',
      url: newMsg.url,
    }).catch(() => {});
  },
};
