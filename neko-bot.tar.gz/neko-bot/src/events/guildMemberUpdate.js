const { logEvent } = require('../utils/logSystem');

module.exports = {
  name: 'guildMemberUpdate',
  async execute(client, oldMember, newMember) {
    const addedRoles = newMember.roles.cache.filter(r => !oldMember.roles.cache.has(r.id));
    const removedRoles = oldMember.roles.cache.filter(r => !newMember.roles.cache.has(r.id));

    if (addedRoles.size > 0 || removedRoles.size > 0) {
      await logEvent(client, newMember.guild, 'roleUpdate', {
        user: newMember.user.tag,
        added: addedRoles.map(r => r.name).join(', ') || 'None',
        removed: removedRoles.map(r => r.name).join(', ') || 'None',
      }).catch(() => {});
    }

    if (oldMember.nickname !== newMember.nickname) {
      await logEvent(client, newMember.guild, 'nicknameUpdate', {
        user: newMember.user.tag,
        before: oldMember.nickname || oldMember.user.username,
        after: newMember.nickname || newMember.user.username,
      }).catch(() => {});
    }
  },
};
