const { sendWelcomeCard } = require('../utils/welcomeCard');
const { trackJoinInvite } = require('../utils/inviteTracker');
const { logEvent } = require('../utils/logSystem');
const Logger = require('../structures/Logger');

const log = new Logger('MemberAdd');

module.exports = {
  name: 'guildMemberAdd',
  async execute(client, member) {
    try {
      // Track which invite was used
      await trackJoinInvite(client, member);

      // Welcome card
      await sendWelcomeCard(client, member);

      // Auto-role
      const welcomeData = client.db.welcome.get(`${member.guild.id}.autorole`);
      if (welcomeData) {
        const roles = Array.isArray(welcomeData) ? welcomeData : [welcomeData];
        for (const roleId of roles) {
          const role = member.guild.roles.cache.get(roleId);
          if (role) await member.roles.add(role).catch(() => {});
        }
      }

      // Verification: restrict if enabled
      const verifyData = client.db.verification.get(`${member.guild.id}`);
      if (verifyData?.enabled && verifyData?.muteRole) {
        const muteRole = member.guild.roles.cache.get(verifyData.muteRole);
        if (muteRole) await member.roles.add(muteRole).catch(() => {});
      }

      // Anti-alt: check account age
      const automod = client.db.automod.get(`${member.guild.id}`);
      if (automod?.antiAlt?.enabled) {
        const minAge = automod.antiAlt.minAge || 7;
        const accountAge = (Date.now() - member.user.createdTimestamp) / 86400000;
        if (accountAge < minAge) {
          await member.kick(`Anti-alt: Account too new (${accountAge.toFixed(1)} days)`).catch(() => {});
          await logEvent(client, member.guild, 'antialt', {
            user: member.user.tag,
            age: accountAge.toFixed(1),
          });
          return;
        }
      }

      await logEvent(client, member.guild, 'join', {
        user: member.user.tag,
        id: member.user.id,
        accountAge: Math.floor((Date.now() - member.user.createdTimestamp) / 86400000),
      });
    } catch (err) {
      log.error('MemberAdd error', err);
    }
  },
};
