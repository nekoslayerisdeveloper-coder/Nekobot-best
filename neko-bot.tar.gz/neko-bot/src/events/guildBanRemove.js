const { logEvent } = require('../utils/logSystem');

module.exports = {
  name: 'guildBanRemove',
  async execute(client, ban) {
    await logEvent(client, ban.guild, 'unban', {
      user: ban.user.tag,
      id: ban.user.id,
    }).catch(() => {});
  },
};
