const { logEvent } = require('../utils/logSystem');

module.exports = {
  name: 'messageDelete',
  async execute(client, message) {
    if (!message.guild || message.author?.bot) return;
    await logEvent(client, message.guild, 'messageDelete', {
      author: message.author?.tag || 'Unknown',
      channel: message.channel?.name || 'Unknown',
      content: message.content || '[no content]',
    }).catch(() => {});
  },
};
