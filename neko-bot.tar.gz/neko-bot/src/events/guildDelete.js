const Logger = require('../structures/Logger');

const log = new Logger('GuildDelete');

module.exports = {
  name: 'guildDelete',
  async execute(client, guild) {
    log.info(`Left guild: ${guild.name} (${guild.id})`);
    client.inviteCache.delete(guild.id);
  },
};
