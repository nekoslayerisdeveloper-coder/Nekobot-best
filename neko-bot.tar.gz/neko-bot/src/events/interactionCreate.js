const Logger = require('../structures/Logger');
const { error } = require('../utils/embeds');

const log = new Logger('InteractionCreate');

module.exports = {
  name: 'interactionCreate',
  async execute(client, interaction) {
    // Slash commands
    if (interaction.isChatInputCommand()) {
      const command = client.slashCommands.get(interaction.commandName);
      if (!command) return;

      // Cooldown
      if (!client.cooldowns.has(command.data.name)) {
        client.cooldowns.set(command.data.name, new Map());
      }
      const now = Date.now();
      const timestamps = client.cooldowns.get(command.data.name);
      const cooldown = (command.cooldown || 3) * 1000;
      if (timestamps.has(interaction.user.id)) {
        const expiry = timestamps.get(interaction.user.id) + cooldown;
        if (now < expiry) {
          const remaining = ((expiry - now) / 1000).toFixed(1);
          return interaction.reply({
            embeds: [error('Cooldown', `Please wait **${remaining}s** before using this command again.`)],
            ephemeral: true,
          });
        }
      }
      timestamps.set(interaction.user.id, now);
      setTimeout(() => timestamps.delete(interaction.user.id), cooldown);

      try {
        await command.execute(client, interaction);
      } catch (err) {
        log.error(`Slash command error: ${interaction.commandName}`, err);
        const reply = { embeds: [error('Error', 'An error occurred. Please try again.')], ephemeral: true };
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(reply).catch(() => {});
        } else {
          await interaction.reply(reply).catch(() => {});
        }
      }
      return;
    }

    // Button interactions
    if (interaction.isButton()) {
      const [action, ...params] = interaction.customId.split(':');

      const handlers = {
        ticket: require('../utils/ticketHandler'),
        apply:  require('../utils/applyHandler'),
        verify: require('../utils/verifyHandler'),
      };

      for (const [key, handler] of Object.entries(handlers)) {
        if (action.startsWith(key)) {
          try {
            await handler.handleButton(client, interaction, action, params);
          } catch (err) {
            log.error(`Button handler error: ${action}`, err);
          }
          return;
        }
      }
    }

    // Select menu interactions
    if (interaction.isStringSelectMenu()) {
      const [action, ...params] = interaction.customId.split(':');

      if (action === 'ticket_type') {
        const handler = require('../utils/ticketHandler');
        await handler.handleSelect(client, interaction, params).catch(err => log.error('Ticket select error', err));
      }
      if (action === 'apply_form') {
        const handler = require('../utils/applyHandler');
        await handler.handleSelect(client, interaction, params).catch(err => log.error('Apply select error', err));
      }
    }

    // Modal submissions
    if (interaction.isModalSubmit()) {
      const [action, ...params] = interaction.customId.split(':');

      if (action === 'apply_modal') {
        const handler = require('../utils/applyHandler');
        await handler.handleModal(client, interaction, params).catch(err => log.error('Apply modal error', err));
      }
      if (action === 'ticket_close_reason') {
        const handler = require('../utils/ticketHandler');
        await handler.handleModal(client, interaction, params).catch(err => log.error('Ticket modal error', err));
      }
      if (action === 'verify_question') {
        const handler = require('../utils/verifyHandler');
        await handler.handleModal(client, interaction, params).catch(err => log.error('Verify modal error', err));
      }
    }
  },
};
