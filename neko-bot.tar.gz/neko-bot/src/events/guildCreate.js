const Logger = require('../structures/Logger');

const log = new Logger('GuildCreate');

module.exports = {
  name: 'guildCreate',
  async execute(client, guild) {
    log.info(`Joined guild: ${guild.name} (${guild.id}) | Members: ${guild.memberCount}`);
    try {
      const invites = await guild.invites.fetch();
      client.inviteCache.set(guild.id, new Map(invites.map(i => [i.code, i.uses])));
    } catch {}
  },
};
