module.exports = {
  name: 'inviteCreate',
  async execute(client, invite) {
    const cache = client.inviteCache.get(invite.guild.id) || new Map();
    cache.set(invite.code, invite.uses);
    client.inviteCache.set(invite.guild.id, cache);
  },
};
