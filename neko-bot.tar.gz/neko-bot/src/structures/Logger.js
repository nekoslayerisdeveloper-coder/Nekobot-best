const chalk = require('chalk');
const fs = require('fs');
const path = require('path');
const moment = require('moment');

const LOG_DIR = path.join(__dirname, '../../logs');
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });

const levels = { debug: 0, info: 1, warn: 2, error: 3 };
const currentLevel = levels[process.env.LOG_LEVEL || 'info'] ?? 1;

function writeToFile(level, message) {
  const date = moment().format('YYYY-MM-DD');
  const logFile = path.join(LOG_DIR, `${date}.log`);
  const line = `[${moment().format('HH:mm:ss')}] [${level.toUpperCase()}] ${message}\n`;
  fs.appendFileSync(logFile, line);
}

function format(level, tag, message) {
  const time = chalk.gray(`[${moment().format('HH:mm:ss')}]`);
  const colors = { debug: chalk.cyan, info: chalk.blue, warn: chalk.yellow, error: chalk.red };
  const color = colors[level] || chalk.white;
  return `${time} ${color(`[${level.toUpperCase()}]`)} ${chalk.magenta(`[${tag}]`)} ${message}`;
}

class Logger {
  constructor(tag = 'NekoBot') {
    this.tag = tag;
  }

  debug(message) {
    if (currentLevel <= levels.debug) {
      console.log(format('debug', this.tag, message));
      writeToFile('debug', `[${this.tag}] ${message}`);
    }
  }

  info(message) {
    if (currentLevel <= levels.info) {
      console.log(format('info', this.tag, message));
      writeToFile('info', `[${this.tag}] ${message}`);
    }
  }

  warn(message) {
    if (currentLevel <= levels.warn) {
      console.warn(format('warn', this.tag, message));
      writeToFile('warn', `[${this.tag}] ${message}`);
    }
  }

  error(message, err) {
    if (currentLevel <= levels.error) {
      console.error(format('error', this.tag, message));
      if (err) console.error(chalk.red(err.stack || err));
      writeToFile('error', `[${this.tag}] ${message}${err ? '\n' + (err.stack || err) : ''}`);
    }
  }

  success(message) {
    const time = chalk.gray(`[${moment().format('HH:mm:ss')}]`);
    console.log(`${time} ${chalk.green('[SUCCESS]')} ${chalk.magenta(`[${this.tag}]`)} ${message}`);
    writeToFile('info', `[${this.tag}] [SUCCESS] ${message}`);
  }
}

module.exports = Logger;
