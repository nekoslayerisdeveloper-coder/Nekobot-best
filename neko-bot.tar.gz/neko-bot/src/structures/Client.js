const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const Database = require('./Database');
const Logger = require('./Logger');

const log = new Logger('Client');

class NekoClient extends Client {
  constructor() {
    super({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildBans,
        GatewayIntentBits.GuildModeration,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages,
      ],
      partials: [
        Partials.Message,
        Partials.Channel,
        Partials.Reaction,
        Partials.GuildMember,
        Partials.User,
      ],
      allowedMentions: { parse: ['users', 'roles'], repliedUser: false },
    });

    this.commands = new Collection();
    this.slashCommands = new Collection();
    this.cooldowns = new Collection();
    this.inviteCache = new Collection();
    this.prefix = process.env.PREFIX || '-';
    this.ownerId = process.env.OWNER_ID;
    this.ownerName = 'NekoSlayer';

    this.db = {
      config:       new Database('config'),
      invites:      new Database('invites'),
      tickets:      new Database('tickets'),
      applications: new Database('applications'),
      levels:       new Database('levels'),
      economy:      new Database('economy'),
      automod:      new Database('automod'),
      warnings:     new Database('warnings'),
      verification: new Database('verification'),
      hosting:      new Database('hosting', { encrypt: true }),
      welcome:      new Database('welcome'),
      logging:      new Database('logging'),
      roles:        new Database('roles'),
      backupMeta:   new Database('backup_meta'),
    };

    log.success('NekoBot Client initialized');
  }

  isOwner(userId) {
    return userId === this.ownerId;
  }

  async loadAll() {
    const { loadCommands } = require('../handlers/commandHandler');
    const { loadEvents } = require('../handlers/eventHandler');
    await loadCommands(this);
    await loadEvents(this);
  }

  backupAll() {
    const results = [];
    for (const [name, db] of Object.entries(this.db)) {
      const p = db.backup();
      if (p) results.push({ name, path: p });
    }
    return results;
  }
}

module.exports = NekoClient;
