const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const Logger = require('./Logger');

const log = new Logger('Database');

const DATA_DIR = path.join(__dirname, '../../data');
const BACKUP_DIR = path.join(__dirname, '../../backups');
const ALGORITHM = 'aes-256-cbc';
const KEY = Buffer.from((process.env.DB_ENCRYPTION_KEY || 'NekoBot_SecretKey_ChangeMe_32chr').padEnd(32, '0').slice(0, 32));

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

class Database {
  constructor(name, { encrypt = false } = {}) {
    this.name = name;
    this.encrypt = encrypt;
    this.filePath = path.join(DATA_DIR, `${name}.json`);
    this.cache = null;
    this.dirty = false;
    this._load();
    this._startAutoSave();
  }

  _encrypt(text) {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv(ALGORITHM, KEY, iv);
    const encrypted = Buffer.concat([cipher.update(text, 'utf8'), cipher.final()]);
    return iv.toString('hex') + ':' + encrypted.toString('hex');
  }

  _decrypt(text) {
    const [ivHex, encHex] = text.split(':');
    const iv = Buffer.from(ivHex, 'hex');
    const enc = Buffer.from(encHex, 'hex');
    const decipher = crypto.createDecipheriv(ALGORITHM, KEY, iv);
    return Buffer.concat([decipher.update(enc), decipher.final()]).toString('utf8');
  }

  _load() {
    try {
      if (!fs.existsSync(this.filePath)) {
        this.cache = {};
        this._save();
        return;
      }
      const raw = fs.readFileSync(this.filePath, 'utf8');
      if (!raw.trim()) { this.cache = {}; return; }
      const text = this.encrypt ? this._decrypt(raw) : raw;
      this.cache = JSON.parse(text);
    } catch (err) {
      log.error(`Failed to load ${this.name}, attempting recovery...`, err);
      this._recover();
    }
  }

  _recover() {
    const backups = fs.readdirSync(BACKUP_DIR)
      .filter(f => f.startsWith(this.name + '_'))
      .sort().reverse();
    for (const backup of backups) {
      try {
        const raw = fs.readFileSync(path.join(BACKUP_DIR, backup), 'utf8');
        const text = this.encrypt ? this._decrypt(raw) : raw;
        this.cache = JSON.parse(text);
        log.warn(`Recovered ${this.name} from backup: ${backup}`);
        this._save();
        return;
      } catch {}
    }
    log.warn(`No valid backup for ${this.name}, starting fresh.`);
    this.cache = {};
    this._save();
  }

  _save() {
    try {
      const text = JSON.stringify(this.cache, null, 2);
      const out = this.encrypt ? this._encrypt(text) : text;
      fs.writeFileSync(this.filePath, out, 'utf8');
      this.dirty = false;
    } catch (err) {
      log.error(`Failed to save ${this.name}`, err);
    }
  }

  _startAutoSave() {
    setInterval(() => {
      if (this.dirty) this._save();
    }, 5000);
  }

  backup() {
    try {
      const ts = new Date().toISOString().replace(/[:.]/g, '-');
      const backupPath = path.join(BACKUP_DIR, `${this.name}_${ts}.json`);
      fs.copyFileSync(this.filePath, backupPath);
      this._pruneBackups();
      return backupPath;
    } catch (err) {
      log.error(`Failed to backup ${this.name}`, err);
    }
  }

  _pruneBackups() {
    const max = parseInt(process.env.MAX_BACKUPS || '24');
    const files = fs.readdirSync(BACKUP_DIR)
      .filter(f => f.startsWith(this.name + '_'))
      .sort();
    while (files.length > max) {
      fs.unlinkSync(path.join(BACKUP_DIR, files.shift()));
    }
  }

  get(key, defaultValue = null) {
    const parts = key.split('.');
    let val = this.cache;
    for (const p of parts) {
      if (val == null || typeof val !== 'object') return defaultValue;
      val = val[p];
    }
    return val !== undefined ? val : defaultValue;
  }

  set(key, value) {
    const parts = key.split('.');
    let obj = this.cache;
    for (let i = 0; i < parts.length - 1; i++) {
      if (obj[parts[i]] === undefined || typeof obj[parts[i]] !== 'object') {
        obj[parts[i]] = {};
      }
      obj = obj[parts[i]];
    }
    obj[parts[parts.length - 1]] = value;
    this.dirty = true;
    return this;
  }

  delete(key) {
    const parts = key.split('.');
    let obj = this.cache;
    for (let i = 0; i < parts.length - 1; i++) {
      if (!obj[parts[i]]) return this;
      obj = obj[parts[i]];
    }
    delete obj[parts[parts.length - 1]];
    this.dirty = true;
    return this;
  }

  has(key) {
    return this.get(key) !== null;
  }

  push(key, value) {
    const arr = this.get(key, []);
    if (!Array.isArray(arr)) throw new Error(`${key} is not an array`);
    arr.push(value);
    return this.set(key, arr);
  }

  pull(key, value) {
    const arr = this.get(key, []);
    return this.set(key, arr.filter(v => JSON.stringify(v) !== JSON.stringify(value)));
  }

  add(key, amount = 1) {
    const current = this.get(key, 0);
    return this.set(key, Number(current) + Number(amount));
  }

  subtract(key, amount = 1) {
    const current = this.get(key, 0);
    return this.set(key, Math.max(0, Number(current) - Number(amount)));
  }

  all() {
    return this.cache;
  }

  clear() {
    this.cache = {};
    this.dirty = true;
    return this;
  }

  save() {
    this._save();
    return this;
  }

  size() {
    return Object.keys(this.cache).length;
  }

  keys() {
    return Object.keys(this.cache);
  }

  entries() {
    return Object.entries(this.cache);
  }

  filter(fn) {
    return Object.entries(this.cache).filter(([k, v]) => fn(v, k));
  }

  sort(fn) {
    return Object.entries(this.cache).sort(([, a], [, b]) => fn(a, b));
  }

  optimize() {
    const before = JSON.stringify(this.cache).length;
    this._save();
    const after = fs.statSync(this.filePath).size;
    log.info(`Optimized ${this.name}: ${before} -> ${after} bytes`);
    return { before, after };
  }
}

module.exports = Database;
