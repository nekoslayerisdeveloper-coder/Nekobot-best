require('dotenv').config();
const NekoClient = require('./structures/Client');
const Logger = require('./structures/Logger');
const cron = require('node-cron');
const path = require('path');
const fs = require('fs');

const log = new Logger('Main');

const client = new NekoClient();

process.on('unhandledRejection', (err) => {
  log.error('Unhandled Promise Rejection', err);
});
process.on('uncaughtException', (err) => {
  log.error('Uncaught Exception', err);
});

(async () => {
  log.info('Starting NekoBot...');

  const dataDir = path.join(__dirname, '../data');
  const backupDir = path.join(__dirname, '../backups');
  const logsDir = path.join(__dirname, '../logs');
  const assetsDir = path.join(__dirname, '../assets');

  for (const dir of [dataDir, backupDir, logsDir, assetsDir]) {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  }

  await client.loadAll();

  const interval = parseInt(process.env.BACKUP_INTERVAL || '60');
  cron.schedule(`*/${interval} * * * *`, () => {
    log.info('Running scheduled backup...');
    const results = client.backupAll();
    log.success(`Backed up ${results.length} databases`);
  });

  cron.schedule('0 0 * * *', () => {
    log.info('Running daily DB optimize...');
    for (const db of Object.values(client.db)) {
      db.optimize();
    }
  });

  await client.login(process.env.BOT_TOKEN);
})();
