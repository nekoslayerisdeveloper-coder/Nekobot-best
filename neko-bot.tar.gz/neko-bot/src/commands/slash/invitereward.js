const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { success, error, info, COLORS } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('invitereward')
    .setDescription('Invite reward role management')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(s => s.setName('add')
      .setDescription('Add an invite role reward')
      .addIntegerOption(o => o.setName('invites').setDescription('Invites needed').setRequired(true).setMinValue(1))
      .addRoleOption(o => o.setName('role').setDescription('Role to give').setRequired(true))
    )
    .addSubcommand(s => s.setName('remove')
      .setDescription('Remove an invite reward')
      .addIntegerOption(o => o.setName('invites').setDescription('Invite count to remove').setRequired(true))
    )
    .addSubcommand(s => s.setName('list').setDescription('View all invite rewards'))
    .addSubcommand(s => s.setName('bonus')
      .setDescription('Give bonus invites to a user')
      .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
      .addIntegerOption(o => o.setName('amount').setDescription('Bonus amount').setRequired(true))
    ),
  cooldown: 5,
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;

    if (sub === 'add') {
      const count = interaction.options.getInteger('invites');
      const role = interaction.options.getRole('role');
      const rewards = client.db.roles.get(`${guild.id}.inviteRewards`) || [];
      if (rewards.some(r => r.count === count)) {
        return interaction.reply({ embeds: [error('Already Exists', `A reward for ${count} invites already exists.`)], ephemeral: true });
      }
      rewards.push({ count, roleId: role.id });
      rewards.sort((a, b) => a.count - b.count);
      client.db.roles.set(`${guild.id}.inviteRewards`, rewards);
      return interaction.reply({ embeds: [success('Reward Added', `${role} will be given at **${count}** invites!`)] });
    }

    if (sub === 'remove') {
      const count = interaction.options.getInteger('invites');
      const rewards = (client.db.roles.get(`${guild.id}.inviteRewards`) || []).filter(r => r.count !== count);
      client.db.roles.set(`${guild.id}.inviteRewards`, rewards);
      return interaction.reply({ embeds: [success('Reward Removed', `Invite reward for ${count} invites removed.`)] });
    }

    if (sub === 'list') {
      const rewards = client.db.roles.get(`${guild.id}.inviteRewards`) || [];
      if (!rewards.length) return interaction.reply({ embeds: [info('No Rewards', 'No invite rewards set. Use `/invitereward add`')] });
      const lines = rewards.map(r => `• **${r.count}** invites → <@&${r.roleId}>`);
      return interaction.reply({
        embeds: [new EmbedBuilder().setColor(COLORS.gold).setTitle('🎁 Invite Rewards').setDescription(lines.join('\n')).setTimestamp()],
      });
    }

    if (sub === 'bonus') {
      const user = interaction.options.getUser('user');
      const amount = interaction.options.getInteger('amount');
      const key = `${guild.id}.${user.id}.bonus`;
      client.db.invites.add(key, amount);
      const total = client.db.invites.get(key) || amount;
      return interaction.reply({ embeds: [success('Bonus Given', `${user} received **+${amount}** bonus invites! (Total bonus: ${total})`)] });
    }
  },
};
