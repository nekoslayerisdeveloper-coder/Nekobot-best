const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { success, error, info, COLORS } = require('../../utils/embeds');

const JOBS = [
  { name: 'Programmer', min: 200, max: 800 },
  { name: 'Designer', min: 150, max: 600 },
  { name: 'Chef', min: 100, max: 400 },
  { name: 'Streamer', min: 50, max: 1500 },
  { name: 'Artist', min: 80, max: 500 },
  { name: 'Driver', min: 100, max: 300 },
  { name: 'Hacker', min: 500, max: 2000 },
  { name: 'Doctor', min: 300, max: 900 },
];

const SHOP_ITEMS = [
  { id: 'vip_badge', name: '⭐ VIP Badge', price: 5000, description: 'Show off your VIP status' },
  { id: 'rainbow_role', name: '🌈 Rainbow Color', price: 10000, description: 'Colorful username' },
  { id: 'custom_title', name: '📛 Custom Title', price: 15000, description: 'Personalized title' },
  { id: 'double_xp', name: '⚡ Double XP (1hr)', price: 3000, description: 'Double XP for 1 hour' },
];

const dailyCooldowns = new Map();
const workCooldowns = new Map();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('economy')
    .setDescription('Economy system')
    .addSubcommand(s => s.setName('balance').setDescription('Check your or someone\'s balance').addUserOption(o => o.setName('user').setDescription('User to check').setRequired(false)))
    .addSubcommand(s => s.setName('daily').setDescription('Claim your daily coins'))
    .addSubcommand(s => s.setName('work').setDescription('Work for coins'))
    .addSubcommand(s => s.setName('transfer').setDescription('Transfer coins').addUserOption(o => o.setName('user').setDescription('Recipient').setRequired(true)).addIntegerOption(o => o.setName('amount').setDescription('Amount to transfer').setRequired(true).setMinValue(1)))
    .addSubcommand(s => s.setName('shop').setDescription('View the shop'))
    .addSubcommand(s => s.setName('buy').setDescription('Buy from the shop').addStringOption(o => o.setName('item').setDescription('Item ID').setRequired(true)))
    .addSubcommand(s => s.setName('inventory').setDescription('View your inventory'))
    .addSubcommand(s => s.setName('leaderboard').setDescription('Economy leaderboard')),
  cooldown: 3,
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;
    const userId = interaction.user.id;

    function getEco(uid = userId) {
      return client.db.economy.get(`${guild.id}.${uid}`) || { balance: 0, bank: 0, inventory: [] };
    }
    function setEco(data, uid = userId) {
      client.db.economy.set(`${guild.id}.${uid}`, data);
    }

    if (sub === 'balance') {
      const target = interaction.options.getUser('user') || interaction.user;
      const eco = getEco(target.id);
      const embed = new EmbedBuilder()
        .setColor(COLORS.gold)
        .setTitle(`💰 Balance — ${target.username}`)
        .setThumbnail(target.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '👜 Wallet', value: `🪙 **${(eco.balance || 0).toLocaleString()}** coins`, inline: true },
          { name: '🏦 Bank', value: `🪙 **${(eco.bank || 0).toLocaleString()}** coins`, inline: true },
          { name: '💎 Net Worth', value: `🪙 **${((eco.balance || 0) + (eco.bank || 0)).toLocaleString()}** coins`, inline: true },
        )
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'daily') {
      const key = `${guild.id}:${userId}`;
      const lastDaily = dailyCooldowns.get(key) || client.db.economy.get(`${guild.id}.${userId}.lastDaily`) || 0;
      const now = Date.now();
      const cd = 24 * 60 * 60 * 1000;
      if (now - lastDaily < cd) {
        const remaining = cd - (now - lastDaily);
        const h = Math.floor(remaining / 3600000);
        const m = Math.floor((remaining % 3600000) / 60000);
        return interaction.reply({ embeds: [error('Daily Claimed', `Next daily in **${h}h ${m}m**`)], ephemeral: true });
      }

      const amount = Math.floor(Math.random() * 500) + 500;
      const eco = getEco();
      eco.balance = (eco.balance || 0) + amount;
      eco.lastDaily = now;
      setEco(eco);
      dailyCooldowns.set(key, now);

      return interaction.reply({ embeds: [success('Daily Claimed! 🎉', `You received 🪙 **${amount}** coins!\n\nBalance: 🪙 **${eco.balance.toLocaleString()}**`)] });
    }

    if (sub === 'work') {
      const key = `${guild.id}:${userId}`;
      const lastWork = workCooldowns.get(key) || client.db.economy.get(`${guild.id}.${userId}.lastWork`) || 0;
      const cd = 30 * 60 * 1000;
      if (Date.now() - lastWork < cd) {
        const remaining = cd - (Date.now() - lastWork);
        const m = Math.floor(remaining / 60000);
        return interaction.reply({ embeds: [error('On Cooldown', `You can work again in **${m} minutes**`)], ephemeral: true });
      }

      const job = JOBS[Math.floor(Math.random() * JOBS.length)];
      const earned = Math.floor(Math.random() * (job.max - job.min + 1)) + job.min;
      const eco = getEco();
      eco.balance = (eco.balance || 0) + earned;
      eco.lastWork = Date.now();
      setEco(eco);
      workCooldowns.set(key, Date.now());

      return interaction.reply({ embeds: [success('Work Done! 💼', `You worked as a **${job.name}** and earned 🪙 **${earned}** coins!\n\nBalance: 🪙 **${eco.balance.toLocaleString()}**`)] });
    }

    if (sub === 'transfer') {
      const target = interaction.options.getUser('user');
      const amount = interaction.options.getInteger('amount');
      if (target.id === userId) return interaction.reply({ embeds: [error('Error', 'You cannot transfer to yourself.')], ephemeral: true });
      if (target.bot) return interaction.reply({ embeds: [error('Error', 'Cannot transfer to a bot.')], ephemeral: true });

      const senderEco = getEco();
      if ((senderEco.balance || 0) < amount) {
        return interaction.reply({ embeds: [error('Insufficient Funds', `You only have 🪙 **${senderEco.balance || 0}** coins.`)], ephemeral: true });
      }

      senderEco.balance -= amount;
      setEco(senderEco);

      const targetEco = getEco(target.id);
      targetEco.balance = (targetEco.balance || 0) + amount;
      setEco(targetEco, target.id);

      return interaction.reply({ embeds: [success('Transfer Complete 💸', `Sent 🪙 **${amount}** coins to ${target}\n\nYour Balance: 🪙 **${senderEco.balance.toLocaleString()}**`)] });
    }

    if (sub === 'shop') {
      const lines = SHOP_ITEMS.map(i => `\`${i.id}\` | **${i.name}** — 🪙 ${i.price.toLocaleString()}\n*${i.description}*`);
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor(COLORS.gold)
          .setTitle('🏪 NekoBot Shop')
          .setDescription(lines.join('\n\n'))
          .setFooter({ text: 'Use /economy buy <item_id> to purchase' })
          .setTimestamp()],
      });
    }

    if (sub === 'buy') {
      const itemId = interaction.options.getString('item');
      const item = SHOP_ITEMS.find(i => i.id === itemId);
      if (!item) return interaction.reply({ embeds: [error('Not Found', `Item \`${itemId}\` not found. Check /economy shop`)], ephemeral: true });

      const eco = getEco();
      if ((eco.balance || 0) < item.price) {
        return interaction.reply({ embeds: [error('Insufficient Funds', `You need 🪙 **${item.price}** but have 🪙 **${eco.balance || 0}**`)], ephemeral: true });
      }

      eco.balance -= item.price;
      eco.inventory = eco.inventory || [];
      eco.inventory.push({ id: item.id, name: item.name, purchasedAt: Date.now() });
      setEco(eco);

      return interaction.reply({ embeds: [success('Purchase Complete! 🛒', `Bought **${item.name}** for 🪙 **${item.price}**!\n\nBalance: 🪙 **${eco.balance.toLocaleString()}**`)] });
    }

    if (sub === 'inventory') {
      const eco = getEco();
      const inv = eco.inventory || [];
      if (!inv.length) return interaction.reply({ embeds: [info('Empty Inventory', 'You have no items. Use `/economy shop` to buy some!')] });
      const lines = inv.map(i => `• **${i.name}** — Purchased <t:${Math.floor(i.purchasedAt / 1000)}:R>`);
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor(COLORS.neko)
          .setTitle(`🎒 Inventory — ${interaction.user.username}`)
          .setDescription(lines.join('\n'))
          .setTimestamp()],
      });
    }

    if (sub === 'leaderboard') {
      const all = client.db.economy.get(`${guild.id}`) || {};
      const sorted = Object.entries(all)
        .filter(([, v]) => v && typeof v === 'object')
        .map(([uid, data]) => ({ userId: uid, net: (data.balance || 0) + (data.bank || 0) }))
        .sort((a, b) => b.net - a.net)
        .slice(0, 15);

      if (!sorted.length) return interaction.reply({ embeds: [info('Empty', 'No economy data yet.')] });

      const medals = ['🥇', '🥈', '🥉'];
      const lines = await Promise.all(sorted.map(async (e, i) => {
        let tag = e.userId;
        try { tag = (await client.users.fetch(e.userId)).tag; } catch {}
        return `${medals[i] || `**#${i + 1}**`} \`${tag}\` — 🪙 **${e.net.toLocaleString()}** coins`;
      }));

      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor(COLORS.gold)
          .setTitle(`💰 Economy Leaderboard — ${guild.name}`)
          .setDescription(lines.join('\n'))
          .setThumbnail(guild.iconURL({ dynamic: true }))
          .setFooter({ text: 'NekoBot Economy • Top 15' })
          .setTimestamp()],
      });
    }
  },
};
