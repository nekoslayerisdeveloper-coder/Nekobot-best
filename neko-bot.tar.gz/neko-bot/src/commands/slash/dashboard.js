const {
  SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle
} = require('discord.js');
const { getLeaderboard: getInviteBoard } = require('../../utils/inviteTracker');
const { COLORS } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dashboard')
    .setDescription('Server dashboard — full overview'),
  cooldown: 10,
  async execute(client, interaction) {
    await interaction.deferReply();
    const guild = interaction.guild;
    await guild.members.fetch().catch(() => {});

    const totalMembers = guild.memberCount;
    const humans = guild.members.cache.filter(m => !m.user.bot).size;
    const bots = guild.members.cache.filter(m => m.user.bot).size;
    const online = guild.members.cache.filter(m => m.presence?.status === 'online').size;

    const allInvites = getInviteBoard(client, guild.id);
    const totalInvites = allInvites.reduce((sum, e) => sum + e.regular, 0);

    const allWarnings = client.db.warnings.get(`${guild.id}`) || {};
    const totalWarns = Object.values(allWarnings).reduce((sum, u) => sum + (Array.isArray(u?.warnings) ? u.warnings.length : 0), 0);

    const tickets = client.db.tickets.get(`${guild.id}.tickets`) || {};
    const openTickets = Object.values(tickets).filter(t => t.status === 'open').length;
    const totalTickets = Object.values(tickets).length;

    const apps = client.db.applications.get(`${guild.id}.apps`) || {};
    const pendingApps = Object.values(apps).filter(a => a.status === 'pending').length;

    const allEco = client.db.economy.get(`${guild.id}`) || {};
    const totalCoins = Object.values(allEco).reduce((sum, u) => sum + ((u?.balance || 0) + (u?.bank || 0)), 0);

    const botUptime = process.uptime();
    const uptimeStr = formatUptime(botUptime);
    const memMB = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(1);

    const embed = new EmbedBuilder()
      .setColor(COLORS.neko)
      .setTitle(`📊 Server Dashboard — ${guild.name}`)
      .setThumbnail(guild.iconURL({ dynamic: true }))
      .setDescription(`**Created:** <t:${Math.floor(guild.createdTimestamp / 1000)}:R> • **Owner:** <@${guild.ownerId}>`)
      .addFields(
        { name: '👥 Members', value: `Total: **${totalMembers}**\nHumans: **${humans}** | Bots: **${bots}**\nOnline: **${online}**`, inline: true },
        { name: '📨 Invites', value: `Total Tracked: **${totalInvites}**\nTop Inviters: **${allInvites.length}**`, inline: true },
        { name: '⚠️ Warnings', value: `Total Warns: **${totalWarns}**`, inline: true },
        { name: '🎫 Tickets', value: `Open: **${openTickets}**\nTotal: **${totalTickets}**`, inline: true },
        { name: '📋 Applications', value: `Pending: **${pendingApps}**\nTotal: **${Object.values(apps).length}**`, inline: true },
        { name: '💰 Economy', value: `Total Coins: **${totalCoins.toLocaleString()}**\nUsers: **${Object.keys(allEco).length}**`, inline: true },
        { name: '🤖 Bot Stats', value: `Uptime: **${uptimeStr}**\nServers: **${client.guilds.cache.size}**\nRAM: **${memMB}MB**\nPing: **${client.ws.ping}ms**`, inline: true },
        { name: '📁 Channels', value: `Total: **${guild.channels.cache.size}**`, inline: true },
        { name: '🎭 Roles', value: `Total: **${guild.roles.cache.size}**`, inline: true },
      )
      .setTimestamp()
      .setFooter({ text: 'NekoBot Dashboard • Real-time stats' });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('_noop').setLabel('📊 Live Stats').setStyle(ButtonStyle.Secondary).setDisabled(true),
      new ButtonBuilder().setCustomId('_noop2').setLabel(`Ping: ${client.ws.ping}ms`).setStyle(ButtonStyle.Primary).setDisabled(true),
      new ButtonBuilder().setCustomId('_noop3').setLabel(`${guild.memberCount} Members`).setStyle(ButtonStyle.Success).setDisabled(true),
    );

    return interaction.editReply({ embeds: [embed], components: [row] });
  },
};

function formatUptime(seconds) {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  return `${d}d ${h}h ${m}m`;
}
