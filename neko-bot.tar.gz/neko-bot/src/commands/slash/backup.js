const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { success, error, info } = require('../../utils/embeds');
const fs = require('fs');
const path = require('path');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('backup')
    .setDescription('Database backup system')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(s => s.setName('create').setDescription('Create a manual backup of all databases'))
    .addSubcommand(s => s.setName('list').setDescription('List available backups'))
    .addSubcommand(s => s.setName('status').setDescription('Backup system status')),
  cooldown: 30,
  async execute(client, interaction) {
    if (!client.isOwner(interaction.user.id) && !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ embeds: [error('No Permission', 'Administrator permission required.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'create') {
      await interaction.deferReply({ ephemeral: true });
      const results = client.backupAll();
      const lines = results.map(r => `✅ \`${r.name}\` — ${path.basename(r.path)}`);
      return interaction.editReply({
        embeds: [success('Backup Created', `**${results.length}** databases backed up!\n\n${lines.join('\n')}`)],
      });
    }

    if (sub === 'list') {
      const backupDir = path.join(__dirname, '../../../backups');
      const files = fs.readdirSync(backupDir).sort().reverse().slice(0, 20);
      if (!files.length) return interaction.reply({ embeds: [info('No Backups', 'No backups found.')], ephemeral: true });

      const lines = files.map(f => {
        const stat = fs.statSync(path.join(backupDir, f));
        const kb = (stat.size / 1024).toFixed(1);
        return `📦 \`${f}\` — ${kb}KB`;
      });

      return interaction.reply({
        embeds: [info(`📦 Backups (${files.length})`, lines.join('\n'))],
        ephemeral: true,
      });
    }

    if (sub === 'status') {
      const backupDir = path.join(__dirname, '../../../backups');
      const files = fs.readdirSync(backupDir);
      const totalSize = files.reduce((sum, f) => sum + fs.statSync(path.join(backupDir, f)).size, 0);
      const intervalMin = parseInt(process.env.BACKUP_INTERVAL || '60');

      return interaction.reply({
        embeds: [info('Backup Status', `**Total Backups:** ${files.length}\n**Total Size:** ${(totalSize / 1024).toFixed(1)}KB\n**Auto Interval:** Every ${intervalMin} minutes\n**Max Kept:** ${process.env.MAX_BACKUPS || 24} per database`)],
        ephemeral: true,
      });
    }
  },
};
