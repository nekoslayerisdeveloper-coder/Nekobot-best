const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { getUserData, getLeaderboard } = require('../../utils/xpSystem');
const { success, error, info, COLORS } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('level')
    .setDescription('Level system')
    .addSubcommand(s => s.setName('rank').setDescription('View your rank or someone else\'s').addUserOption(o => o.setName('user').setDescription('User to check').setRequired(false)))
    .addSubcommand(s => s.setName('leaderboard').setDescription('Show XP leaderboard'))
    .addSubcommand(s => s.setName('setup')
      .setDescription('Enable leveling system')
      .addBooleanOption(o => o.setName('enabled').setDescription('Enable/disable').setRequired(true))
      .addChannelOption(o => o.setName('channel').setDescription('Level up announcement channel').setRequired(false))
      .addIntegerOption(o => o.setName('min_xp').setDescription('Min XP per message').setRequired(false))
      .addIntegerOption(o => o.setName('max_xp').setDescription('Max XP per message').setRequired(false))
    )
    .addSubcommand(s => s.setName('addrole')
      .setDescription('Add a level role reward')
      .addIntegerOption(o => o.setName('level').setDescription('Level required').setRequired(true))
      .addRoleOption(o => o.setName('role').setDescription('Role to give').setRequired(true))
    )
    .addSubcommand(s => s.setName('removerole')
      .setDescription('Remove a level role reward')
      .addIntegerOption(o => o.setName('level').setDescription('Level to remove').setRequired(true))
    )
    .addSubcommand(s => s.setName('setxp')
      .setDescription('Set a user\'s XP')
      .addUserOption(o => o.setName('user').setDescription('Target user').setRequired(true))
      .addIntegerOption(o => o.setName('amount').setDescription('XP amount').setRequired(true))
    ),
  cooldown: 5,
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;

    if (sub === 'rank') {
      const target = interaction.options.getUser('user') || interaction.user;
      const data = getUserData(client, guild.id, target.id);
      const allUsers = getLeaderboard(client, guild.id);
      const rank = allUsers.findIndex(u => u.userId === target.id) + 1;

      const bar = createProgressBar(data.xpProgress, data.xpNeeded);
      const embed = new EmbedBuilder()
        .setColor(COLORS.neko)
        .setTitle(`⭐ Rank Card — ${target.username}`)
        .setThumbnail(target.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '🏆 Rank', value: `#${rank || 'Unranked'}`, inline: true },
          { name: '📊 Level', value: `${data.level}`, inline: true },
          { name: '✨ Total XP', value: `${data.xp.toLocaleString()}`, inline: true },
          { name: '📈 Progress', value: `${bar}\n${data.xpProgress} / ${data.xpNeeded} XP`, inline: false },
        )
        .setFooter({ text: `${guild.name} • NekoBot Levels` })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'leaderboard') {
      const board = getLeaderboard(client, guild.id);
      if (!board.length) return interaction.reply({ embeds: [info('Empty', 'No XP data yet. Start chatting!')] });

      const medals = ['🥇', '🥈', '🥉'];
      const lines = await Promise.all(board.slice(0, 15).map(async (entry, i) => {
        let tag = entry.userId;
        try { tag = (await client.users.fetch(entry.userId)).tag; } catch {}
        return `${medals[i] || `**#${i + 1}**`} \`${tag}\` — Level **${entry.level}** | **${entry.xp.toLocaleString()}** XP`;
      }));

      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor(COLORS.gold)
          .setTitle(`🏆 XP Leaderboard — ${guild.name}`)
          .setDescription(lines.join('\n'))
          .setThumbnail(guild.iconURL({ dynamic: true }))
          .setFooter({ text: 'NekoBot Levels • Top 15' })
          .setTimestamp()],
      });
    }

    if (sub === 'setup') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [error('No Permission', 'Need Manage Server.')], ephemeral: true });
      }
      const enabled = interaction.options.getBoolean('enabled');
      const channel = interaction.options.getChannel('channel');
      const minXP = interaction.options.getInteger('min_xp') || 15;
      const maxXP = interaction.options.getInteger('max_xp') || 25;

      client.db.config.set(`${guild.id}.levels`, { enabled, channel: channel?.id || null, minXP, maxXP, cooldown: 60 });
      return interaction.reply({ embeds: [success('Level System', `Leveling ${enabled ? 'enabled' : 'disabled'}. XP: ${minXP}-${maxXP} per message. Announce: ${channel || 'same channel'}`)] });
    }

    if (sub === 'addrole') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [error('No Permission', 'Need Manage Server.')], ephemeral: true });
      }
      const level = interaction.options.getInteger('level');
      const role = interaction.options.getRole('role');
      const rewards = client.db.roles.get(`${guild.id}.levelRewards`) || [];
      rewards.push({ level, roleId: role.id });
      rewards.sort((a, b) => a.level - b.level);
      client.db.roles.set(`${guild.id}.levelRewards`, rewards);
      return interaction.reply({ embeds: [success('Role Reward Added', `${role} will be given at Level **${level}**`)] });
    }

    if (sub === 'removerole') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [error('No Permission', 'Need Manage Server.')], ephemeral: true });
      }
      const level = interaction.options.getInteger('level');
      const rewards = (client.db.roles.get(`${guild.id}.levelRewards`) || []).filter(r => r.level !== level);
      client.db.roles.set(`${guild.id}.levelRewards`, rewards);
      return interaction.reply({ embeds: [success('Role Reward Removed', `Reward for Level ${level} removed.`)] });
    }

    if (sub === 'setxp') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [error('No Permission', 'Need Manage Server.')], ephemeral: true });
      }
      const user = interaction.options.getUser('user');
      const amount = interaction.options.getInteger('amount');
      client.db.levels.set(`${guild.id}.${user.id}.xp`, amount);
      return interaction.reply({ embeds: [success('XP Set', `${user.tag}'s XP set to **${amount}**`)] });
    }
  },
};

function createProgressBar(current, total, length = 20) {
  const filled = Math.round((current / total) * length);
  const empty = length - filled;
  return '█'.repeat(Math.max(0, filled)) + '░'.repeat(Math.max(0, empty)) + ` ${Math.round((current / total) * 100)}%`;
}
