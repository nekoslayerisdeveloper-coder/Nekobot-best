const {
  SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  PermissionFlagsBits
} = require('discord.js');
const { success, error, info, COLORS } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('verify')
    .setDescription('Verification system')
    .addSubcommand(s => s.setName('setup')
      .setDescription('Setup verification system')
      .addStringOption(o => o.setName('method').setDescription('Verification method').setRequired(true)
        .addChoices(
          { name: 'Button Click', value: 'button' },
          { name: 'Captcha Math', value: 'captcha' },
          { name: 'Question Answer', value: 'question' },
        ))
      .addRoleOption(o => o.setName('verified_role').setDescription('Role given after verification').setRequired(true))
      .addRoleOption(o => o.setName('unverified_role').setDescription('Role removed after verification').setRequired(false))
      .addStringOption(o => o.setName('question').setDescription('Custom question (for question method)').setRequired(false))
      .addStringOption(o => o.setName('answer').setDescription('Answer to the question').setRequired(false))
    )
    .addSubcommand(s => s.setName('panel').setDescription('Send the verification panel').addChannelOption(o => o.setName('channel').setDescription('Channel for panel').setRequired(false)))
    .addSubcommand(s => s.setName('disable').setDescription('Disable verification')),
  cooldown: 5,
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;

    if (sub === 'setup') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [error('No Permission', 'Need Manage Server.')], ephemeral: true });
      }
      const method = interaction.options.getString('method');
      const verifiedRole = interaction.options.getRole('verified_role');
      const unverifiedRole = interaction.options.getRole('unverified_role');
      const question = interaction.options.getString('question');
      const answer = interaction.options.getString('answer');

      client.db.verification.set(`${guild.id}`, {
        enabled: true,
        method,
        verifiedRole: verifiedRole.id,
        unverifiedRole: unverifiedRole?.id || null,
        question: question || null,
        answer: answer || null,
      });

      const methodLabels = { button: 'Button Click', captcha: 'Math Captcha', question: 'Question Answer' };
      return interaction.reply({
        embeds: [success('Verification Setup', `**Method:** ${methodLabels[method]}\n**Verified Role:** ${verifiedRole}\n**Unverified Role:** ${unverifiedRole || 'None'}`)],
        ephemeral: true,
      });
    }

    if (sub === 'panel') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [error('No Permission', 'Need Manage Server.')], ephemeral: true });
      }
      const config = client.db.verification.get(`${guild.id}`) || {};
      if (!config.enabled) return interaction.reply({ embeds: [error('Not Setup', 'Run `/verify setup` first.')], ephemeral: true });

      const channel = interaction.options.getChannel('channel') || interaction.channel;
      const methodLabels = { button: '🖱️ Click the button below', captcha: '🧮 Solve a math captcha', question: '❓ Answer a question' };

      const embed = new EmbedBuilder()
        .setColor(COLORS.success)
        .setTitle('🔐 Verification Required')
        .setDescription(`**Welcome to ${guild.name}!**\n\nTo access the server, you must verify yourself.\n\n**Method:** ${methodLabels[config.method] || 'Click below'}\n\nClick the button below to begin.`)
        .setThumbnail(guild.iconURL({ dynamic: true }))
        .setFooter({ text: `${guild.name} • NekoBot Verification` })
        .setTimestamp();

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('verify_start')
          .setLabel('✅ Verify Me')
          .setStyle(ButtonStyle.Success)
      );

      await channel.send({ embeds: [embed], components: [row] });
      return interaction.reply({ embeds: [success('Panel Sent', `Verification panel sent to ${channel}`)], ephemeral: true });
    }

    if (sub === 'disable') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [error('No Permission', 'Need Manage Server.')], ephemeral: true });
      }
      client.db.verification.set(`${guild.id}.enabled`, false);
      return interaction.reply({ embeds: [success('Disabled', 'Verification system disabled.')], ephemeral: true });
    }
  },
};
