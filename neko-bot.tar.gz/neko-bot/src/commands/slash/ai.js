const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { COLORS, error } = require('../../utils/embeds');
const OpenAI = require('openai');

let openai = null;
if (process.env.OPENAI_API_KEY) {
  openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

const MODEL = process.env.AI_MODEL || 'gpt-4o';
const IMG_MODEL = process.env.IMAGE_MODEL || 'dall-e-3';

async function askAI(systemPrompt, userPrompt, maxTokens = 2000) {
  if (!openai) throw new Error('OpenAI API key not configured. Set OPENAI_API_KEY in .env');
  const res = await openai.chat.completions.create({
    model: MODEL,
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt },
    ],
    max_tokens: maxTokens,
  });
  return res.choices[0].message.content;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ai')
    .setDescription('AI-powered tools for NekoBot')
    .addSubcommand(s => s.setName('ask').setDescription('Ask AI anything').addStringOption(o => o.setName('question').setDescription('Your question').setRequired(true)))
    .addSubcommand(s => s.setName('image').setDescription('Generate an image with AI').addStringOption(o => o.setName('prompt').setDescription('Image description').setRequired(true)))
    .addSubcommand(s => s.setName('code').setDescription('Generate code').addStringOption(o => o.setName('task').setDescription('What to code').setRequired(true)).addStringOption(o => o.setName('language').setDescription('Programming language').setRequired(false)))
    .addSubcommand(s => s.setName('fix').setDescription('Fix broken code').addStringOption(o => o.setName('code').setDescription('Paste your broken code').setRequired(true)))
    .addSubcommand(s => s.setName('explain').setDescription('Explain code or a concept').addStringOption(o => o.setName('input').setDescription('Code or concept to explain').setRequired(true)))
    .addSubcommand(s => s.setName('summarize').setDescription('Summarize text').addStringOption(o => o.setName('text').setDescription('Text to summarize').setRequired(true)))
    .addSubcommand(s => s.setName('translate').setDescription('Translate text').addStringOption(o => o.setName('text').setDescription('Text to translate').setRequired(true)).addStringOption(o => o.setName('language').setDescription('Target language').setRequired(true)))
    .addSubcommand(s => s.setName('serverhelp').setDescription('Get help with Discord server setup')),
  cooldown: 10,
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply();

    try {
      if (sub === 'ask') {
        const q = interaction.options.getString('question');
        const answer = await askAI(
          'You are NekoBot, a helpful, friendly AI assistant for Discord servers. Be concise and helpful. Use markdown formatting.',
          q
        );
        const embed = new EmbedBuilder()
          .setColor(COLORS.primary)
          .setTitle('🤖 AI Response')
          .setDescription(answer.slice(0, 4000))
          .addFields({ name: '❓ Question', value: q.slice(0, 1000), inline: false })
          .setFooter({ text: `NekoBot AI • ${MODEL}` })
          .setTimestamp();
        return interaction.editReply({ embeds: [embed] });
      }

      if (sub === 'image') {
        if (!openai) return interaction.editReply({ embeds: [error('No API Key', 'OPENAI_API_KEY not configured.')] });
        const prompt = interaction.options.getString('prompt');
        const res = await openai.images.generate({
          model: IMG_MODEL,
          prompt,
          n: 1,
          size: '1024x1024',
          quality: 'standard',
        });
        const embed = new EmbedBuilder()
          .setColor(COLORS.neko)
          .setTitle('🎨 AI Generated Image')
          .setDescription(`**Prompt:** ${prompt}`)
          .setImage(res.data[0].url)
          .setFooter({ text: `NekoBot AI • ${IMG_MODEL}` })
          .setTimestamp();
        return interaction.editReply({ embeds: [embed] });
      }

      if (sub === 'code') {
        const task = interaction.options.getString('task');
        const lang = interaction.options.getString('language') || 'auto-detect';
        const code = await askAI(
          `You are an expert programmer. Generate clean, production-ready ${lang} code. Return ONLY the code with brief comments. Use markdown code blocks.`,
          task
        );
        const embed = new EmbedBuilder()
          .setColor(COLORS.info)
          .setTitle('💻 Generated Code')
          .setDescription(code.slice(0, 4000))
          .setFooter({ text: `NekoBot AI Code Gen • ${lang}` })
          .setTimestamp();
        return interaction.editReply({ embeds: [embed] });
      }

      if (sub === 'fix') {
        const code = interaction.options.getString('code');
        const fixed = await askAI(
          'You are an expert debugger. Analyze the code, identify bugs, fix them, and explain what was wrong. Use markdown code blocks for the fixed code.',
          `Fix this code:\n\`\`\`\n${code}\n\`\`\``
        );
        const embed = new EmbedBuilder()
          .setColor(COLORS.success)
          .setTitle('🔧 Code Fixed')
          .setDescription(fixed.slice(0, 4000))
          .setFooter({ text: 'NekoBot AI Bug Fixer' })
          .setTimestamp();
        return interaction.editReply({ embeds: [embed] });
      }

      if (sub === 'explain') {
        const input = interaction.options.getString('input');
        const explanation = await askAI(
          'You are a clear, concise teacher. Explain the given code or concept in simple terms. Use examples when helpful.',
          `Explain this:\n${input}`
        );
        const embed = new EmbedBuilder()
          .setColor(COLORS.warning)
          .setTitle('📚 Explanation')
          .setDescription(explanation.slice(0, 4000))
          .setFooter({ text: 'NekoBot AI Explainer' })
          .setTimestamp();
        return interaction.editReply({ embeds: [embed] });
      }

      if (sub === 'summarize') {
        const text = interaction.options.getString('text');
        const summary = await askAI(
          'You are a summarization expert. Create a concise, accurate summary with key bullet points.',
          `Summarize this:\n${text}`
        );
        const embed = new EmbedBuilder()
          .setColor(COLORS.info)
          .setTitle('📋 Summary')
          .setDescription(summary.slice(0, 4000))
          .setFooter({ text: 'NekoBot AI Summarizer' })
          .setTimestamp();
        return interaction.editReply({ embeds: [embed] });
      }

      if (sub === 'translate') {
        const text = interaction.options.getString('text');
        const lang = interaction.options.getString('language');
        const translated = await askAI(
          `You are a professional translator. Translate the given text to ${lang}. Return ONLY the translation.`,
          text
        );
        const embed = new EmbedBuilder()
          .setColor(COLORS.success)
          .setTitle('🌐 Translation')
          .addFields(
            { name: '📝 Original', value: text.slice(0, 1000), inline: false },
            { name: `🌍 ${lang}`, value: translated.slice(0, 1000), inline: false }
          )
          .setFooter({ text: 'NekoBot AI Translator' })
          .setTimestamp();
        return interaction.editReply({ embeds: [embed] });
      }

      if (sub === 'serverhelp') {
        const guild = interaction.guild;
        const memberCount = guild.memberCount;
        const channelCount = guild.channels.cache.size;
        const roleCount = guild.roles.cache.size;
        const context = `Server: ${guild.name}, Members: ${memberCount}, Channels: ${channelCount}, Roles: ${roleCount}`;
        const help = await askAI(
          'You are a Discord server expert. Given server info, provide 5-7 specific, actionable tips to improve server growth, engagement, and community. Be practical and specific.',
          `Help improve this Discord server:\n${context}`
        );
        const embed = new EmbedBuilder()
          .setColor(COLORS.gold)
          .setTitle(`🏰 Server Help — ${guild.name}`)
          .setDescription(help.slice(0, 4000))
          .setFooter({ text: 'NekoBot AI Server Helper' })
          .setTimestamp();
        return interaction.editReply({ embeds: [embed] });
      }
    } catch (err) {
      const msg = err.message?.includes('API key') ? 'OpenAI API key not configured or invalid.' : `AI error: ${err.message}`;
      await interaction.editReply({ embeds: [error('AI Error', msg)] });
    }
  },
};
