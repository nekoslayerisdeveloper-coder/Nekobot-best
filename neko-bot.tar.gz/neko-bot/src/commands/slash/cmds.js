const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { COLORS } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('cmds')
    .setDescription('View all NekoBot commands'),
  cooldown: 10,
  async execute(client, interaction) {
    const embed = new EmbedBuilder()
      .setColor(COLORS.neko)
      .setTitle('🐱 NekoBot — Command List')
      .setDescription('**Premium Discord Bot by NekoSlayer**\n\nPrefix: `-` | Slash Commands: `/`')
      .addFields(
        {
          name: '📨 Invite System (Prefix)',
          value: '`-inv [@user]` — View invite stats\n`-topinv` — Invite leaderboard',
          inline: false,
        },
        {
          name: '🤖 AI System',
          value: '`/ai ask` `/ai image` `/ai code` `/ai fix`\n`/ai explain` `/ai summarize` `/ai translate` `/ai serverhelp`',
          inline: false,
        },
        {
          name: '🎫 Ticket System',
          value: '`/ticket panel` `/ticket setup` `/ticket close`\n`/ticket rename` `/ticket add` `/ticket remove` `/ticket list`',
          inline: false,
        },
        {
          name: '📋 Applications',
          value: '`/apply create` `/apply setup` `/apply list` `/apply review`',
          inline: false,
        },
        {
          name: '🔐 Verification',
          value: '`/verify setup` `/verify panel` `/verify disable`',
          inline: false,
        },
        {
          name: '🛡️ AutoMod',
          value: '`/automod setup` `/automod antispam` `/automod antilink`\n`/automod antiinvite` `/automod anticaps` `/automod antialt`',
          inline: false,
        },
        {
          name: '⭐ Level System',
          value: '`/level rank` `/level leaderboard` `/level setup`\n`/level addrole` `/level removerole` `/level setxp`',
          inline: false,
        },
        {
          name: '💰 Economy',
          value: '`/economy balance` `/economy daily` `/economy work`\n`/economy transfer` `/economy shop` `/economy buy` `/economy inventory`',
          inline: false,
        },
        {
          name: '📊 Server Dashboard',
          value: '`/dashboard` — Full server stats overview',
          inline: false,
        },
        {
          name: '🖥️ VPS/Hosting Panel',
          value: '`/server add` `/server remove` `/server list` `/server view`',
          inline: false,
        },
        {
          name: '📦 Backup System',
          value: '`/backup create` `/backup list` `/backup status`',
          inline: false,
        },
        {
          name: '📝 Logging',
          value: '`/logging setup` `/logging enable` `/logging disable` `/logging view`',
          inline: false,
        },
        {
          name: '👋 Welcome System',
          value: '`/welcome setup` `/welcome leave` `/welcome disable` `/welcome test`',
          inline: false,
        },
        {
          name: '⚠️ Moderation',
          value: '`/mod ban` `/mod kick` `/mod timeout` `/mod unban`\n`/mod purge` `/mod slowmode`\n`/warn add` `/warn list` `/warn remove` `/warn clear`',
          inline: false,
        },
        {
          name: '🎁 Invite Rewards',
          value: '`/invitereward add` `/invitereward remove` `/invitereward list` `/invitereward bonus`',
          inline: false,
        },
        {
          name: '👑 Owner Panel',
          value: '`/owner eval` `/owner broadcast` `/owner stats`\n`/owner servercount` `/owner backup` `/owner restart`',
          inline: false,
        },
      )
      .setThumbnail(client.user?.displayAvatarURL() || null)
      .setFooter({ text: 'NekoBot Premium • by NekoSlayer' })
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  },
};
