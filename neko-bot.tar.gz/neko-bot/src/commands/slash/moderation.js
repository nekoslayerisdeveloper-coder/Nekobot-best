const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { success, error } = require('../../utils/embeds');
const { logEvent } = require('../../utils/logSystem');
const ms = require('ms');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mod')
    .setDescription('Moderation commands')
    .addSubcommand(s => s.setName('ban')
      .setDescription('Ban a user')
      .addUserOption(o => o.setName('user').setDescription('User to ban').setRequired(true))
      .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false))
      .addIntegerOption(o => o.setName('days').setDescription('Delete message days (0-7)').setRequired(false).setMinValue(0).setMaxValue(7))
    )
    .addSubcommand(s => s.setName('kick')
      .setDescription('Kick a user')
      .addUserOption(o => o.setName('user').setDescription('User to kick').setRequired(true))
      .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false))
    )
    .addSubcommand(s => s.setName('timeout')
      .setDescription('Timeout a user')
      .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
      .addStringOption(o => o.setName('duration').setDescription('Duration (e.g. 10m, 1h, 1d)').setRequired(true))
      .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false))
    )
    .addSubcommand(s => s.setName('untimeout')
      .setDescription('Remove timeout from a user')
      .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
    )
    .addSubcommand(s => s.setName('unban')
      .setDescription('Unban a user')
      .addStringOption(o => o.setName('user_id').setDescription('User ID to unban').setRequired(true))
    )
    .addSubcommand(s => s.setName('purge')
      .setDescription('Delete messages')
      .addIntegerOption(o => o.setName('amount').setDescription('Number of messages (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))
      .addUserOption(o => o.setName('user').setDescription('From specific user only').setRequired(false))
    )
    .addSubcommand(s => s.setName('slowmode')
      .setDescription('Set channel slowmode')
      .addIntegerOption(o => o.setName('seconds').setDescription('Seconds (0 to disable)').setRequired(true).setMinValue(0).setMaxValue(21600))
    ),
  cooldown: 3,
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;

    if (sub === 'ban') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.BanMembers)) {
        return interaction.reply({ embeds: [error('No Permission', 'Ban Members required.')], ephemeral: true });
      }
      const user = interaction.options.getUser('user');
      const reason = interaction.options.getString('reason') || 'No reason';
      const days = interaction.options.getInteger('days') || 0;
      const member = guild.members.cache.get(user.id);
      if (member && !member.bannable) return interaction.reply({ embeds: [error('Cannot Ban', 'I cannot ban this user.')], ephemeral: true });
      await guild.members.ban(user.id, { reason, deleteMessageSeconds: days * 86400 });
      await logEvent(client, guild, 'ban', { user: user.tag, id: user.id, reason });
      return interaction.reply({ embeds: [success('Banned', `**${user.tag}** has been banned.\n**Reason:** ${reason}`)] });
    }

    if (sub === 'kick') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.KickMembers)) {
        return interaction.reply({ embeds: [error('No Permission', 'Kick Members required.')], ephemeral: true });
      }
      const user = interaction.options.getUser('user');
      const reason = interaction.options.getString('reason') || 'No reason';
      const member = guild.members.cache.get(user.id);
      if (!member) return interaction.reply({ embeds: [error('Not Found', 'User not in server.')], ephemeral: true });
      if (!member.kickable) return interaction.reply({ embeds: [error('Cannot Kick', 'I cannot kick this user.')], ephemeral: true });
      await member.kick(reason);
      await logEvent(client, guild, 'kick', { user: user.tag, mod: interaction.user.tag, reason });
      return interaction.reply({ embeds: [success('Kicked', `**${user.tag}** has been kicked.\n**Reason:** ${reason}`)] });
    }

    if (sub === 'timeout') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
        return interaction.reply({ embeds: [error('No Permission', 'Moderate Members required.')], ephemeral: true });
      }
      const user = interaction.options.getUser('user');
      const duration = interaction.options.getString('duration');
      const reason = interaction.options.getString('reason') || 'No reason';
      const parsed = ms(duration);
      if (!parsed) return interaction.reply({ embeds: [error('Invalid Duration', 'Use formats like: 10m, 1h, 1d')], ephemeral: true });
      const member = guild.members.cache.get(user.id);
      if (!member) return interaction.reply({ embeds: [error('Not Found', 'User not in server.')], ephemeral: true });
      await member.timeout(parsed, reason);
      return interaction.reply({ embeds: [success('Timed Out', `**${user.tag}** timed out for **${duration}**.\n**Reason:** ${reason}`)] });
    }

    if (sub === 'untimeout') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
        return interaction.reply({ embeds: [error('No Permission', 'Moderate Members required.')], ephemeral: true });
      }
      const user = interaction.options.getUser('user');
      const member = guild.members.cache.get(user.id);
      if (!member) return interaction.reply({ embeds: [error('Not Found', 'User not in server.')], ephemeral: true });
      await member.timeout(null);
      return interaction.reply({ embeds: [success('Timeout Removed', `**${user.tag}**'s timeout has been removed.`)] });
    }

    if (sub === 'unban') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.BanMembers)) {
        return interaction.reply({ embeds: [error('No Permission', 'Ban Members required.')], ephemeral: true });
      }
      const userId = interaction.options.getString('user_id');
      await guild.members.unban(userId).catch(() => {});
      return interaction.reply({ embeds: [success('Unbanned', `User \`${userId}\` has been unbanned.`)] });
    }

    if (sub === 'purge') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
        return interaction.reply({ embeds: [error('No Permission', 'Manage Messages required.')], ephemeral: true });
      }
      const amount = interaction.options.getInteger('amount');
      const filterUser = interaction.options.getUser('user');
      let messages = await interaction.channel.messages.fetch({ limit: filterUser ? 100 : amount });
      if (filterUser) messages = messages.filter(m => m.author.id === filterUser.id).first(amount);
      const deleted = await interaction.channel.bulkDelete(messages, true).catch(() => null);
      await interaction.reply({ embeds: [success('Purged', `Deleted **${deleted?.size || amount}** messages.`)], ephemeral: true });
    }

    if (sub === 'slowmode') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
        return interaction.reply({ embeds: [error('No Permission', 'Manage Channels required.')], ephemeral: true });
      }
      const seconds = interaction.options.getInteger('seconds');
      await interaction.channel.setRateLimitPerUser(seconds);
      return interaction.reply({ embeds: [success('Slowmode Set', seconds === 0 ? 'Slowmode disabled.' : `Slowmode set to **${seconds}s**`)] });
    }
  },
};
