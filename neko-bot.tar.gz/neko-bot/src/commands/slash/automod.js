const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { success, error } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('automod')
    .setDescription('Configure AutoMod system')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(s => s.setName('setup').setDescription('Enable automod with defaults'))
    .addSubcommand(s => s.setName('antispam')
      .setDescription('Configure anti-spam')
      .addBooleanOption(o => o.setName('enabled').setDescription('Enable anti-spam').setRequired(true))
      .addIntegerOption(o => o.setName('limit').setDescription('Messages before trigger').setRequired(false))
      .addIntegerOption(o => o.setName('interval').setDescription('Interval in ms').setRequired(false))
      .addStringOption(o => o.setName('action').setDescription('Action').setRequired(false)
        .addChoices({ name: 'Delete', value: 'delete' }, { name: 'Warn', value: 'warn' }, { name: 'Mute', value: 'mute' }, { name: 'Kick', value: 'kick' }, { name: 'Ban', value: 'ban' }))
    )
    .addSubcommand(s => s.setName('antilink')
      .setDescription('Configure anti-link')
      .addBooleanOption(o => o.setName('enabled').setDescription('Enable').setRequired(true))
      .addStringOption(o => o.setName('allowed').setDescription('Allowed domains (comma-separated)').setRequired(false))
    )
    .addSubcommand(s => s.setName('antiinvite')
      .setDescription('Configure anti-invite')
      .addBooleanOption(o => o.setName('enabled').setDescription('Enable').setRequired(true))
    )
    .addSubcommand(s => s.setName('anticaps')
      .setDescription('Configure anti-caps')
      .addBooleanOption(o => o.setName('enabled').setDescription('Enable').setRequired(true))
      .addIntegerOption(o => o.setName('threshold').setDescription('Cap threshold % (1-100)').setRequired(false).setMinValue(1).setMaxValue(100))
    )
    .addSubcommand(s => s.setName('antialt')
      .setDescription('Kick alt accounts')
      .addBooleanOption(o => o.setName('enabled').setDescription('Enable').setRequired(true))
      .addIntegerOption(o => o.setName('min_age').setDescription('Min account age in days').setRequired(false))
    )
    .addSubcommand(s => s.setName('muterole')
      .setDescription('Set mute role for automod')
      .addRoleOption(o => o.setName('role').setDescription('Mute role').setRequired(true))
    )
    .addSubcommand(s => s.setName('whitelist')
      .setDescription('Whitelist a role from automod')
      .addRoleOption(o => o.setName('role').setDescription('Role to whitelist').setRequired(true))
    )
    .addSubcommand(s => s.setName('disable').setDescription('Disable all automod')),
  cooldown: 5,
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;
    const key = `${guild.id}`;

    if (sub === 'setup') {
      client.db.automod.set(key, {
        enabled: true,
        antiSpam: { enabled: true, limit: 5, interval: 5000, action: 'delete' },
        antiLink: { enabled: false, allowed: [] },
        antiInvite: { enabled: true, action: 'delete' },
        antiCaps: { enabled: true, threshold: 0.7, action: 'delete' },
        antiAlt: { enabled: false, minAge: 7 },
        whitelistRoles: [],
        muteRole: null,
      });
      return interaction.reply({ embeds: [success('AutoMod Enabled', 'AutoMod configured with default settings!\n\nEnabled: Anti-Spam, Anti-Invite, Anti-Caps\n\nUse subcommands to customize.')] });
    }

    if (sub === 'antispam') {
      const enabled = interaction.options.getBoolean('enabled');
      const limit = interaction.options.getInteger('limit') || 5;
      const interval = interaction.options.getInteger('interval') || 5000;
      const action = interaction.options.getString('action') || 'delete';
      client.db.automod.set(`${key}.enabled`, true);
      client.db.automod.set(`${key}.antiSpam`, { enabled, limit, interval, action });
      return interaction.reply({ embeds: [success('Anti-Spam Updated', `Anti-spam ${enabled ? 'enabled' : 'disabled'}. Limit: ${limit} msgs/${interval}ms. Action: ${action}`)] });
    }

    if (sub === 'antilink') {
      const enabled = interaction.options.getBoolean('enabled');
      const allowed = (interaction.options.getString('allowed') || '').split(',').map(s => s.trim()).filter(Boolean);
      client.db.automod.set(`${key}.enabled`, true);
      client.db.automod.set(`${key}.antiLink`, { enabled, allowed });
      return interaction.reply({ embeds: [success('Anti-Link Updated', `Anti-link ${enabled ? 'enabled' : 'disabled'}. Allowed: ${allowed.join(', ') || 'none'}`)] });
    }

    if (sub === 'antiinvite') {
      const enabled = interaction.options.getBoolean('enabled');
      client.db.automod.set(`${key}.enabled`, true);
      client.db.automod.set(`${key}.antiInvite`, { enabled, action: 'delete' });
      return interaction.reply({ embeds: [success('Anti-Invite Updated', `Anti-invite ${enabled ? 'enabled' : 'disabled'}.`)] });
    }

    if (sub === 'anticaps') {
      const enabled = interaction.options.getBoolean('enabled');
      const threshold = (interaction.options.getInteger('threshold') || 70) / 100;
      client.db.automod.set(`${key}.antiCaps`, { enabled, threshold, action: 'delete' });
      return interaction.reply({ embeds: [success('Anti-Caps Updated', `Anti-caps ${enabled ? 'enabled' : 'disabled'}. Threshold: ${Math.round(threshold * 100)}%`)] });
    }

    if (sub === 'antialt') {
      const enabled = interaction.options.getBoolean('enabled');
      const minAge = interaction.options.getInteger('min_age') || 7;
      client.db.automod.set(`${key}.antiAlt`, { enabled, minAge });
      return interaction.reply({ embeds: [success('Anti-Alt Updated', `Anti-alt ${enabled ? 'enabled' : 'disabled'}. Min age: ${minAge} days.`)] });
    }

    if (sub === 'muterole') {
      const role = interaction.options.getRole('role');
      client.db.automod.set(`${key}.muteRole`, role.id);
      return interaction.reply({ embeds: [success('Mute Role Set', `Mute role set to ${role}`)] });
    }

    if (sub === 'whitelist') {
      const role = interaction.options.getRole('role');
      const wl = client.db.automod.get(`${key}.whitelistRoles`) || [];
      if (!wl.includes(role.id)) {
        wl.push(role.id);
        client.db.automod.set(`${key}.whitelistRoles`, wl);
      }
      return interaction.reply({ embeds: [success('Whitelisted', `${role} is now exempt from AutoMod.`)] });
    }

    if (sub === 'disable') {
      client.db.automod.set(`${key}.enabled`, false);
      return interaction.reply({ embeds: [success('AutoMod Disabled', 'All automod features have been disabled.')] });
    }
  },
};
