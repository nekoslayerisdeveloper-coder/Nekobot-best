const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { success, error, info, COLORS } = require('../../utils/embeds');
const { logEvent } = require('../../utils/logSystem');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warning system')
    .addSubcommand(s => s.setName('add')
      .setDescription('Warn a user')
      .addUserOption(o => o.setName('user').setDescription('User to warn').setRequired(true))
      .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(true))
    )
    .addSubcommand(s => s.setName('list').setDescription('View a user\'s warnings').addUserOption(o => o.setName('user').setDescription('User').setRequired(true)))
    .addSubcommand(s => s.setName('remove').setDescription('Remove a warning').addUserOption(o => o.setName('user').setDescription('User').setRequired(true)).addIntegerOption(o => o.setName('index').setDescription('Warning number').setRequired(true)))
    .addSubcommand(s => s.setName('clear').setDescription('Clear all warnings for a user').addUserOption(o => o.setName('user').setDescription('User').setRequired(true))),
  cooldown: 3,
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;

    if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
      return interaction.reply({ embeds: [error('No Permission', 'You need Moderate Members permission.')], ephemeral: true });
    }

    if (sub === 'add') {
      const user = interaction.options.getUser('user');
      const reason = interaction.options.getString('reason');
      const key = `${guild.id}.${user.id}.warnings`;
      client.db.warnings.push(key, { reason, time: Date.now(), mod: interaction.user.tag });
      const count = (client.db.warnings.get(key) || []).length;

      try {
        await user.send({ embeds: [error(`You were warned in ${guild.name}`, `**Reason:** ${reason}\n**Warnings:** ${count}`)] }).catch(() => {});
      } catch {}

      await logEvent(client, guild, 'warn', { user: user.tag, mod: interaction.user.tag, reason });
      return interaction.reply({ embeds: [success('Warning Issued', `${user} has been warned.\n**Reason:** ${reason}\n**Total Warnings:** ${count}`)] });
    }

    if (sub === 'list') {
      const user = interaction.options.getUser('user');
      const warnings = client.db.warnings.get(`${guild.id}.${user.id}.warnings`) || [];
      if (!warnings.length) return interaction.reply({ embeds: [info('No Warnings', `${user.tag} has no warnings.`)] });

      const lines = warnings.map((w, i) => `**${i + 1}.** ${w.reason}\nBy: ${w.mod} | <t:${Math.floor(w.time / 1000)}:R>`);
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor(COLORS.warning)
          .setTitle(`⚠️ Warnings — ${user.tag}`)
          .setDescription(lines.join('\n\n'))
          .setFooter({ text: `${warnings.length} total warnings` })
          .setTimestamp()],
      });
    }

    if (sub === 'remove') {
      const user = interaction.options.getUser('user');
      const idx = interaction.options.getInteger('index') - 1;
      const key = `${guild.id}.${user.id}.warnings`;
      const warnings = client.db.warnings.get(key) || [];
      if (idx < 0 || idx >= warnings.length) return interaction.reply({ embeds: [error('Invalid', 'Warning not found.')], ephemeral: true });
      warnings.splice(idx, 1);
      client.db.warnings.set(key, warnings);
      return interaction.reply({ embeds: [success('Warning Removed', `Warning #${idx + 1} removed from ${user.tag}`)] });
    }

    if (sub === 'clear') {
      const user = interaction.options.getUser('user');
      client.db.warnings.set(`${guild.id}.${user.id}.warnings`, []);
      return interaction.reply({ embeds: [success('Warnings Cleared', `All warnings cleared for ${user.tag}`)] });
    }
  },
};
