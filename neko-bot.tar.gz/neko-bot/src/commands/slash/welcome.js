const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { success, error } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('welcome')
    .setDescription('Welcome & leave system configuration')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(s => s.setName('setup')
      .setDescription('Setup welcome messages')
      .addChannelOption(o => o.setName('channel').setDescription('Welcome channel').setRequired(true))
      .addStringOption(o => o.setName('message').setDescription('Welcome message ({user} {server} {count} {tag})').setRequired(false))
      .addStringOption(o => o.setName('title').setDescription('Embed title').setRequired(false))
      .addRoleOption(o => o.setName('autorole').setDescription('Auto-assign role').setRequired(false))
    )
    .addSubcommand(s => s.setName('leave')
      .setDescription('Setup leave messages')
      .addChannelOption(o => o.setName('channel').setDescription('Leave channel').setRequired(true))
      .addStringOption(o => o.setName('message').setDescription('Leave message ({user} {tag} {server})').setRequired(false))
    )
    .addSubcommand(s => s.setName('disable').setDescription('Disable welcome/leave messages'))
    .addSubcommand(s => s.setName('test').setDescription('Test the welcome message')),
  cooldown: 5,
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;

    if (sub === 'setup') {
      const channel = interaction.options.getChannel('channel');
      const message = interaction.options.getString('message') || 'Welcome to **{server}**, {user}! You are member **#{count}**!';
      const title = interaction.options.getString('title') || `Welcome to ${guild.name}!`;
      const autorole = interaction.options.getRole('autorole');

      const current = client.db.welcome.get(`${guild.id}`) || {};
      client.db.welcome.set(`${guild.id}`, {
        ...current,
        enabled: true,
        channel: channel.id,
        message,
        title,
        autorole: autorole ? [autorole.id] : (current.autorole || []),
      });

      return interaction.reply({
        embeds: [success('Welcome Setup', `Welcome messages enabled!\n**Channel:** ${channel}\n**Auto-role:** ${autorole || 'None'}`)],
        ephemeral: true,
      });
    }

    if (sub === 'leave') {
      const channel = interaction.options.getChannel('channel');
      const message = interaction.options.getString('message') || '**{tag}** has left **{server}**. Goodbye!';
      const current = client.db.welcome.get(`${guild.id}`) || {};
      client.db.welcome.set(`${guild.id}`, { ...current, leaveEnabled: true, leaveChannel: channel.id, leaveMessage: message });
      return interaction.reply({ embeds: [success('Leave Setup', `Leave messages configured for ${channel}`)], ephemeral: true });
    }

    if (sub === 'disable') {
      const current = client.db.welcome.get(`${guild.id}`) || {};
      client.db.welcome.set(`${guild.id}`, { ...current, enabled: false, leaveEnabled: false });
      return interaction.reply({ embeds: [success('Disabled', 'Welcome/leave messages disabled.')] });
    }

    if (sub === 'test') {
      const { sendWelcomeCard } = require('../../utils/welcomeCard');
      await sendWelcomeCard(client, interaction.member);
      return interaction.reply({ embeds: [success('Test Sent', 'Test welcome message sent to configured channel!')], ephemeral: true });
    }
  },
};
