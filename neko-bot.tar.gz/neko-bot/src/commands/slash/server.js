const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { success, error, info, COLORS } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('server')
    .setDescription('VPS/Server hosting panel')
    .addSubcommand(s => s.setName('add')
      .setDescription('Add a server to your panel')
      .addStringOption(o => o.setName('name').setDescription('Server name').setRequired(true))
      .addStringOption(o => o.setName('ip').setDescription('Server IP/hostname').setRequired(true))
      .addStringOption(o => o.setName('description').setDescription('Server description').setRequired(false))
      .addIntegerOption(o => o.setName('port').setDescription('Server port').setRequired(false))
    )
    .addSubcommand(s => s.setName('remove').setDescription('Remove a server').addStringOption(o => o.setName('id').setDescription('Server ID').setRequired(true)))
    .addSubcommand(s => s.setName('list').setDescription('View all your servers'))
    .addSubcommand(s => s.setName('view').setDescription('View a server\'s details').addStringOption(o => o.setName('id').setDescription('Server ID').setRequired(true))),
  cooldown: 5,
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    const userId = interaction.user.id;

    if (sub === 'add') {
      const name = interaction.options.getString('name');
      const ip = interaction.options.getString('ip');
      const description = interaction.options.getString('description') || 'No description';
      const port = interaction.options.getInteger('port') || null;

      const servers = client.db.hosting.get(`${userId}.servers`) || [];
      if (servers.length >= 10) {
        return interaction.reply({ embeds: [error('Limit Reached', 'You can store up to **10 servers** in your panel.')], ephemeral: true });
      }

      const serverId = Date.now().toString(36).toUpperCase();
      servers.push({ id: serverId, name, ip, description, port, addedAt: Date.now() });
      client.db.hosting.set(`${userId}.servers`, servers);

      return interaction.reply({
        embeds: [success('Server Added! 🖥️', `**${name}** added to your panel.\nID: \`${serverId}\``)],
        ephemeral: true,
      });
    }

    if (sub === 'remove') {
      const serverId = interaction.options.getString('id');
      const servers = client.db.hosting.get(`${userId}.servers`) || [];
      const idx = servers.findIndex(s => s.id === serverId);
      if (idx === -1) return interaction.reply({ embeds: [error('Not Found', `Server \`${serverId}\` not found.`)], ephemeral: true });

      const removed = servers.splice(idx, 1)[0];
      client.db.hosting.set(`${userId}.servers`, servers);
      return interaction.reply({ embeds: [success('Server Removed', `**${removed.name}** removed from your panel.`)], ephemeral: true });
    }

    if (sub === 'list') {
      const servers = client.db.hosting.get(`${userId}.servers`) || [];
      if (!servers.length) {
        return interaction.reply({ embeds: [info('No Servers', 'You have no servers added. Use `/server add` to add one.')], ephemeral: true });
      }

      const lines = servers.map((s, i) => `**${i + 1}.** \`${s.id}\` — **${s.name}**\n   📡 IP: ||\`${s.ip}${s.port ? `:${s.port}` : ''}\`|| | ${s.description}`);
      const embed = new EmbedBuilder()
        .setColor(COLORS.dark)
        .setTitle('🖥️ Your Server Panel')
        .setDescription(lines.join('\n\n'))
        .setFooter({ text: `${servers.length}/10 servers • NekoBot Hosting Panel` })
        .setTimestamp();

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'view') {
      const serverId = interaction.options.getString('id');
      const servers = client.db.hosting.get(`${userId}.servers`) || [];
      const srv = servers.find(s => s.id === serverId);
      if (!srv) return interaction.reply({ embeds: [error('Not Found', `Server \`${serverId}\` not found.`)], ephemeral: true });

      const embed = new EmbedBuilder()
        .setColor(COLORS.dark)
        .setTitle(`🖥️ Server — ${srv.name}`)
        .addFields(
          { name: '🆔 ID', value: `\`${srv.id}\``, inline: true },
          { name: '📡 IP', value: `||\`${srv.ip}${srv.port ? `:${srv.port}` : ''}\`||`, inline: true },
          { name: '📝 Description', value: srv.description, inline: false },
          { name: '📅 Added', value: `<t:${Math.floor(srv.addedAt / 1000)}:R>`, inline: true },
        )
        .setTimestamp();

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('_noop').setLabel('🖥️ Panel View').setStyle(ButtonStyle.Secondary).setDisabled(true),
      );

      return interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
    }
  },
};
