const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { ownerOnly, success, error, info, COLORS } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('owner')
    .setDescription('Owner-only control panel (NekoSlayer)')
    .addSubcommand(s => s.setName('eval').setDescription('Execute JavaScript').addStringOption(o => o.setName('code').setDescription('Code to run').setRequired(true)))
    .addSubcommand(s => s.setName('servercount').setDescription('View server count'))
    .addSubcommand(s => s.setName('broadcast').setDescription('Broadcast a message to all servers').addStringOption(o => o.setName('message').setDescription('Message to broadcast').setRequired(true)))
    .addSubcommand(s => s.setName('restart').setDescription('Restart the bot'))
    .addSubcommand(s => s.setName('shutdown').setDescription('Shutdown the bot'))
    .addSubcommand(s => s.setName('backup').setDescription('Force backup all databases'))
    .addSubcommand(s => s.setName('stats').setDescription('Detailed bot statistics')),
  cooldown: 0,
  async execute(client, interaction) {
    if (!client.isOwner(interaction.user.id)) {
      return interaction.reply({ embeds: [ownerOnly()], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'eval') {
      const code = interaction.options.getString('code');
      try {
        let result = eval(code);
        if (result instanceof Promise) result = await result;
        const output = typeof result === 'object' ? JSON.stringify(result, null, 2) : String(result);
        return interaction.reply({
          embeds: [new EmbedBuilder()
            .setColor(COLORS.success)
            .setTitle('📡 Eval Output')
            .addFields(
              { name: '📥 Input', value: `\`\`\`js\n${code.slice(0, 1000)}\n\`\`\``, inline: false },
              { name: '📤 Output', value: `\`\`\`js\n${output.slice(0, 1000)}\n\`\`\``, inline: false }
            )
            .setTimestamp()],
          ephemeral: true,
        });
      } catch (err) {
        return interaction.reply({
          embeds: [error('Eval Error', `\`\`\`js\n${err.message.slice(0, 1000)}\n\`\`\``)],
          ephemeral: true,
        });
      }
    }

    if (sub === 'servercount') {
      const guilds = client.guilds.cache;
      const totalMembers = guilds.reduce((s, g) => s + g.memberCount, 0);
      const lines = guilds.map(g => `• **${g.name}** — ${g.memberCount} members`).slice(0, 20).join('\n');
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor(COLORS.gold)
          .setTitle(`📊 Server Count — ${guilds.size} Servers`)
          .setDescription(`**Total Members:** ${totalMembers.toLocaleString()}\n\n${lines}`)
          .setTimestamp()],
        ephemeral: true,
      });
    }

    if (sub === 'broadcast') {
      const message = interaction.options.getString('message');
      await interaction.deferReply({ ephemeral: true });
      let sent = 0;
      let failed = 0;

      for (const guild of client.guilds.cache.values()) {
        const channel = guild.systemChannel || guild.channels.cache.find(c => c.isTextBased() && c.permissionsFor(guild.members.me)?.has('SendMessages'));
        if (channel) {
          const embed = new EmbedBuilder()
            .setColor(COLORS.neko)
            .setTitle('📢 NekoBot Announcement')
            .setDescription(message)
            .setFooter({ text: 'From NekoSlayer • NekoBot Owner' })
            .setTimestamp();
          await channel.send({ embeds: [embed] }).then(() => sent++).catch(() => failed++);
        }
      }

      return interaction.editReply({ embeds: [success('Broadcast Sent', `Sent to **${sent}** servers. Failed: **${failed}**`)] });
    }

    if (sub === 'backup') {
      await interaction.deferReply({ ephemeral: true });
      const results = client.backupAll();
      return interaction.editReply({ embeds: [success('Backup Complete', `Backed up **${results.length}** databases.`)] });
    }

    if (sub === 'stats') {
      const uptime = process.uptime();
      const d = Math.floor(uptime / 86400);
      const h = Math.floor((uptime % 86400) / 3600);
      const m = Math.floor((uptime % 3600) / 60);
      const mem = process.memoryUsage();

      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor(COLORS.neko)
          .setTitle('🤖 NekoBot — Detailed Stats')
          .addFields(
            { name: '⏱️ Uptime', value: `${d}d ${h}h ${m}m`, inline: true },
            { name: '🏓 Ping', value: `${client.ws.ping}ms`, inline: true },
            { name: '🌐 Servers', value: `${client.guilds.cache.size}`, inline: true },
            { name: '👥 Users', value: `${client.users.cache.size.toLocaleString()}`, inline: true },
            { name: '💾 RAM', value: `${(mem.heapUsed / 1024 / 1024).toFixed(1)}MB / ${(mem.heapTotal / 1024 / 1024).toFixed(1)}MB`, inline: true },
            { name: '📡 Commands', value: `${client.slashCommands.size} slash / ${client.commands.size} prefix`, inline: true },
            { name: '🟢 Node.js', value: process.version, inline: true },
            { name: '📦 discord.js', value: require('discord.js').version, inline: true },
            { name: '👑 Owner', value: 'NekoSlayer', inline: true },
          )
          .setTimestamp()],
        ephemeral: true,
      });
    }

    if (sub === 'restart') {
      await interaction.reply({ embeds: [info('Restarting...', 'NekoBot is restarting. Back in a moment!')], ephemeral: true });
      setTimeout(() => process.exit(0), 2000);
    }

    if (sub === 'shutdown') {
      await interaction.reply({ embeds: [info('Shutting Down...', 'NekoBot is shutting down. Goodbye!')], ephemeral: true });
      setTimeout(() => process.exit(0), 2000);
    }
  },
};
