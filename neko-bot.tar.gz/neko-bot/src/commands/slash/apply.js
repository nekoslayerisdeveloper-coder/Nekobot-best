const {
  SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder,
  PermissionFlagsBits
} = require('discord.js');
const { success, error, info, COLORS } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('apply')
    .setDescription('Application system')
    .addSubcommand(s => s.setName('create').setDescription('Submit an application'))
    .addSubcommand(s => s.setName('setup')
      .setDescription('Setup application system')
      .addChannelOption(o => o.setName('review_channel').setDescription('Where to send applications').setRequired(true))
    )
    .addSubcommand(s => s.setName('review').setDescription('Review applications').addStringOption(o => o.setName('id').setDescription('Application ID').setRequired(false)))
    .addSubcommand(s => s.setName('list').setDescription('List pending applications')),
  cooldown: 5,
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;

    if (sub === 'setup') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [error('No Permission', 'Need Manage Server.')], ephemeral: true });
      }
      const reviewChannel = interaction.options.getChannel('review_channel');
      client.db.applications.set(`${guild.id}.config.reviewChannel`, reviewChannel.id);
      return interaction.reply({ embeds: [success('Setup Done', `Applications will go to ${reviewChannel}`)], ephemeral: true });
    }

    if (sub === 'create') {
      const config = client.db.applications.get(`${guild.id}.config`) || {};
      if (!config.reviewChannel) {
        return interaction.reply({ embeds: [error('Not Setup', 'Application system not configured.')], ephemeral: true });
      }

      const select = new StringSelectMenuBuilder()
        .setCustomId('apply_form')
        .setPlaceholder('📋 Choose application type...')
        .addOptions([
          { label: 'Staff', description: 'Apply for staff team', emoji: '👮', value: 'staff' },
          { label: 'Moderator', description: 'Apply for moderator', emoji: '🛡️', value: 'mod' },
          { label: 'Admin', description: 'Apply for admin', emoji: '⚙️', value: 'admin' },
          { label: 'Developer', description: 'Apply for developer role', emoji: '💻', value: 'developer' },
          { label: 'Builder', description: 'Apply for builder role', emoji: '🏗️', value: 'builder' },
          { label: 'Custom', description: 'Custom application', emoji: '📋', value: 'custom' },
        ]);

      const embed = new EmbedBuilder()
        .setColor(COLORS.primary)
        .setTitle('📋 Application Center')
        .setDescription('Select the position you want to apply for below.\n\nAll applications are reviewed by staff within **24-48 hours**.')
        .setFooter({ text: `${guild.name} Applications • NekoBot` })
        .setTimestamp();

      return interaction.reply({ embeds: [embed], components: [new ActionRowBuilder().addComponents(select)], ephemeral: true });
    }

    if (sub === 'list') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [error('No Permission', 'Need Manage Server.')], ephemeral: true });
      }
      const apps = client.db.applications.get(`${guild.id}.apps`) || {};
      const pending = Object.values(apps).filter(a => a.status === 'pending');
      if (!pending.length) return interaction.reply({ embeds: [info('No Applications', 'No pending applications.')], ephemeral: true });

      const lines = pending.slice(0, 20).map(a => `📋 \`${a.id}\` — <@${a.userId}> | Type: ${a.type} | <t:${Math.floor(a.submittedAt / 1000)}:R>`);
      return interaction.reply({
        embeds: [new EmbedBuilder().setColor(COLORS.primary).setTitle(`📋 Pending Applications (${pending.length})`).setDescription(lines.join('\n')).setTimestamp()],
        ephemeral: true,
      });
    }

    if (sub === 'review') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [error('No Permission', 'Need Manage Server.')], ephemeral: true });
      }
      const appId = interaction.options.getString('id');
      if (!appId) return interaction.reply({ embeds: [info('Usage', 'Use `/apply list` to see pending application IDs.')], ephemeral: true });
      const app = client.db.applications.get(`${guild.id}.apps.${appId}`);
      if (!app) return interaction.reply({ embeds: [error('Not Found', `Application \`${appId}\` not found.`)], ephemeral: true });
      return interaction.reply({ embeds: [info(`Application ${appId}`, `User: <@${app.userId}>\nType: ${app.type}\nStatus: ${app.status}\nSubmitted: <t:${Math.floor(app.submittedAt / 1000)}:R>`)], ephemeral: true });
    }
  },
};
