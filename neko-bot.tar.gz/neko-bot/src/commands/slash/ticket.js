const {
  SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  StringSelectMenuBuilder, PermissionFlagsBits
} = require('discord.js');
const { createTicket } = require('../../utils/ticketHandler');
const { success, error, info, COLORS } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Ticket system management')
    .addSubcommand(s => s.setName('panel').setDescription('Send the ticket panel').addChannelOption(o => o.setName('channel').setDescription('Channel to send panel').setRequired(false)))
    .addSubcommand(s => s.setName('setup')
      .setDescription('Setup ticket system')
      .addChannelOption(o => o.setName('category').setDescription('Ticket category').setRequired(true))
      .addRoleOption(o => o.setName('support_role').setDescription('Support team role').setRequired(false))
      .addChannelOption(o => o.setName('log_channel').setDescription('Log channel').setRequired(false))
      .addChannelOption(o => o.setName('transcript_channel').setDescription('Transcript channel').setRequired(false))
    )
    .addSubcommand(s => s.setName('close').setDescription('Close the current ticket'))
    .addSubcommand(s => s.setName('rename').setDescription('Rename this ticket').addStringOption(o => o.setName('name').setDescription('New name').setRequired(true)))
    .addSubcommand(s => s.setName('add').setDescription('Add a user to this ticket').addUserOption(o => o.setName('user').setDescription('User to add').setRequired(true)))
    .addSubcommand(s => s.setName('remove').setDescription('Remove a user from this ticket').addUserOption(o => o.setName('user').setDescription('User to remove').setRequired(true)))
    .addSubcommand(s => s.setName('list').setDescription('List all open tickets')),
  cooldown: 5,
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;

    if (sub === 'setup') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [error('No Permission', 'You need Manage Server permission.')], ephemeral: true });
      }
      const category = interaction.options.getChannel('category');
      const supportRole = interaction.options.getRole('support_role');
      const logChannel = interaction.options.getChannel('log_channel');
      const transcriptChannel = interaction.options.getChannel('transcript_channel');

      const config = {
        category: category.id,
        supportRoles: supportRole ? [supportRole.id] : [],
        logChannel: logChannel?.id || null,
        transcriptChannel: transcriptChannel?.id || null,
        cooldown: 5,
        allowMultiple: false,
      };

      client.db.tickets.set(`${guild.id}.config`, config);

      if (logChannel) {
        client.db.logging.set(`${guild.id}.enabled`, true);
        client.db.logging.set(`${guild.id}.channels.ticket`, logChannel.id);
      }

      return interaction.reply({
        embeds: [success('Ticket System Setup', `Configuration saved!\n**Category:** ${category}\n**Support Role:** ${supportRole || 'None'}\n**Logs:** ${logChannel || 'None'}`)],
        ephemeral: true,
      });
    }

    if (sub === 'panel') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ embeds: [error('No Permission', 'You need Manage Server permission.')], ephemeral: true });
      }

      const channel = interaction.options.getChannel('channel') || interaction.channel;

      const embed = new EmbedBuilder()
        .setColor(COLORS.primary)
        .setTitle('🎫 NekoBot Support Center')
        .setDescription('Select the type of support you need below.\n\nOur team will assist you as soon as possible.\n\n**Support Types:**\n💳 Billing — Payment issues\n🐛 Bug — Report a bug\n⚖️ Appeal — Ban/mute appeals\n🛒 Purchase — Purchase inquiries\n🤝 Partner — Partnerships\n💻 Developer — Dev requests\n📋 General — Other topics')
        .setThumbnail(guild.iconURL({ dynamic: true }))
        .setFooter({ text: `${guild.name} Support • NekoBot` })
        .setTimestamp();

      const select = new StringSelectMenuBuilder()
        .setCustomId('ticket_type')
        .setPlaceholder('📋 Choose support type...')
        .addOptions([
          { label: 'Billing', description: 'Payment & billing issues', emoji: '💳', value: 'billing' },
          { label: 'Bug Report', description: 'Report a bug or issue', emoji: '🐛', value: 'bug' },
          { label: 'Appeal', description: 'Ban or mute appeals', emoji: '⚖️', value: 'appeal' },
          { label: 'Purchase', description: 'Purchase inquiries', emoji: '🛒', value: 'purchase' },
          { label: 'Partner', description: 'Partnership requests', emoji: '🤝', value: 'partner' },
          { label: 'Developer', description: 'Development requests', emoji: '💻', value: 'developer' },
          { label: 'General', description: 'General support', emoji: '📋', value: 'custom' },
        ]);

      const row = new ActionRowBuilder().addComponents(select);
      await channel.send({ embeds: [embed], components: [row] });
      return interaction.reply({ embeds: [success('Panel Sent', `Ticket panel sent to ${channel}`)], ephemeral: true });
    }

    if (sub === 'close') {
      const ticketData = findTicketByChannel(client, guild.id, interaction.channelId);
      if (!ticketData) return interaction.reply({ embeds: [error('Not a Ticket', 'This command must be used in a ticket channel.')], ephemeral: true });
      const { handleModal } = require('../../utils/ticketHandler');
      client.db.tickets.set(`${guild.id}.tickets.${ticketData.id}.status`, 'closed');
      client.db.tickets.set(`${guild.id}.tickets.${ticketData.id}.closedAt`, Date.now());
      await interaction.reply({ embeds: [info('Closing...', 'This ticket will be closed.')] });
      setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
    }

    if (sub === 'rename') {
      const newName = interaction.options.getString('name');
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
        return interaction.reply({ embeds: [error('No Permission', 'You need Manage Channels permission.')], ephemeral: true });
      }
      await interaction.channel.setName(newName).catch(() => {});
      return interaction.reply({ embeds: [success('Renamed', `Channel renamed to \`${newName}\``)] });
    }

    if (sub === 'add') {
      const user = interaction.options.getUser('user');
      await interaction.channel.permissionOverwrites.edit(user.id, {
        ViewChannel: true, SendMessages: true, ReadMessageHistory: true,
      });
      return interaction.reply({ embeds: [success('User Added', `${user} has been added to this ticket.`)] });
    }

    if (sub === 'remove') {
      const user = interaction.options.getUser('user');
      await interaction.channel.permissionOverwrites.edit(user.id, {
        ViewChannel: false,
      });
      return interaction.reply({ embeds: [success('User Removed', `${user} has been removed from this ticket.`)] });
    }

    if (sub === 'list') {
      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
        return interaction.reply({ embeds: [error('No Permission', 'Need Manage Channels.')], ephemeral: true });
      }
      const tickets = client.db.tickets.get(`${guild.id}.tickets`) || {};
      const open = Object.values(tickets).filter(t => t.status === 'open');
      if (!open.length) return interaction.reply({ embeds: [info('No Tickets', 'No open tickets found.')] });

      const lines = open.slice(0, 20).map(t => `🎫 \`${t.id}\` — <@${t.userId}> | Type: ${t.type} | Priority: ${t.priority || 'normal'}`);
      return interaction.reply({
        embeds: [new EmbedBuilder().setColor(COLORS.primary).setTitle(`🎫 Open Tickets (${open.length})`).setDescription(lines.join('\n')).setTimestamp()],
        ephemeral: true,
      });
    }
  },
};

function findTicketByChannel(client, guildId, channelId) {
  const tickets = client.db.tickets.get(`${guildId}.tickets`) || {};
  return Object.values(tickets).find(t => t.channelId === channelId) || null;
}
