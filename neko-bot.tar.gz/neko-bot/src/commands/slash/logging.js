const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { success, error, info } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('logging')
    .setDescription('Configure logging system')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(s => s.setName('setup')
      .setDescription('Setup a log channel for an event type')
      .addChannelOption(o => o.setName('channel').setDescription('Log channel').setRequired(true))
      .addStringOption(o => o.setName('event').setDescription('Event type').setRequired(true)
        .addChoices(
          { name: 'Join', value: 'join' }, { name: 'Leave', value: 'leave' },
          { name: 'Ban', value: 'ban' }, { name: 'Unban', value: 'unban' },
          { name: 'Message Delete', value: 'messageDelete' }, { name: 'Message Edit', value: 'messageEdit' },
          { name: 'Role Update', value: 'roleUpdate' }, { name: 'Nickname Update', value: 'nicknameUpdate' },
          { name: 'Invite Used', value: 'invite' }, { name: 'Warnings', value: 'warn' },
          { name: 'Kicks', value: 'kick' }, { name: 'Tickets', value: 'ticket' },
          { name: 'All Events (default)', value: 'default' },
        )
      )
    )
    .addSubcommand(s => s.setName('enable').setDescription('Enable logging'))
    .addSubcommand(s => s.setName('disable').setDescription('Disable logging'))
    .addSubcommand(s => s.setName('view').setDescription('View current log configuration')),
  cooldown: 5,
  async execute(client, interaction) {
    const sub = interaction.options.getSubcommand();
    const guild = interaction.guild;

    if (sub === 'setup') {
      const channel = interaction.options.getChannel('channel');
      const event = interaction.options.getString('event');
      client.db.logging.set(`${guild.id}.enabled`, true);
      client.db.logging.set(`${guild.id}.channels.${event}`, channel.id);
      return interaction.reply({ embeds: [success('Log Channel Set', `Event **${event}** → ${channel}`)], ephemeral: true });
    }

    if (sub === 'enable') {
      client.db.logging.set(`${guild.id}.enabled`, true);
      return interaction.reply({ embeds: [success('Logging Enabled', 'Logging is now active.')] });
    }

    if (sub === 'disable') {
      client.db.logging.set(`${guild.id}.enabled`, false);
      return interaction.reply({ embeds: [success('Logging Disabled', 'Logging has been paused.')] });
    }

    if (sub === 'view') {
      const data = client.db.logging.get(`${guild.id}`) || {};
      const channels = data.channels || {};
      const lines = Object.entries(channels).map(([evt, ch]) => `• **${evt}** → <#${ch}>`);
      return interaction.reply({
        embeds: [info('Log Configuration', `**Enabled:** ${data.enabled ? '✅' : '❌'}\n\n${lines.join('\n') || 'No channels configured'}`)],
        ephemeral: true,
      });
    }
  },
};
