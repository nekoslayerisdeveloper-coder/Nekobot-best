const { EmbedBuilder } = require('discord.js');
const { getLeaderboard } = require('../../utils/inviteTracker');
const { COLORS } = require('../../utils/embeds');

module.exports = {
  name: 'topinv',
  aliases: ['invlb', 'invitetop'],
  description: 'Show the top inviters leaderboard',
  usage: '-topinv',
  cooldown: 10,
  async execute(client, message, args) {
    const board = getLeaderboard(client, message.guild.id);

    if (!board.length) {
      return message.reply({ embeds: [
        new EmbedBuilder()
          .setColor(COLORS.neko)
          .setDescription('No invite data recorded yet.')
      ]});
    }

    const medals = ['🥇', '🥈', '🥉'];
    const lines = await Promise.all(board.map(async (entry, i) => {
      let tag = entry.userId;
      try {
        const user = await client.users.fetch(entry.userId);
        tag = user.tag;
      } catch {}
      const medal = medals[i] || `**#${i + 1}**`;
      return `${medal} \`${tag}\` — **${entry.net}** invites (${entry.regular} reg / ${entry.fake} fake / ${entry.leaves} left)`;
    }));

    const embed = new EmbedBuilder()
      .setColor(COLORS.gold)
      .setTitle(`🏆 Invite Leaderboard — ${message.guild.name}`)
      .setDescription(lines.join('\n'))
      .setThumbnail(message.guild.iconURL({ dynamic: true }))
      .setFooter({ text: 'NekoBot • Top 20 Inviters' })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};
