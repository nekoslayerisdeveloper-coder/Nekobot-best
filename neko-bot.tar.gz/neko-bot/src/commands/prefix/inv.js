const { EmbedBuilder } = require('discord.js');
const { getInviteData, getLeaderboard } = require('../../utils/inviteTracker');
const { error, COLORS } = require('../../utils/embeds');

module.exports = {
  name: 'inv',
  aliases: ['invites', 'invite'],
  description: 'Check invite stats for yourself or a user',
  usage: '-inv [@user]',
  cooldown: 5,
  async execute(client, message, args) {
    const target = message.mentions.users.first() || message.author;
    const member = message.guild.members.cache.get(target.id);

    const data = getInviteData(client, message.guild.id, target.id);

    const embed = new EmbedBuilder()
      .setColor(COLORS.neko)
      .setTitle(`📨 Invite Stats — ${target.username}`)
      .setThumbnail(target.displayAvatarURL({ dynamic: true }))
      .setDescription(`Here are the invite statistics for **${target.tag}**`)
      .addFields(
        { name: '✅ Regular', value: `\`${data.regular}\``, inline: true },
        { name: '❌ Fake', value: `\`${data.fake}\``, inline: true },
        { name: '🚪 Leaves', value: `\`${data.leaves}\``, inline: true },
        { name: '🎁 Bonus', value: `\`${data.bonus}\``, inline: true },
        { name: '🔄 Rejoins', value: `\`${data.rejoins}\``, inline: true },
        { name: '📊 Net Total', value: `\`${data.net}\``, inline: true },
      )
      .setFooter({ text: `NekoBot • ${message.guild.name}` })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};
