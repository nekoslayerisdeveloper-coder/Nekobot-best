const { logEvent } = require('./logSystem');

const spamMap = new Map();
const ghostPingMap = new Map();

async function automodCheck(client, message) {
  const guild = message.guild;
  const cfg = client.db.automod.get(`${guild.id}`) || {};
  if (!cfg.enabled) return;

  // Whitelisted roles
  const member = message.member;
  if (!member) return;
  const whitelist = cfg.whitelistRoles || [];
  if (member.roles.cache.some(r => whitelist.includes(r.id))) return;
  if (member.permissions.has('ManageMessages')) return;

  const warns = [];

  // Anti spam
  if (cfg.antiSpam?.enabled) {
    const key = `${guild.id}:${message.author.id}`;
    const now = Date.now();
    const userMsgs = spamMap.get(key) || [];
    userMsgs.push(now);
    const recent = userMsgs.filter(t => now - t < (cfg.antiSpam.interval || 5000));
    spamMap.set(key, recent);
    if (recent.length >= (cfg.antiSpam.limit || 5)) {
      warns.push({ reason: 'Spam detected', action: cfg.antiSpam.action || 'delete' });
      spamMap.set(key, []);
    }
  }

  // Anti link
  if (cfg.antiLink?.enabled) {
    const linkRegex = /https?:\/\/[^\s]+/gi;
    if (linkRegex.test(message.content)) {
      const allowedDomains = cfg.antiLink.allowed || [];
      const links = message.content.match(linkRegex) || [];
      const hasBlocked = links.some(l => !allowedDomains.some(d => l.includes(d)));
      if (hasBlocked) warns.push({ reason: 'Unauthorized link', action: cfg.antiLink.action || 'delete' });
    }
  }

  // Anti invite
  if (cfg.antiInvite?.enabled) {
    const inviteRegex = /(discord\.gg|discordapp\.com\/invite|discord\.com\/invite)\/[a-z0-9]+/gi;
    if (inviteRegex.test(message.content)) {
      warns.push({ reason: 'Discord invite link', action: cfg.antiInvite.action || 'delete' });
    }
  }

  // Anti caps (>70% caps, message > 10 chars)
  if (cfg.antiCaps?.enabled && message.content.length > 10) {
    const upper = message.content.replace(/[^A-Za-z]/g, '');
    const ratio = upper.replace(/[^A-Z]/g, '').length / (upper.length || 1);
    if (ratio > (cfg.antiCaps.threshold || 0.7)) {
      warns.push({ reason: 'Excessive caps', action: cfg.antiCaps.action || 'warn' });
    }
  }

  // Execute
  for (const w of warns) {
    if (w.action === 'delete' || w.action === 'warn') {
      await message.delete().catch(() => {});
    }
    if (w.action === 'warn' || w.action === 'mute') {
      // Auto-warn
      const warningsKey = `${guild.id}.${message.author.id}.warnings`;
      client.db.warnings.push(warningsKey, {
        reason: `[AutoMod] ${w.reason}`,
        time: Date.now(),
        mod: 'AutoMod',
      });
    }
    if (w.action === 'mute') {
      const muteRole = guild.roles.cache.get(cfg.muteRole);
      if (muteRole) await member.roles.add(muteRole).catch(() => {});
      setTimeout(async () => {
        if (muteRole) await member.roles.remove(muteRole).catch(() => {});
      }, cfg.antiSpam?.muteDuration || 60000);
    }
    if (w.action === 'kick') {
      await member.kick(w.reason).catch(() => {});
    }
    if (w.action === 'ban') {
      await member.ban({ reason: w.reason }).catch(() => {});
    }
    // Notify
    await message.channel.send({
      content: `<@${message.author.id}> ⚠️ **AutoMod:** ${w.reason}`,
    }).then(m => setTimeout(() => m.delete().catch(() => {}), 5000)).catch(() => {});

    await logEvent(client, guild, 'warn', {
      user: message.author.tag,
      mod: 'AutoMod',
      reason: w.reason,
    });
  }
}

module.exports = { automodCheck };
