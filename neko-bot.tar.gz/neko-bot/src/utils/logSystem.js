const { EmbedBuilder } = require('discord.js');
const { COLORS } = require('./embeds');

const EVENT_CONFIG = {
  join: {
    color: COLORS.success,
    title: '👋 Member Joined',
    fields: (d) => [
      { name: 'User', value: `${d.user} \`(${d.id})\``, inline: true },
      { name: 'Account Age', value: `${d.accountAge} days`, inline: true },
    ],
  },
  leave: {
    color: COLORS.error,
    title: '🚪 Member Left',
    fields: (d) => [
      { name: 'User', value: `${d.user} \`(${d.id})\``, inline: true },
    ],
  },
  ban: {
    color: 0x8B0000,
    title: '🔨 Member Banned',
    fields: (d) => [
      { name: 'User', value: `${d.user} \`(${d.id})\``, inline: true },
      { name: 'Reason', value: d.reason, inline: true },
    ],
  },
  unban: {
    color: COLORS.info,
    title: '🔓 Member Unbanned',
    fields: (d) => [
      { name: 'User', value: `${d.user} \`(${d.id})\``, inline: true },
    ],
  },
  messageDelete: {
    color: COLORS.error,
    title: '🗑️ Message Deleted',
    fields: (d) => [
      { name: 'Author', value: d.author, inline: true },
      { name: 'Channel', value: `#${d.channel}`, inline: true },
      { name: 'Content', value: d.content.slice(0, 1000) || '[empty]', inline: false },
    ],
  },
  messageEdit: {
    color: COLORS.warning,
    title: '✏️ Message Edited',
    fields: (d) => [
      { name: 'Author', value: d.author, inline: true },
      { name: 'Channel', value: `#${d.channel}`, inline: true },
      { name: 'Before', value: d.before.slice(0, 500) || '[empty]', inline: false },
      { name: 'After', value: d.after.slice(0, 500) || '[empty]', inline: false },
    ],
  },
  roleUpdate: {
    color: COLORS.gold,
    title: '🎭 Role Updated',
    fields: (d) => [
      { name: 'User', value: d.user, inline: true },
      { name: 'Added', value: d.added || 'None', inline: true },
      { name: 'Removed', value: d.removed || 'None', inline: true },
    ],
  },
  nicknameUpdate: {
    color: COLORS.info,
    title: '📝 Nickname Changed',
    fields: (d) => [
      { name: 'User', value: d.user, inline: true },
      { name: 'Before', value: d.before, inline: true },
      { name: 'After', value: d.after, inline: true },
    ],
  },
  invite: {
    color: COLORS.primary,
    title: '📨 Invite Used',
    fields: (d) => [
      { name: 'Joined', value: d.user, inline: true },
      { name: 'Inviter', value: d.inviter, inline: true },
      { name: 'Code', value: d.code, inline: true },
      { name: 'Fake?', value: d.fake ? '✅ Yes' : '❌ No', inline: true },
      { name: 'Rejoin?', value: d.rejoin ? '✅ Yes' : '❌ No', inline: true },
    ],
  },
  warn: {
    color: COLORS.warning,
    title: '⚠️ Member Warned',
    fields: (d) => [
      { name: 'User', value: d.user, inline: true },
      { name: 'Moderator', value: d.mod, inline: true },
      { name: 'Reason', value: d.reason, inline: false },
    ],
  },
  kick: {
    color: COLORS.warning,
    title: '👢 Member Kicked',
    fields: (d) => [
      { name: 'User', value: d.user, inline: true },
      { name: 'Moderator', value: d.mod, inline: true },
      { name: 'Reason', value: d.reason, inline: false },
    ],
  },
  antialt: {
    color: COLORS.error,
    title: '🛡️ Anti-Alt Kicked',
    fields: (d) => [
      { name: 'User', value: d.user, inline: true },
      { name: 'Account Age', value: `${d.age} days`, inline: true },
    ],
  },
  ticket: {
    color: COLORS.primary,
    title: '🎫 Ticket Event',
    fields: (d) => [
      { name: 'Action', value: d.action, inline: true },
      { name: 'User', value: d.user, inline: true },
      { name: 'Channel', value: d.channel || 'N/A', inline: true },
    ],
  },
};

async function logEvent(client, guild, eventType, data = {}) {
  const logData = client.db.logging.get(`${guild.id}`);
  if (!logData?.enabled) return;

  const channelId = logData.channels?.[eventType] || logData.channels?.default;
  if (!channelId) return;

  const channel = guild.channels.cache.get(channelId);
  if (!channel) return;

  const config = EVENT_CONFIG[eventType];
  if (!config) return;

  const embed = new EmbedBuilder()
    .setColor(config.color)
    .setTitle(config.title)
    .addFields(config.fields(data))
    .setTimestamp()
    .setFooter({ text: 'NekoBot Logging' });

  await channel.send({ embeds: [embed] }).catch(() => {});
}

module.exports = { logEvent };
