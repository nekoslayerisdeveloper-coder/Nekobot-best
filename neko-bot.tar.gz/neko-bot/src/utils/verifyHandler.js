const {
  ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder,
  ButtonBuilder, ButtonStyle
} = require('discord.js');
const { success, error } = require('./embeds');

async function handleButton(client, interaction, action, params) {
  const guild = interaction.guild;
  const config = client.db.verification.get(`${guild.id}`) || {};

  if (!config.enabled) return interaction.reply({ embeds: [error('Not Setup', 'Verification not enabled.')], ephemeral: true });

  // Check if already verified
  const member = interaction.member;
  if (config.verifiedRole && member.roles.cache.has(config.verifiedRole)) {
    return interaction.reply({ embeds: [error('Already Verified', 'You are already verified!')], ephemeral: true });
  }

  const method = config.method || 'button';

  if (method === 'button') {
    await grantVerification(client, interaction, config);
  }

  if (method === 'captcha') {
    const a = Math.floor(Math.random() * 9) + 1;
    const b = Math.floor(Math.random() * 9) + 1;
    const ops = ['+', '-', '*'];
    const op = ops[Math.floor(Math.random() * ops.length)];
    const answers = { '+': a + b, '-': a - b, '*': a * b };
    const answer = answers[op];

    client.db.verification.set(`${guild.id}.captcha.${interaction.user.id}`, { answer, expires: Date.now() + 120000 });

    const modal = new ModalBuilder()
      .setCustomId('verify_question:captcha')
      .setTitle('Captcha Verification')
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('answer')
            .setLabel(`Solve: ${a} ${op} ${b} = ?`)
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMaxLength(10)
        )
      );
    await interaction.showModal(modal);
  }

  if (method === 'question') {
    const q = config.question || 'What is the server name?';
    const modal = new ModalBuilder()
      .setCustomId('verify_question:question')
      .setTitle('Verification Question')
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('answer')
            .setLabel(q)
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMaxLength(200)
        )
      );
    await interaction.showModal(modal);
  }
}

async function handleModal(client, interaction, params) {
  const type = params[0];
  const guild = interaction.guild;
  const config = client.db.verification.get(`${guild.id}`) || {};
  const answer = interaction.fields.getTextInputValue('answer').trim();

  if (type === 'captcha') {
    const captcha = client.db.verification.get(`${guild.id}.captcha.${interaction.user.id}`);
    if (!captcha || Date.now() > captcha.expires) {
      return interaction.reply({ embeds: [error('Expired', 'Your captcha has expired. Try again.')], ephemeral: true });
    }
    if (parseInt(answer) !== captcha.answer) {
      return interaction.reply({ embeds: [error('Wrong Answer', 'Incorrect captcha. Try again.')], ephemeral: true });
    }
    client.db.verification.delete(`${guild.id}.captcha.${interaction.user.id}`);
    await grantVerification(client, interaction, config);
  }

  if (type === 'question') {
    const expected = (config.answer || '').toLowerCase().trim();
    if (expected && answer.toLowerCase() !== expected) {
      return interaction.reply({ embeds: [error('Wrong Answer', 'Incorrect answer. Try again.')], ephemeral: true });
    }
    await grantVerification(client, interaction, config);
  }
}

async function grantVerification(client, interaction, config) {
  const guild = interaction.guild;
  const member = interaction.member;

  if (config.verifiedRole) {
    const role = guild.roles.cache.get(config.verifiedRole);
    if (role) await member.roles.add(role).catch(() => {});
  }
  if (config.unverifiedRole) {
    const role = guild.roles.cache.get(config.unverifiedRole);
    if (role) await member.roles.remove(role).catch(() => {});
  }

  client.db.verification.set(`${guild.id}.verified.${interaction.user.id}`, { verifiedAt: Date.now() });
  await interaction.reply({ embeds: [success('Verified!', 'You have been successfully verified! Welcome.')], ephemeral: true });
}

module.exports = { handleButton, handleModal };
