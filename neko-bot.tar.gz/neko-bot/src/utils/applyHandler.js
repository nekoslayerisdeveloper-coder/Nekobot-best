const {
  ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder,
  ButtonBuilder, ButtonStyle, EmbedBuilder
} = require('discord.js');
const { success, error, info, COLORS } = require('./embeds');

const FORMS = {
  staff:     { label: 'Staff',      emoji: '👮', color: 0x3498DB },
  mod:       { label: 'Moderator',  emoji: '🛡️', color: 0x9B59B6 },
  admin:     { label: 'Admin',      emoji: '⚙️', color: 0xE74C3C },
  developer: { label: 'Developer',  emoji: '💻', color: 0xFF6B9D },
  builder:   { label: 'Builder',    emoji: '🏗️', color: 0xF39C12 },
  custom:    { label: 'Custom',     emoji: '📋', color: 0x95A5A6 },
};

const QUESTIONS = {
  staff:     ['What is your age?', 'Why do you want to be staff?', 'Previous experience?', 'How many hours can you dedicate?', 'Anything else?'],
  mod:       ['Your timezone?', 'Why do you want to be a moderator?', 'How would you handle a rule break?', 'Experience with moderation?', 'Discord username & age?'],
  admin:     ['Leadership experience?', 'Why should we choose you?', 'How would you improve this server?', 'Are you familiar with Discord admin tools?', 'Availability?'],
  developer: ['Programming languages you know?', 'GitHub or portfolio link?', 'What can you build for us?', 'Discord bot experience?', 'Availability per week?'],
  builder:   ['Building experience?', 'Portfolio or screenshots?', 'Games/styles you excel at?', 'Weekly hours available?', 'Why this server?'],
  custom:    ['Full name/tag?', 'Why are you applying?', 'What skills do you have?', 'Previous experience?', 'Anything to add?'],
};

async function handleSelect(client, interaction) {
  const formType = interaction.values[0];
  const questions = QUESTIONS[formType] || QUESTIONS.custom;
  const formInfo = FORMS[formType] || FORMS.custom;

  const modal = new ModalBuilder()
    .setCustomId(`apply_modal:${formType}`)
    .setTitle(`${formInfo.emoji} ${formInfo.label} Application`);

  for (let i = 0; i < Math.min(questions.length, 5); i++) {
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId(`q${i}`)
          .setLabel(questions[i])
          .setStyle(i === 1 || i === 2 ? TextInputStyle.Paragraph : TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(500)
      )
    );
  }

  await interaction.showModal(modal);
}

async function handleModal(client, interaction, params) {
  const formType = params[0];
  const questions = QUESTIONS[formType] || QUESTIONS.custom;
  const formInfo = FORMS[formType] || FORMS.custom;
  const guild = interaction.guild;
  const user = interaction.user;

  const config = client.db.applications.get(`${guild.id}.config`) || {};
  if (!config.reviewChannel) {
    return interaction.reply({ embeds: [error('Not Setup', 'Application review channel not configured.')], ephemeral: true });
  }

  const reviewChannel = guild.channels.cache.get(config.reviewChannel);
  if (!reviewChannel) return interaction.reply({ embeds: [error('Error', 'Review channel not found.')], ephemeral: true });

  const appId = Date.now().toString(36).toUpperCase();
  const answers = [];
  for (let i = 0; i < Math.min(questions.length, 5); i++) {
    try {
      answers.push(interaction.fields.getTextInputValue(`q${i}`));
    } catch { answers.push('N/A'); }
  }

  const appData = {
    id: appId,
    type: formType,
    userId: user.id,
    guildId: guild.id,
    answers,
    status: 'pending',
    submittedAt: Date.now(),
  };

  client.db.applications.set(`${guild.id}.apps.${appId}`, appData);

  const embed = new EmbedBuilder()
    .setColor(formInfo.color)
    .setTitle(`${formInfo.emoji} New ${formInfo.label} Application`)
    .setDescription(`Application from **${user.tag}** (${user.id})`)
    .addFields(questions.slice(0, 5).map((q, i) => ({
      name: `Q${i + 1}: ${q}`,
      value: answers[i] || 'No answer',
      inline: false,
    })))
    .addFields({ name: '🎫 App ID', value: appId, inline: true })
    .setThumbnail(user.displayAvatarURL())
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`apply_approve:${appId}`).setLabel('✅ Approve').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`apply_reject:${appId}`).setLabel('❌ Reject').setStyle(ButtonStyle.Danger),
  );

  await reviewChannel.send({ embeds: [embed], components: [row] });
  await interaction.reply({ embeds: [success('Application Submitted', `Your **${formInfo.label}** application has been submitted! ID: \`${appId}\``)], ephemeral: true });
}

async function handleButton(client, interaction, action, params) {
  const appId = params[0];
  const guild = interaction.guild;
  const appData = client.db.applications.get(`${guild.id}.apps.${appId}`);
  if (!appData) return interaction.reply({ embeds: [error('Not Found', 'Application not found.')], ephemeral: true });

  const formInfo = FORMS[appData.type] || FORMS.custom;

  if (action === 'apply_approve') {
    client.db.applications.set(`${guild.id}.apps.${appId}.status`, 'approved');
    client.db.applications.set(`${guild.id}.apps.${appId}.reviewer`, interaction.user.id);

    const config = client.db.applications.get(`${guild.id}.config`) || {};
    const member = await guild.members.fetch(appData.userId).catch(() => null);
    if (member && config.approveRole) {
      const role = guild.roles.cache.get(config.approveRole[appData.type] || config.approveRole);
      if (role) await member.roles.add(role).catch(() => {});
    }

    try {
      const user = await client.users.fetch(appData.userId);
      await user.send({ embeds: [success('Application Approved! 🎉', `Your **${formInfo.label}** application in **${guild.name}** has been **approved**! Welcome to the team!`)] }).catch(() => {});
    } catch {}

    await interaction.update({
      embeds: [interaction.message.embeds[0], success('Approved', `Approved by ${interaction.user}`)],
      components: [],
    });
  }

  if (action === 'apply_reject') {
    client.db.applications.set(`${guild.id}.apps.${appId}.status`, 'rejected');
    client.db.applications.set(`${guild.id}.apps.${appId}.reviewer`, interaction.user.id);

    try {
      const user = await client.users.fetch(appData.userId);
      await user.send({ embeds: [error('Application Rejected', `Your **${formInfo.label}** application in **${guild.name}** has been **rejected**. Better luck next time!`)] }).catch(() => {});
    } catch {}

    await interaction.update({
      embeds: [interaction.message.embeds[0], error('Rejected', `Rejected by ${interaction.user}`)],
      components: [],
    });
  }
}

module.exports = { handleSelect, handleModal, handleButton };
