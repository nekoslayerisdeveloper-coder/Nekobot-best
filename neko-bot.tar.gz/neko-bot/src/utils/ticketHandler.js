const {
  PermissionFlagsBits, ChannelType, EmbedBuilder, ButtonBuilder, ButtonStyle,
  ActionRowBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, StringSelectMenuBuilder
} = require('discord.js');
const { success, error, info, COLORS } = require('./embeds');
const { logEvent } = require('./logSystem');

const TICKET_TYPES = {
  billing:   { label: 'Billing',    emoji: '💳', color: 0xF1C40F },
  bug:       { label: 'Bug Report', emoji: '🐛', color: 0xE74C3C },
  appeal:    { label: 'Appeal',     emoji: '⚖️', color: 0x9B59B6 },
  purchase:  { label: 'Purchase',   emoji: '🛒', color: 0x2ECC71 },
  partner:   { label: 'Partner',    emoji: '🤝', color: 0x3498DB },
  developer: { label: 'Developer',  emoji: '💻', color: 0xFF6B9D },
  custom:    { label: 'General',    emoji: '📋', color: 0x95A5A6 },
};

async function createTicket(client, interaction, type = 'custom') {
  const guild = interaction.guild;
  const user = interaction.user;
  const config = client.db.tickets.get(`${guild.id}.config`) || {};

  if (!config.category) return interaction.reply({ embeds: [error('Not Setup', 'Ticket system not configured.')], ephemeral: true });

  // Cooldown
  const cooldownKey = `${guild.id}.cooldowns.${user.id}`;
  const lastTicket = client.db.tickets.get(cooldownKey) || 0;
  const cooldown = (config.cooldown || 5) * 60 * 1000;
  if (Date.now() - lastTicket < cooldown) {
    const remaining = Math.ceil((cooldown - (Date.now() - lastTicket)) / 60000);
    return interaction.reply({ embeds: [error('Cooldown', `Wait **${remaining}m** before opening another ticket.`)], ephemeral: true });
  }

  const existing = guild.channels.cache.find(c => c.topic?.includes(user.id) && c.name.includes('ticket'));
  if (existing && !config.allowMultiple) {
    return interaction.reply({ embeds: [error('Already Open', `You already have a ticket: ${existing}`)], ephemeral: true });
  }

  const ticketId = Date.now().toString(36).toUpperCase();
  const typeInfo = TICKET_TYPES[type] || TICKET_TYPES.custom;

  const category = guild.channels.cache.get(config.category);
  if (!category) return interaction.reply({ embeds: [error('Error', 'Ticket category not found.')], ephemeral: true });

  const channel = await guild.channels.create({
    name: `${typeInfo.emoji}-ticket-${ticketId}`,
    type: ChannelType.GuildText,
    parent: config.category,
    topic: `Ticket by ${user.tag} (${user.id}) | Type: ${type} | ID: ${ticketId}`,
    permissionOverwrites: [
      { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
      { id: user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
      ...(config.supportRoles || []).map(roleId => ({
        id: roleId,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageMessages],
      })),
    ],
  });

  const ticketData = {
    id: ticketId,
    type,
    userId: user.id,
    channelId: channel.id,
    guildId: guild.id,
    status: 'open',
    priority: 'normal',
    claimedBy: null,
    rating: null,
    closeReason: null,
    createdAt: Date.now(),
    messages: [],
  };

  client.db.tickets.set(`${guild.id}.tickets.${ticketId}`, ticketData);
  client.db.tickets.set(cooldownKey, Date.now());

  const embed = new EmbedBuilder()
    .setColor(typeInfo.color)
    .setTitle(`${typeInfo.emoji} ${typeInfo.label} Ticket — #${ticketId}`)
    .setDescription(`Hello ${user}! Our support team will be with you shortly.\n\nPlease describe your issue in detail.`)
    .addFields(
      { name: '📋 Type', value: typeInfo.label, inline: true },
      { name: '🎫 ID', value: ticketId, inline: true },
      { name: '⚡ Priority', value: 'Normal', inline: true },
    )
    .setTimestamp()
    .setFooter({ text: 'NekoBot Tickets' });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`ticket_claim:${ticketId}`).setLabel('Claim').setEmoji('✋').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`ticket_close:${ticketId}`).setLabel('Close').setEmoji('🔒').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(`ticket_priority:${ticketId}`).setLabel('Priority').setEmoji('⚡').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`ticket_transcript:${ticketId}`).setLabel('Transcript').setEmoji('📄').setStyle(ButtonStyle.Secondary),
  );

  const pingRoles = (config.supportRoles || []).map(id => `<@&${id}>`).join(' ');
  await channel.send({ content: `${user} ${pingRoles}`.trim(), embeds: [embed], components: [row] });

  await interaction.reply({ embeds: [success('Ticket Created', `Your ticket has been opened: ${channel}`)], ephemeral: true });

  await logEvent(client, guild, 'ticket', {
    action: 'Opened',
    user: user.tag,
    channel: channel.name,
  });
}

async function handleButton(client, interaction, action, params) {
  const ticketId = params[0];
  const guild = interaction.guild;
  const ticketData = client.db.tickets.get(`${guild.id}.tickets.${ticketId}`);

  if (action === 'ticket_claim') {
    if (ticketData?.claimedBy) {
      return interaction.reply({ embeds: [error('Already Claimed', `This ticket is claimed by <@${ticketData.claimedBy}>`)], ephemeral: true });
    }
    client.db.tickets.set(`${guild.id}.tickets.${ticketId}.claimedBy`, interaction.user.id);
    await interaction.reply({ embeds: [success('Ticket Claimed', `${interaction.user} has claimed this ticket.`)] });
  }

  if (action === 'ticket_close') {
    const modal = new ModalBuilder()
      .setCustomId(`ticket_close_reason:${ticketId}`)
      .setTitle('Close Ticket')
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('reason')
            .setLabel('Reason for closing')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder('Enter close reason...')
            .setRequired(false)
        )
      );
    await interaction.showModal(modal);
  }

  if (action === 'ticket_priority') {
    const priorities = ['low', 'normal', 'high', 'urgent'];
    const current = ticketData?.priority || 'normal';
    const next = priorities[(priorities.indexOf(current) + 1) % priorities.length];
    const colors = { low: '🟢', normal: '🟡', high: '🟠', urgent: '🔴' };
    client.db.tickets.set(`${guild.id}.tickets.${ticketId}.priority`, next);
    await interaction.reply({ embeds: [info('Priority Updated', `Priority set to ${colors[next]} **${next.toUpperCase()}**`)] });
  }

  if (action === 'ticket_transcript') {
    await generateTranscript(client, interaction, ticketId);
  }

  if (action === 'ticket_reopen') {
    client.db.tickets.set(`${guild.id}.tickets.${ticketId}.status`, 'open');
    const channel = guild.channels.cache.get(ticketData?.channelId);
    if (channel) {
      const userId = ticketData?.userId;
      await channel.permissionOverwrites.edit(userId, { ViewChannel: true, SendMessages: true }).catch(() => {});
    }
    await interaction.reply({ embeds: [success('Ticket Reopened', 'This ticket has been reopened.')] });
  }
}

async function handleModal(client, interaction, params) {
  const ticketId = params[0];
  const reason = interaction.fields.getTextInputValue('reason') || 'No reason provided';
  const guild = interaction.guild;

  const ticketData = client.db.tickets.get(`${guild.id}.tickets.${ticketId}`);
  if (!ticketData) return interaction.reply({ embeds: [error('Not Found', 'Ticket not found.')], ephemeral: true });

  client.db.tickets.set(`${guild.id}.tickets.${ticketId}.status`, 'closed');
  client.db.tickets.set(`${guild.id}.tickets.${ticketId}.closeReason`, reason);
  client.db.tickets.set(`${guild.id}.tickets.${ticketId}.closedAt`, Date.now());

  const channel = interaction.channel;

  const ratingRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`ticket_rate:${ticketId}:1`).setLabel('⭐').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`ticket_rate:${ticketId}:2`).setLabel('⭐⭐').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`ticket_rate:${ticketId}:3`).setLabel('⭐⭐⭐').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`ticket_rate:${ticketId}:4`).setLabel('⭐⭐⭐⭐').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`ticket_rate:${ticketId}:5`).setLabel('⭐⭐⭐⭐⭐').setStyle(ButtonStyle.Secondary),
  );

  const reopenRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`ticket_reopen:${ticketId}`).setLabel('Reopen').setEmoji('🔓').setStyle(ButtonStyle.Success),
  );

  await interaction.reply({
    embeds: [info('Ticket Closed', `Closed by ${interaction.user}\n**Reason:** ${reason}\n\nPlease rate your support experience!`)],
    components: [ratingRow, reopenRow],
  });

  // Remove user permissions
  await channel.permissionOverwrites.edit(ticketData.userId, { SendMessages: false }).catch(() => {});

  await logEvent(client, guild, 'ticket', {
    action: 'Closed',
    user: interaction.user.tag,
    channel: channel.name,
  });

  // Auto archive after 24h
  setTimeout(async () => {
    const current = client.db.tickets.get(`${guild.id}.tickets.${ticketId}`);
    if (current?.status === 'closed') {
      await channel.delete('Auto archived').catch(() => {});
    }
  }, 24 * 60 * 60 * 1000);
}

async function handleSelect(client, interaction) {
  const type = interaction.values[0];
  await createTicket(client, interaction, type);
}

async function generateTranscript(client, interaction, ticketId) {
  const guild = interaction.guild;
  const channel = interaction.channel;

  const messages = await channel.messages.fetch({ limit: 100 });
  const sorted = [...messages.values()].reverse();

  let transcript = `=== NekoBot Ticket Transcript ===\nTicket ID: ${ticketId}\nGuild: ${guild.name}\nDate: ${new Date().toISOString()}\n\n`;
  for (const msg of sorted) {
    if (msg.author.bot && !msg.content) continue;
    transcript += `[${new Date(msg.createdTimestamp).toISOString()}] ${msg.author.tag}: ${msg.content || '[embed/attachment]'}\n`;
  }

  const config = client.db.tickets.get(`${guild.id}.config`) || {};
  if (config.transcriptChannel) {
    const tChannel = guild.channels.cache.get(config.transcriptChannel);
    if (tChannel) {
      const { AttachmentBuilder } = require('discord.js');
      const buf = Buffer.from(transcript, 'utf8');
      const att = new AttachmentBuilder(buf, { name: `transcript-${ticketId}.txt` });
      await tChannel.send({ content: `📄 Transcript for ticket \`${ticketId}\``, files: [att] }).catch(() => {});
    }
  }

  await interaction.reply({ embeds: [success('Transcript Generated', 'Transcript sent to the log channel.')], ephemeral: true });
}

module.exports = { createTicket, handleButton, handleModal, handleSelect };
