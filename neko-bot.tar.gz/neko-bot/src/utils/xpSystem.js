const cooldowns = new Map();

function getXPForLevel(level) {
  return 100 * (level ** 2) + 50 * level + 100;
}

function getLevelFromXP(xp) {
  let level = 0;
  while (xp >= getXPForLevel(level)) {
    xp -= getXPForLevel(level);
    level++;
  }
  return level;
}

async function addXP(client, message) {
  const guild = message.guild;
  const cfg = client.db.config.get(`${guild.id}.levels`) || {};
  if (!cfg.enabled) return;

  const key = `${guild.id}:${message.author.id}`;
  const now = Date.now();
  const cooldown = (cfg.cooldown || 60) * 1000;

  if (cooldowns.has(key) && now - cooldowns.get(key) < cooldown) return;
  cooldowns.set(key, now);

  const min = cfg.minXP || 15;
  const max = cfg.maxXP || 25;
  const earned = Math.floor(Math.random() * (max - min + 1)) + min;

  const dataKey = `${guild.id}.${message.author.id}`;
  const before = client.db.levels.get(`${dataKey}.xp`) || 0;
  client.db.levels.add(`${dataKey}.xp`, earned);

  const totalXP = before + earned;
  const oldLevel = getLevelFromXP(before);
  const newLevel = getLevelFromXP(totalXP);

  if (newLevel > oldLevel) {
    client.db.levels.set(`${dataKey}.level`, newLevel);

    // Level up message
    const announceChannelId = cfg.channel;
    const channel = announceChannelId ? guild.channels.cache.get(announceChannelId) : message.channel;
    if (channel) {
      const { EmbedBuilder } = require('discord.js');
      const embed = new EmbedBuilder()
        .setColor(0xFF6B9D)
        .setTitle('🎉 Level Up!')
        .setDescription(`<@${message.author.id}> reached **Level ${newLevel}**! Keep chatting!`)
        .setThumbnail(message.author.displayAvatarURL())
        .setTimestamp();
      await channel.send({ embeds: [embed] }).catch(() => {});
    }

    // Role rewards
    const rewards = client.db.roles.get(`${guild.id}.levelRewards`) || [];
    for (const reward of rewards) {
      if (newLevel >= reward.level) {
        const member = message.member;
        const role = guild.roles.cache.get(reward.roleId);
        if (role && !member.roles.cache.has(reward.roleId)) {
          await member.roles.add(role).catch(() => {});
        }
      }
    }
  }
}

function getLeaderboard(client, guildId) {
  const all = client.db.levels.get(guildId) || {};
  return Object.entries(all)
    .filter(([, v]) => v && typeof v === 'object')
    .map(([userId, data]) => ({
      userId,
      xp: data.xp || 0,
      level: getLevelFromXP(data.xp || 0),
    }))
    .sort((a, b) => b.xp - a.xp)
    .slice(0, 20);
}

function getUserData(client, guildId, userId) {
  const data = client.db.levels.get(`${guildId}.${userId}`) || {};
  const xp = data.xp || 0;
  const level = getLevelFromXP(xp);
  const xpForCurrent = getXPForLevel(level);
  let xpProgress = xp;
  for (let i = 0; i < level; i++) xpProgress -= getXPForLevel(i);
  return { xp, level, xpProgress, xpNeeded: xpForCurrent };
}

module.exports = { addXP, getLeaderboard, getUserData, getLevelFromXP, getXPForLevel };
