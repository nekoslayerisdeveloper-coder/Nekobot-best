const { EmbedBuilder } = require('discord.js');

const COLORS = {
  primary:  0x9B59B6,
  success:  0x2ECC71,
  error:    0xE74C3C,
  warning:  0xF39C12,
  info:     0x3498DB,
  dark:     0x2C2F33,
  gold:     0xF1C40F,
  neko:     0xFF6B9D,
};

const FOOTER = { text: 'NekoBot • Premium', iconURL: 'https://cdn.discordapp.com/emojis/neko.png' };

function base(color = COLORS.primary) {
  return new EmbedBuilder()
    .setColor(color)
    .setTimestamp();
}

function success(title, description, fields = []) {
  const e = base(COLORS.success)
    .setTitle(`✅ ${title}`)
    .setDescription(description);
  if (fields.length) e.addFields(fields);
  return e;
}

function error(title, description) {
  return base(COLORS.error)
    .setTitle(`❌ ${title}`)
    .setDescription(description);
}

function warning(title, description) {
  return base(COLORS.warning)
    .setTitle(`⚠️ ${title}`)
    .setDescription(description);
}

function info(title, description, fields = []) {
  const e = base(COLORS.info)
    .setTitle(`ℹ️ ${title}`)
    .setDescription(description);
  if (fields.length) e.addFields(fields);
  return e;
}

function neko(title, description, fields = []) {
  const e = base(COLORS.neko)
    .setTitle(`🐱 ${title}`)
    .setDescription(description);
  if (fields.length) e.addFields(fields);
  return e;
}

function dark(title, description, fields = []) {
  const e = base(COLORS.dark)
    .setTitle(title)
    .setDescription(description);
  if (fields.length) e.addFields(fields);
  return e;
}

function premium(title, description, thumbnail = null) {
  const e = base(COLORS.gold)
    .setTitle(`⭐ ${title}`)
    .setDescription(description);
  if (thumbnail) e.setThumbnail(thumbnail);
  return e;
}

function cooldown(seconds) {
  return error('Cooldown Active', `Please wait **${seconds}s** before using this command again.`);
}

function noPermission(perm) {
  return error('No Permission', `You need the **${perm}** permission to use this command.`);
}

function ownerOnly() {
  return error('Owner Only', 'This command is restricted to the bot owner.');
}

module.exports = { success, error, warning, info, neko, dark, premium, cooldown, noPermission, ownerOnly, COLORS, base };
