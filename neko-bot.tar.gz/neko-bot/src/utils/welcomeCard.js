const { EmbedBuilder } = require('discord.js');

async function sendWelcomeCard(client, member) {
  const guild = member.guild;
  const data = client.db.welcome.get(`${guild.id}`) || {};
  if (!data.enabled || !data.channel) return;

  const channel = guild.channels.cache.get(data.channel);
  if (!channel) return;

  const memberCount = guild.memberCount;
  let description = (data.message || 'Welcome to **{server}**, {user}! You are member **#{count}**.!')
    .replace('{user}', `<@${member.id}>`)
    .replace('{server}', guild.name)
    .replace('{count}', memberCount)
    .replace('{tag}', member.user.tag);

  const embed = new EmbedBuilder()
    .setColor(data.color || 0xFF6B9D)
    .setTitle(data.title || `Welcome to ${guild.name}!`)
    .setDescription(description)
    .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))
    .setImage(data.banner || null)
    .addFields(
      { name: '👤 User', value: member.user.tag, inline: true },
      { name: '📊 Member Count', value: `#${memberCount}`, inline: true },
      { name: '📅 Account Created', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true }
    )
    .setTimestamp()
    .setFooter({ text: guild.name, iconURL: guild.iconURL() });

  await channel.send({ content: `<@${member.id}>`, embeds: [embed] }).catch(() => {});
}

async function sendLeaveCard(client, member) {
  const guild = member.guild;
  const data = client.db.welcome.get(`${guild.id}`) || {};
  if (!data.leaveEnabled || !data.leaveChannel) return;

  const channel = guild.channels.cache.get(data.leaveChannel);
  if (!channel) return;

  let description = (data.leaveMessage || '**{tag}** has left the server. Goodbye!')
    .replace('{user}', `<@${member.id}>`)
    .replace('{tag}', member.user.tag)
    .replace('{server}', guild.name);

  const embed = new EmbedBuilder()
    .setColor(data.leaveColor || 0xE74C3C)
    .setTitle(data.leaveTitle || `Goodbye!`)
    .setDescription(description)
    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
    .addFields(
      { name: '👤 User', value: member.user.tag, inline: true },
      { name: '🕒 Joined', value: member.joinedAt ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : 'Unknown', inline: true }
    )
    .setTimestamp();

  await channel.send({ embeds: [embed] }).catch(() => {});
}

module.exports = { sendWelcomeCard, sendLeaveCard };
