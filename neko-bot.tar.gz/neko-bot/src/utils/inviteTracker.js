const { logEvent } = require('./logSystem');

async function trackJoinInvite(client, member) {
  const guild = member.guild;
  try {
    const cachedInvites = client.inviteCache.get(guild.id) || new Map();
    const newInvites = await guild.invites.fetch();
    client.inviteCache.set(guild.id, new Map(newInvites.map(i => [i.code, i.uses])));

    const usedInvite = newInvites.find(i => {
      const oldUses = cachedInvites.get(i.code) || 0;
      return i.uses > oldUses;
    });

    const guildKey = guild.id;
    const memberKey = `${guildKey}.${member.id}`;

    // Check if member was here before (rejoin)
    const memberData = client.db.invites.get(memberKey) || {};
    const isRejoin = !!memberData.joinedBefore;

    client.db.invites.set(`${memberKey}.joinedBefore`, true);
    client.db.invites.set(`${memberKey}.joinedAt`, Date.now());

    if (!usedInvite) {
      // Vanity or unknown invite
      client.db.invites.set(`${memberKey}.inviter`, 'vanity');
      return;
    }

    const inviterId = usedInvite.inviter?.id;
    if (!inviterId) return;

    client.db.invites.set(`${memberKey}.inviter`, inviterId);
    client.db.invites.set(`${memberKey}.inviteCode`, usedInvite.code);

    const inviterKey = `${guildKey}.${inviterId}`;
    const inviterData = client.db.invites.get(inviterKey) || {};

    // Determine if fake invite (account < 7 days old)
    const accountAge = (Date.now() - member.user.createdTimestamp) / 86400000;
    const isFake = accountAge < 7;

    if (isFake) {
      client.db.invites.set(`${inviterKey}.fake`, (inviterData.fake || 0) + 1);
    } else if (isRejoin) {
      client.db.invites.set(`${inviterKey}.rejoins`, (inviterData.rejoins || 0) + 1);
    } else {
      client.db.invites.set(`${inviterKey}.regular`, (inviterData.regular || 0) + 1);
    }

    const inviterDataUpdated = client.db.invites.get(inviterKey);
    const net = getNetInvites(inviterDataUpdated);
    client.db.invites.set(`${inviterKey}.net`, net);

    // Check invite role rewards
    await checkInviteRewards(client, guild, inviterId, net);

    // Log invite
    await logEvent(client, guild, 'invite', {
      user: member.user.tag,
      inviter: usedInvite.inviter?.tag || 'Unknown',
      code: usedInvite.code,
      fake: isFake,
      rejoin: isRejoin,
    });
  } catch {}
}

async function trackLeaveInvite(client, member) {
  const guild = member.guild;
  const memberKey = `${guild.id}.${member.id}`;
  const inviterId = client.db.invites.get(`${memberKey}.inviter`);
  if (!inviterId || inviterId === 'vanity') return;

  const inviterKey = `${guild.id}.${inviterId}`;
  const inviterData = client.db.invites.get(inviterKey) || {};
  client.db.invites.set(`${inviterKey}.leaves`, (inviterData.leaves || 0) + 1);

  const net = getNetInvites(client.db.invites.get(inviterKey));
  client.db.invites.set(`${inviterKey}.net`, net);
}

function getNetInvites(data = {}) {
  const regular = data.regular || 0;
  const fake = data.fake || 0;
  const leaves = data.leaves || 0;
  const bonus = data.bonus || 0;
  return Math.max(0, regular - fake - leaves + bonus);
}

async function checkInviteRewards(client, guild, userId, net) {
  const rewards = client.db.roles.get(`${guild.id}.inviteRewards`) || [];
  for (const reward of rewards) {
    if (net >= reward.count) {
      const member = await guild.members.fetch(userId).catch(() => null);
      if (member && !member.roles.cache.has(reward.roleId)) {
        const role = guild.roles.cache.get(reward.roleId);
        if (role) await member.roles.add(role).catch(() => {});
      }
    }
  }
}

function getInviteData(client, guildId, userId) {
  const data = client.db.invites.get(`${guildId}.${userId}`) || {};
  return {
    regular: data.regular || 0,
    fake: data.fake || 0,
    leaves: data.leaves || 0,
    bonus: data.bonus || 0,
    rejoins: data.rejoins || 0,
    net: data.net || 0,
  };
}

function getLeaderboard(client, guildId) {
  const all = client.db.invites.get(guildId) || {};
  return Object.entries(all)
    .filter(([, v]) => v && typeof v === 'object' && 'net' in v)
    .map(([userId, data]) => ({
      userId,
      regular: data.regular || 0,
      fake: data.fake || 0,
      leaves: data.leaves || 0,
      bonus: data.bonus || 0,
      rejoins: data.rejoins || 0,
      net: data.net || 0,
    }))
    .sort((a, b) => b.net - a.net)
    .slice(0, 20);
}

module.exports = { trackJoinInvite, trackLeaveInvite, getInviteData, getLeaderboard, getNetInvites };
