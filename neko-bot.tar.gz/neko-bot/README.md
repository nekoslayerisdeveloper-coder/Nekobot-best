# 🐱 NekoBot — Ultra Advanced Premium Discord Bot

> **Owner:** NekoSlayer | **Version:** 2.0.0 | **Built with:** discord.js v14

---

## ✨ Features

| System | Commands | Description |
|--------|----------|-------------|
| 📨 Invite Tracker | `-inv`, `-topinv` | Track regular, fake, leave, bonus, rejoins, net |
| 🤖 AI System | `/ai ask/image/code/fix/explain/summarize/translate/serverhelp` | GPT-4o + DALL-E 3 |
| 🎫 Ticket System | `/ticket panel/setup/close/rename/add/remove/list` | Full ticket lifecycle with transcripts |
| 📋 Applications | `/apply create/setup/list/review` | Staff/Mod/Admin/Dev/Builder/Custom forms |
| 🔐 Verification | `/verify setup/panel/disable` | Button / Captcha / Question methods |
| 🛡️ AutoMod | `/automod setup/antispam/antilink/antiinvite/anticaps/antialt` | Auto punishments |
| ⭐ Levels | `/level rank/leaderboard/setup/addrole/removerole/setxp` | XP + role rewards |
| 💰 Economy | `/economy balance/daily/work/transfer/shop/buy/inventory` | Full economy system |
| 📊 Dashboard | `/dashboard` | Real-time server overview |
| 🖥️ VPS Panel | `/server add/remove/list/view` | Encrypted server storage |
| 📦 Backups | `/backup create/list/status` | Auto + manual encrypted backups |
| 📝 Logging | `/logging setup/enable/disable/view` | Full event logging |
| 👋 Welcome | `/welcome setup/leave/disable/test` | Animated welcome/leave cards |
| ⚠️ Warnings | `/warn add/list/remove/clear` | Warning system |
| ⚔️ Moderation | `/mod ban/kick/timeout/unban/purge/slowmode` | Full mod toolkit |
| 🎁 Invite Rewards | `/invitereward add/remove/list/bonus` | Role rewards for inviting |
| 👑 Owner Panel | `/owner eval/broadcast/stats/servercount/backup/restart/shutdown` | NekoSlayer only |

---

## 🚀 Quick Start

### 1. Prerequisites
- Node.js 18+ ([download](https://nodejs.org))
- A Discord Bot Token ([discord.dev](https://discord.com/developers/applications))
- OpenAI API Key (optional, for AI features)

### 2. Install Dependencies
```bash
npm install
```

### 3. Configure Environment
```bash
cp .env.example .env
```
Edit `.env` with your values:
```env
BOT_TOKEN=your_token_here
CLIENT_ID=your_bot_client_id
OWNER_ID=your_discord_user_id
DB_ENCRYPTION_KEY=your_32_char_secret_key
OPENAI_API_KEY=your_openai_key  # Optional
```

### 4. Deploy Slash Commands
```bash
npm run deploy
```

### 5. Start the Bot
```bash
npm start
# or for development with auto-restart:
npm run dev
```

---

## 🗄️ Database System

NekoBot uses a **custom JSON database engine** with:
- 🔒 **AES-256-CBC encryption** for sensitive data (hosting panel)
- 💾 **Auto-save** every 5 seconds (only when dirty)
- 📦 **Auto backups** on a configurable interval
- 🔧 **Corruption recovery** — auto-restores from latest backup
- ⚡ **In-memory cache** — zero file reads during operation
- 🗜️ **Daily optimization** — file size reduction

Database files are stored in `/data/`, backups in `/backups/`.

---

## 📁 Project Structure

```
neko-bot/
├── src/
│   ├── index.js                  # Entry point
│   ├── structures/
│   │   ├── Client.js             # Extended Discord client
│   │   ├── Database.js           # JSON DB engine
│   │   └── Logger.js             # Colored logger
│   ├── commands/
│   │   ├── prefix/               # Prefix commands (-inv, -topinv)
│   │   └── slash/                # Slash commands (all /commands)
│   ├── events/                   # Discord.js event handlers
│   ├── handlers/
│   │   ├── commandHandler.js     # Loads all commands
│   │   ├── eventHandler.js       # Loads all events
│   │   └── deployCommands.js     # Deploys slash commands
│   └── utils/
│       ├── embeds.js             # Embed builder utilities
│       ├── inviteTracker.js      # Invite tracking logic
│       ├── xpSystem.js           # XP/Level calculations
│       ├── automod.js            # AutoMod checks
│       ├── logSystem.js          # Event logging
│       ├── welcomeCard.js        # Welcome/leave cards
│       ├── ticketHandler.js      # Ticket button/modal handlers
│       ├── applyHandler.js       # Application handlers
│       └── verifyHandler.js      # Verification handlers
├── data/                         # JSON database files (auto-created)
├── backups/                      # Database backups (auto-created)
├── logs/                         # Log files (auto-created)
├── assets/                       # Static assets
├── .env.example                  # Environment template
├── package.json
└── README.md
```

---

## ⚙️ Setup Guides

### Ticket System
1. Create a category for tickets in Discord
2. Run `/ticket setup` — select the category + support role
3. Run `/ticket panel` in your support channel
4. Users select a ticket type from the dropdown

### Invite Tracker
- Works automatically when bot joins
- Use `-inv` to check your invites
- Use `-topinv` for the leaderboard
- Set rewards: `/invitereward add <count> <role>`

### Level System
1. `/level setup enabled:True` to enable
2. Optionally set a channel for level-up announcements
3. Add role rewards: `/level addrole level:5 role:@Regular`

### AutoMod
1. `/automod setup` — enables defaults (anti-spam, anti-invite, anti-caps)
2. Customize: `/automod antispam enabled:True limit:5 action:mute`
3. Set mute role: `/automod muterole role:@Muted`
4. Whitelist staff: `/automod whitelist role:@Staff`

### AI System
- Requires `OPENAI_API_KEY` in `.env`
- `/ai ask` — general questions
- `/ai image` — generates images with DALL-E 3
- `/ai code` — generate code in any language
- `/ai fix` — debug and fix code

### Verification
1. `/verify setup method:button verified_role:@Member`
2. `/verify panel` — sends the verify panel

---

## 🤖 Bot Status Rotation

Rotates every 10 seconds:
- `Watching X Servers`
- `Watching Owner: NekoSlayer`
- `Watching -inv`
- `Watching /cmds`
- `Watching Ticket Support`
- `Watching AI Enabled`
- `Watching VPS System Enabled`

---

## 🔒 Security Notes

- The hosting panel database is **encrypted** with AES-256-CBC
- Change `DB_ENCRYPTION_KEY` to a unique 32-character string
- Keep your `.env` file secret — never commit it to git
- `/owner eval` is restricted to `OWNER_ID` only

---

## 📦 Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `BOT_TOKEN` | ✅ | Your Discord bot token |
| `CLIENT_ID` | ✅ | Bot's application/client ID |
| `OWNER_ID` | ✅ | Your Discord user ID (NekoSlayer) |
| `DB_ENCRYPTION_KEY` | ✅ | 32-char encryption key for sensitive data |
| `OPENAI_API_KEY` | ❌ | OpenAI key for AI features |
| `AI_MODEL` | ❌ | AI model (default: gpt-4o) |
| `IMAGE_MODEL` | ❌ | Image model (default: dall-e-3) |
| `BACKUP_INTERVAL` | ❌ | Backup interval in minutes (default: 60) |
| `MAX_BACKUPS` | ❌ | Max backups to keep per DB (default: 24) |
| `PREFIX` | ❌ | Command prefix (default: -) |
| `LOG_LEVEL` | ❌ | Log level: debug/info/warn/error |

---

## 🐱 Made with ❤️ by NekoSlayer
