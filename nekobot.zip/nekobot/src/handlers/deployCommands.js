'use strict';

require('dotenv').config();
const { REST, Routes } = require('@discordjs/rest');
const fs = require('fs');
const path = require('path');
const chalk = require('chalk');

async function deployCommands() {
  const commands = [];
  const commandsDir = path.join(__dirname, '..', 'commands');
  const categories = fs.readdirSync(commandsDir).filter(f =>
    fs.statSync(path.join(commandsDir, f)).isDirectory()
  );

  for (const cat of categories) {
    const files = fs.readdirSync(path.join(commandsDir, cat)).filter(f => f.endsWith('.js'));
    for (const file of files) {
      try {
        const cmd = require(path.join(commandsDir, cat, file));
        if (cmd.data) commands.push(cmd.data.toJSON());
      } catch (e) {
        console.error(chalk.red(`Failed to load ${file}: ${e.message}`));
      }
    }
  }

  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

  try {
    console.log(chalk.cyan(`Deploying ${commands.length} slash commands...`));
    const guildId = process.env.GUILD_ID;
    if (guildId) {
      await rest.put(Routes.applicationGuildCommands(process.env.CLIENT_ID, guildId), { body: commands });
      console.log(chalk.green(`✓ Deployed ${commands.length} commands to guild ${guildId} (instant)`));
    } else {
      await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: commands });
      console.log(chalk.green(`✓ Deployed ${commands.length} commands globally (up to 1hr propagation)`));
    }
  } catch (err) {
    console.error(chalk.red('Deploy failed:'), err);
    process.exit(1);
  }
}

deployCommands();
