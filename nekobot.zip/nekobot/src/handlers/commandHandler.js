'use strict';

const fs = require('fs');
const path = require('path');
const { Logger } = require('../utils/logger');

class CommandHandler {
  constructor(client) {
    this.client = client;
    this.commandsDir = path.join(__dirname, '..', 'commands');
  }

  async loadCommands() {
    const categories = fs.readdirSync(this.commandsDir).filter(f =>
      fs.statSync(path.join(this.commandsDir, f)).isDirectory()
    );

    for (const category of categories) {
      const categoryPath = path.join(this.commandsDir, category);
      const files = fs.readdirSync(categoryPath).filter(f => f.endsWith('.js'));

      for (const file of files) {
        try {
          const command = require(path.join(categoryPath, file));
          if (!command.data || !command.execute) {
            Logger.warn('CommandHandler', `Skipping ${file}: missing data or execute`);
            continue;
          }
          this.client.commands.set(command.data.name, command);
          if (command.aliases) {
            for (const alias of command.aliases) {
              this.client.aliases.set(alias, command.data.name);
            }
          }
          Logger.debug('CommandHandler', `Loaded command: ${command.data.name}`);
        } catch (err) {
          Logger.error('CommandHandler', `Failed to load ${file}:`, err.message);
        }
      }
    }

    // Load plugin commands
    if (this.client.pluginSystem) {
      const pluginCommands = this.client.pluginSystem.getCommands();
      for (const [name, cmd] of pluginCommands) {
        this.client.commands.set(name, cmd);
      }
    }
  }

  async reloadCommand(name) {
    const command = this.client.commands.get(name);
    if (!command) throw new Error(`Command "${name}" not found`);

    const categories = fs.readdirSync(this.commandsDir);
    for (const cat of categories) {
      const file = path.join(this.commandsDir, cat, `${name}.js`);
      if (fs.existsSync(file)) {
        delete require.cache[require.resolve(file)];
        const reloaded = require(file);
        this.client.commands.set(name, reloaded);
        Logger.info('CommandHandler', `Reloaded command: ${name}`);
        return reloaded;
      }
    }
    throw new Error(`Command file for "${name}" not found`);
  }

  getCommandList() {
    const list = {};
    for (const [name, cmd] of this.client.commands) {
      const cat = cmd.category || 'misc';
      if (!list[cat]) list[cat] = [];
      list[cat].push({
        name,
        description: cmd.data.description,
        permissions: cmd.permissions || [],
        aliases: cmd.aliases || [],
        examples: cmd.examples || [],
        premium: cmd.premium || false,
      });
    }
    return list;
  }
}

module.exports = { CommandHandler };
