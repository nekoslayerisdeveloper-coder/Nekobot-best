'use strict';

const fs = require('fs');
const path = require('path');
const { Logger } = require('../utils/logger');

class EventHandler {
  constructor(client) {
    this.client = client;
    this.eventsDir = path.join(__dirname, '..', 'events');
  }

  async loadEvents() {
    const files = fs.readdirSync(this.eventsDir).filter(f => f.endsWith('.js'));
    for (const file of files) {
      try {
        const event = require(path.join(this.eventsDir, file));
        if (!event.name || !event.execute) {
          Logger.warn('EventHandler', `Skipping event ${file}: missing name or execute`);
          continue;
        }
        const handler = (...args) => event.execute(this.client, ...args);
        if (event.once) {
          this.client.once(event.name, handler);
        } else {
          this.client.on(event.name, handler);
        }
        Logger.debug('EventHandler', `Registered event: ${event.name}`);
      } catch (err) {
        Logger.error('EventHandler', `Failed to load event ${file}:`, err.message);
      }
    }
  }
}

module.exports = { EventHandler };
