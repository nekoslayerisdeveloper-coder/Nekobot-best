'use strict';

const {
  ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ChannelType, PermissionFlagsBits, StringSelectMenuBuilder
} = require('discord.js');
const { Embed } = require('../utils/embed');
const { Logger } = require('../utils/logger');
const { v4: uuidv4 } = require('uuid');

const TICKET_CATEGORIES = {
  billing:     { label: 'Billing',     emoji: '💳', description: 'Payment & subscription issues' },
  support:     { label: 'Support',     emoji: '🛠️', description: 'General support requests' },
  report:      { label: 'Report',      emoji: '🚨', description: 'Report a member or issue' },
  partnership: { label: 'Partnership', emoji: '🤝', description: 'Partnership & collaboration' },
};

class TicketSystem {
  constructor(client) {
    this.client = client;
  }

  async createPanel(channel, config) {
    const options = Object.entries(TICKET_CATEGORIES).map(([id, cat]) => ({
      label: cat.label,
      value: id,
      description: cat.description,
      emoji: cat.emoji,
    }));

    const select = new StringSelectMenuBuilder()
      .setCustomId('ticket:open')
      .setPlaceholder('Select a ticket category...')
      .addOptions(options);

    const row = new ActionRowBuilder().addComponents(select);
    const embed = Embed.ticket('Support Tickets', 'Select a category below to open a support ticket. Our team will assist you as soon as possible.')
      .setThumbnail(channel.guild.iconURL({ dynamic: true }));

    const msg = await channel.send({ embeds: [embed], components: [row] });

    const guildConfig = await this.client.getGuildConfig(channel.guild.id);
    guildConfig.ticketPanel = { messageId: msg.id, channelId: channel.id };
    await this.client.setGuildConfig(channel.guild.id, guildConfig);
    return msg;
  }

  async openTicket(interaction, categoryId) {
    const guild = interaction.guild;
    const user = interaction.user;
    const category = TICKET_CATEGORIES[categoryId];
    if (!category) return interaction.reply({ content: 'Invalid category.', ephemeral: true });

    // Check if user already has open ticket
    const existing = this.client.db.tickets.filter((v, k) =>
      k.startsWith(`${guild.id}:`) && v.userId === user.id && v.status === 'open'
    );
    if (existing.length > 0) {
      const ch = guild.channels.cache.get(existing[0][1].channelId);
      return interaction.reply({ content: `You already have an open ticket: ${ch || 'unknown'}`, ephemeral: true });
    }

    const guildConfig = await this.client.getGuildConfig(guild.id);
    const ticketCategoryId = guildConfig.ticketCategory;

    const ticketId = `ticket-${user.username.toLowerCase()}-${Date.now().toString(36)}`;
    const ticketData = {
      id: ticketId,
      uuid: uuidv4(),
      userId: user.id,
      categoryId,
      guildId: guild.id,
      channelId: null,
      status: 'open',
      priority: 'normal',
      claimedBy: null,
      createdAt: Date.now(),
      messages: [],
    };

    try {
      const channel = await guild.channels.create({
        name: ticketId,
        type: ChannelType.GuildText,
        parent: ticketCategoryId || null,
        permissionOverwrites: [
          { id: guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
          { id: user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
          { id: this.client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels] },
        ],
      });

      // Add support roles
      const supportRoleId = guildConfig.supportRole;
      if (supportRoleId) {
        await channel.permissionOverwrites.edit(supportRoleId, {
          ViewChannel: true, SendMessages: true, ReadMessageHistory: true
        });
      }

      ticketData.channelId = channel.id;
      this.client.db.tickets.set(`${guild.id}:${channel.id}`, ticketData);

      const embed = Embed.ticket(`${category.emoji} ${category.label} Ticket`)
        .setDescription(`Welcome ${user}, a staff member will be with you shortly.\n\n**Category:** ${category.label}\n**Priority:** Normal\n**Ticket ID:** \`${ticketId}\``)
        .addFields(
          { name: 'User', value: `${user} (${user.id})`, inline: true },
          { name: 'Category', value: category.label, inline: true },
        );

      const buttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`ticket:claim:${channel.id}`).setLabel('Claim').setStyle(ButtonStyle.Primary).setEmoji('✋'),
        new ButtonBuilder().setCustomId(`ticket:close:${channel.id}`).setLabel('Close').setStyle(ButtonStyle.Danger).setEmoji('🔒'),
        new ButtonBuilder().setCustomId(`ticket:priority:${channel.id}`).setLabel('Priority').setStyle(ButtonStyle.Secondary).setEmoji('🚨'),
        new ButtonBuilder().setCustomId(`ticket:transcript:${channel.id}`).setLabel('Transcript').setStyle(ButtonStyle.Secondary).setEmoji('📄'),
      );

      await channel.send({ embeds: [embed], components: [buttons] });
      await interaction.reply({ content: `Your ticket has been created: ${channel}`, ephemeral: true });
    } catch (err) {
      Logger.error('TicketSystem', 'Failed to create ticket:', err.message);
      await interaction.reply({ content: 'Failed to create ticket. Please try again.', ephemeral: true });
    }
  }

  async closeTicket(interaction, channelId) {
    const guild = interaction.guild;
    const channel = guild.channels.cache.get(channelId);
    if (!channel) return;

    const ticketData = this.client.db.tickets.get(`${guild.id}:${channelId}`);
    if (!ticketData) return interaction.reply({ content: 'Ticket not found.', ephemeral: true });

    ticketData.status = 'closed';
    ticketData.closedAt = Date.now();
    ticketData.closedBy = interaction.user.id;
    this.client.db.tickets.set(`${guild.id}:${channelId}`, ticketData);

    await interaction.reply({ embeds: [Embed.info('Ticket Closing', 'This ticket will be deleted in 5 seconds.')] });
    setTimeout(async () => {
      await channel.delete('Ticket closed').catch(() => {});
    }, 5000);
  }

  async claimTicket(interaction, channelId) {
    const guild = interaction.guild;
    const ticketData = this.client.db.tickets.get(`${guild.id}:${channelId}`);
    if (!ticketData) return interaction.reply({ content: 'Ticket not found.', ephemeral: true });

    ticketData.claimedBy = interaction.user.id;
    this.client.db.tickets.set(`${guild.id}:${channelId}`, ticketData);

    await interaction.reply({ embeds: [Embed.success('Ticket Claimed', `This ticket has been claimed by ${interaction.user}.`)] });
  }

  async generateTranscript(channelId, guild) {
    const channel = guild.channels.cache.get(channelId);
    if (!channel) return null;

    const messages = await channel.messages.fetch({ limit: 100 });
    const sorted = [...messages.values()].reverse();

    let html = `<!DOCTYPE html><html><head><title>Transcript - ${channel.name}</title>
<style>body{background:#36393f;color:#dcddde;font-family:sans-serif;padding:20px}
.msg{margin:8px 0;padding:8px;background:#2f3136;border-radius:4px}
.author{font-weight:bold;color:#7289da}.time{color:#72767d;font-size:12px}
.content{margin-top:4px}</style></head><body>
<h2>Transcript: #${channel.name}</h2><hr>`;

    for (const msg of sorted) {
      const time = new Date(msg.createdTimestamp).toLocaleString();
      html += `<div class="msg"><span class="author">${msg.author.tag}</span> <span class="time">${time}</span><div class="content">${msg.content.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</div></div>`;
    }
    html += '</body></html>';
    return html;
  }

  async setPriority(interaction, channelId, priority) {
    const guild = interaction.guild;
    const ticketData = this.client.db.tickets.get(`${guild.id}:${channelId}`);
    if (!ticketData) return interaction.reply({ content: 'Ticket not found.', ephemeral: true });

    ticketData.priority = priority;
    this.client.db.tickets.set(`${guild.id}:${channelId}`, ticketData);
    await interaction.reply({ embeds: [Embed.info('Priority Updated', `Ticket priority set to **${priority}**`)] });
  }

  async addMember(channel, guild, userId) {
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) throw new Error('Member not found');
    await channel.permissionOverwrites.edit(member, { ViewChannel: true, SendMessages: true });
    return member;
  }

  async removeMember(channel, guild, userId) {
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) throw new Error('Member not found');
    await channel.permissionOverwrites.delete(member);
    return member;
  }
}

module.exports = { TicketSystem, TICKET_CATEGORIES };
