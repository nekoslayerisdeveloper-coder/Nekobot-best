'use strict';

const { Logger } = require('../utils/logger');

class SecuritySystem {
  constructor(client) {
    this.client = client;
    this.exploitAttempts = new Map();
    this.selfbotSuspects = new Map();
    this.nukerAlerts = new Map();
  }

  // Anti-crash: called by uncaughtException/unhandledRejection handlers
  static handleCrash(error) {
    Logger.error('SecuritySystem', 'Anti-crash triggered:', error);
  }

  // Anti-selfbot: Detect impossible human-speed actions
  checkSelfbot(userId) {
    const now = Date.now();
    const record = this.selfbotSuspects.get(userId) || { count: 0, first: now };
    record.count++;
    if (now - record.first < 1000) {
      if (record.count > 15) {
        Logger.warn('Security', `Possible selfbot detected: ${userId}`);
        this.selfbotSuspects.set(userId, record);
        return true;
      }
    } else {
      this.selfbotSuspects.set(userId, { count: 1, first: now });
    }
    this.selfbotSuspects.set(userId, record);
    return false;
  }

  // Anti-nuker: Track dangerous actions in a short window
  trackAction(guildId, userId, actionType) {
    const key = `${guildId}:${userId}`;
    const now = Date.now();
    const record = this.nukerAlerts.get(key) || { actions: [], warned: false };
    record.actions.push({ type: actionType, at: now });
    // Keep only actions in last 10s
    record.actions = record.actions.filter(a => now - a.at < 10000);

    if (record.actions.length >= 5 && !record.warned) {
      record.warned = true;
      Logger.warn('Security', `Potential nuker detected: ${userId} in ${guildId}`);
      this._handleNuker(guildId, userId);
    }
    this.nukerAlerts.set(key, record);
  }

  async _handleNuker(guildId, userId) {
    if (!this.client) return;
    if (userId === process.env.OWNER_ID) return;
    try {
      const guild = this.client.guilds.cache.get(guildId);
      if (!guild) return;
      const member = await guild.members.fetch(userId).catch(() => null);
      if (!member) return;
      // Remove all roles as a safety measure
      await member.roles.set([]).catch(() => {});
      Logger.warn('Security', `Nuker ${userId} had all roles removed in ${guildId}`);
    } catch (e) {
      Logger.error('Security', 'Nuker handler error:', e.message);
    }
  }

  // Anti-exploit: check for command abuse
  checkExploit(userId, commandName) {
    const key = `${userId}:${commandName}`;
    const now = Date.now();
    const record = this.exploitAttempts.get(key) || { count: 0, first: now };
    if (now - record.first > 5000) {
      this.exploitAttempts.set(key, { count: 1, first: now });
      return false;
    }
    record.count++;
    this.exploitAttempts.set(key, record);
    if (record.count > 30) {
      Logger.warn('Security', `Exploit attempt by ${userId} on command ${commandName}`);
      return true;
    }
    return false;
  }

  // Token protection: ensure token is never logged
  sanitizeLog(text) {
    const token = process.env.DISCORD_TOKEN || '';
    if (!token) return text;
    return text.replace(new RegExp(token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), '[REDACTED]');
  }
}

module.exports = { SecuritySystem };
