'use strict';

const { Logger } = require('../utils/logger');

class TempVCSystem {
  constructor(client) {
    this.client = client;
    this._interval = null;
  }

  start() {
    this._interval = setInterval(() => this._cleanup(), 60000);
  }

  stop() {
    if (this._interval) clearInterval(this._interval);
  }

  async _cleanup() {
    const entries = this.client.db.guild.entries();
    for (const [guildId, data] of entries) {
      const tempVCs = data.tempVCs || {};
      for (const [channelId, vc] of Object.entries(tempVCs)) {
        const guild = this.client.guilds.cache.get(guildId);
        if (!guild) continue;
        const channel = guild.channels.cache.get(channelId);
        if (!channel) { delete tempVCs[channelId]; continue; }
        if (channel.members.size === 0) {
          await channel.delete('Temp VC: empty').catch(() => {});
          delete tempVCs[channelId];
        }
      }
      data.tempVCs = tempVCs;
      this.client.db.guild.set(guildId, data);
    }
  }

  async handleJoin(guildId, userId, channelId) {
    const guildData = this.client.db.guild.get(guildId) || {};
    const createChannelId = guildData.tempVCTrigger;
    if (!createChannelId || channelId !== createChannelId) return;

    const guild = this.client.guilds.cache.get(guildId);
    if (!guild) return;
    const member = guild.members.cache.get(userId);
    if (!member) return;

    const category = guild.channels.cache.get(channelId)?.parentId;
    const newChannel = await guild.channels.create({
      name: `${member.displayName}'s VC`,
      type: 2, // GUILD_VOICE
      parent: category,
      permissionOverwrites: [{ id: userId, allow: ['ManageChannels', 'MoveMembers', 'MuteMembers'] }],
      reason: 'Temp VC created',
    });

    await member.voice.setChannel(newChannel).catch(() => {});
    const tempVCs = guildData.tempVCs || {};
    tempVCs[newChannel.id] = { ownerId: userId, createdAt: Date.now() };
    guildData.tempVCs = tempVCs;
    this.client.db.guild.set(guildId, guildData);
    return newChannel;
  }

  setTrigger(guildId, channelId) {
    const guildData = this.client.db.guild.get(guildId) || {};
    guildData.tempVCTrigger = channelId;
    this.client.db.guild.set(guildId, guildData);
  }
}

module.exports = { TempVCSystem };
