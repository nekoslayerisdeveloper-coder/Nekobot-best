'use strict';

const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { Embed } = require('../utils/embed');
const { Logger } = require('../utils/logger');

class SuggestionSystem {
  constructor(client) {
    this.client = client;
  }

  async submit(interaction, suggestionText) {
    const config = await this.client.getGuildConfig(interaction.guild.id);
    const channelId = config.suggestionChannel;
    if (!channelId) throw new Error('Suggestion channel not configured. Use /setup suggestion-channel');

    const channel = interaction.guild.channels.cache.get(channelId);
    if (!channel) throw new Error('Suggestion channel not found');

    const id = `sug_${Date.now()}`;
    const suggestion = {
      id,
      userId: interaction.user.id,
      text: suggestionText,
      upvotes: [],
      downvotes: [],
      status: 'pending',
      messageId: null,
      channelId,
      guildId: interaction.guild.id,
      createdAt: Date.now(),
      response: null,
    };

    const embed = this._buildEmbed(suggestion, interaction.user);
    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`sug:up:${id}`).setLabel('0').setStyle(ButtonStyle.Success).setEmoji('👍'),
      new ButtonBuilder().setCustomId(`sug:down:${id}`).setLabel('0').setStyle(ButtonStyle.Danger).setEmoji('👎'),
    );

    const msg = await channel.send({ embeds: [embed], components: [buttons] });
    suggestion.messageId = msg.id;

    const store = this.client.db.global.get(`suggestions:${interaction.guild.id}`) || {};
    store[id] = suggestion;
    this.client.db.global.set(`suggestions:${interaction.guild.id}`, store);

    return { id, msg };
  }

  _buildEmbed(suggestion, user) {
    const statusColors = { pending: 0x3498DB, approved: 0x2ECC71, rejected: 0xE74C3C };
    const statusEmojis = { pending: '⏳', approved: '✅', rejected: '❌' };
    return new (require('../utils/embed').Embed.primary)('Suggestion', suggestion.text)
      || require('../utils/embed').Embed.custom(
          statusColors[suggestion.status] || 0x3498DB,
          `${statusEmojis[suggestion.status] || '⏳'} Suggestion`,
          suggestion.text
        )
        .addFields(
          { name: 'Submitted by', value: user ? `${user.tag}` : `<@${suggestion.userId}>`, inline: true },
          { name: 'Status', value: suggestion.status.charAt(0).toUpperCase() + suggestion.status.slice(1), inline: true },
          { name: '👍 Upvotes', value: `${suggestion.upvotes.length}`, inline: true },
          { name: '👎 Downvotes', value: `${suggestion.downvotes.length}`, inline: true },
          ...(suggestion.response ? [{ name: 'Response', value: suggestion.response, inline: false }] : []),
        );
  }

  _buildEmbedFromData(suggestion) {
    const statusColors = { pending: 0x3498DB, approved: 0x2ECC71, rejected: 0xE74C3C };
    const statusEmojis = { pending: '⏳', approved: '✅', rejected: '❌' };
    return Embed.custom(
      statusColors[suggestion.status] || 0x3498DB,
      `${statusEmojis[suggestion.status] || '⏳'} Suggestion`,
      suggestion.text
    ).addFields(
      { name: 'Submitted by', value: `<@${suggestion.userId}>`, inline: true },
      { name: 'Status', value: suggestion.status.charAt(0).toUpperCase() + suggestion.status.slice(1), inline: true },
      { name: '👍 Upvotes', value: `${suggestion.upvotes.length}`, inline: true },
      { name: '👎 Downvotes', value: `${suggestion.downvotes.length}`, inline: true },
      ...(suggestion.response ? [{ name: 'Response', value: suggestion.response, inline: false }] : []),
    );
  }

  async handleVote(interaction, type, suggestionId) {
    const store = this.client.db.global.get(`suggestions:${interaction.guild.id}`) || {};
    const suggestion = store[suggestionId];
    if (!suggestion) return interaction.reply({ content: 'Suggestion not found.', ephemeral: true });

    const userId = interaction.user.id;
    if (userId === suggestion.userId) return interaction.reply({ content: 'You cannot vote on your own suggestion.', ephemeral: true });

    if (type === 'up') {
      suggestion.downvotes = suggestion.downvotes.filter(u => u !== userId);
      if (suggestion.upvotes.includes(userId)) {
        suggestion.upvotes = suggestion.upvotes.filter(u => u !== userId);
      } else {
        suggestion.upvotes.push(userId);
      }
    } else {
      suggestion.upvotes = suggestion.upvotes.filter(u => u !== userId);
      if (suggestion.downvotes.includes(userId)) {
        suggestion.downvotes = suggestion.downvotes.filter(u => u !== userId);
      } else {
        suggestion.downvotes.push(userId);
      }
    }

    store[suggestionId] = suggestion;
    this.client.db.global.set(`suggestions:${interaction.guild.id}`, store);

    const embed = this._buildEmbedFromData(suggestion);
    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`sug:up:${suggestionId}`).setLabel(`${suggestion.upvotes.length}`).setStyle(ButtonStyle.Success).setEmoji('👍'),
      new ButtonBuilder().setCustomId(`sug:down:${suggestionId}`).setLabel(`${suggestion.downvotes.length}`).setStyle(ButtonStyle.Danger).setEmoji('👎'),
    );

    await interaction.message.edit({ embeds: [embed], components: [buttons] });
    await interaction.reply({ content: `Vote recorded!`, ephemeral: true });
  }

  async respond(guildId, suggestionId, status, response, moderatorId) {
    const store = this.client.db.global.get(`suggestions:${guildId}`) || {};
    const suggestion = store[suggestionId];
    if (!suggestion) throw new Error('Suggestion not found');

    suggestion.status = status;
    suggestion.response = response;
    suggestion.respondedBy = moderatorId;
    suggestion.respondedAt = Date.now();
    store[suggestionId] = suggestion;
    this.client.db.global.set(`suggestions:${guildId}`, store);

    const channel = this.client.channels.cache.get(suggestion.channelId);
    if (channel) {
      const msg = await channel.messages.fetch(suggestion.messageId).catch(() => null);
      if (msg) {
        const embed = this._buildEmbedFromData(suggestion);
        await msg.edit({ embeds: [embed] });
      }
    }
    return suggestion;
  }
}

module.exports = { SuggestionSystem };
