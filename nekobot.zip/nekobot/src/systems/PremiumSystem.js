'use strict';

const { v4: uuidv4 } = require('uuid');
const { Logger } = require('../utils/logger');

const PLANS = {
  basic:    { name: 'Basic',    price: 4.99,  duration: 30 * 86400000,  perks: ['custom_role', 'priority_support'] },
  pro:      { name: 'Pro',      price: 9.99,  duration: 30 * 86400000,  perks: ['custom_role', 'priority_support', 'ai_unlimited', 'music_24_7'] },
  lifetime: { name: 'Lifetime', price: 49.99, duration: null,            perks: ['custom_role', 'priority_support', 'ai_unlimited', 'music_24_7', 'all_perks'] },
};

class PremiumSystem {
  constructor(client) {
    this.client = client;
  }

  async generateKey(planId, count = 1) {
    if (!PLANS[planId]) throw new Error(`Unknown plan: ${planId}`);
    const keys = [];
    const keyStore = this.client.db.premium.get('keys') || {};
    for (let i = 0; i < count; i++) {
      const key = `NEKO-${uuidv4().toUpperCase().replace(/-/g, '').slice(0, 4)}-${uuidv4().toUpperCase().replace(/-/g, '').slice(0, 4)}-${uuidv4().toUpperCase().replace(/-/g, '').slice(0, 4)}`;
      keyStore[key] = { planId, used: false, createdAt: Date.now(), usedBy: null, usedAt: null };
      keys.push(key);
    }
    this.client.db.premium.set('keys', keyStore);
    return keys;
  }

  async redeemKey(userId, key) {
    const keyStore = this.client.db.premium.get('keys') || {};
    const keyData = keyStore[key];
    if (!keyData) throw new Error('Invalid key');
    if (keyData.used) throw new Error('Key already used');

    const plan = PLANS[keyData.planId];
    if (!plan) throw new Error('Unknown plan on key');

    keyData.used = true;
    keyData.usedBy = userId;
    keyData.usedAt = Date.now();
    keyStore[key] = keyData;
    this.client.db.premium.set('keys', keyStore);

    const userPremium = this.client.db.premium.get(`user:${userId}`) || {};
    const now = Date.now();
    const existing = userPremium.expiresAt && userPremium.expiresAt > now ? userPremium.expiresAt : now;
    userPremium.planId = keyData.planId;
    userPremium.planName = plan.name;
    userPremium.perks = plan.perks;
    userPremium.activatedAt = now;
    userPremium.expiresAt = plan.duration ? existing + plan.duration : null;
    userPremium.lifetime = plan.duration === null;
    this.client.db.premium.set(`user:${userId}`, userPremium);

    Logger.info('Premium', `User ${userId} redeemed key for plan ${plan.name}`);
    return { plan, expiresAt: userPremium.expiresAt };
  }

  isPremium(userId) {
    const data = this.client.db.premium.get(`user:${userId}`);
    if (!data) return false;
    if (data.lifetime) return true;
    if (!data.expiresAt) return false;
    return Date.now() < data.expiresAt;
  }

  getPremiumData(userId) {
    return this.client.db.premium.get(`user:${userId}`) || null;
  }

  hasPerk(userId, perk) {
    if (!this.isPremium(userId)) return false;
    const data = this.getPremiumData(userId);
    if (!data) return false;
    return data.perks?.includes('all_perks') || data.perks?.includes(perk);
  }

  getPlans() {
    return PLANS;
  }

  listKeys(planId = null) {
    const keyStore = this.client.db.premium.get('keys') || {};
    return Object.entries(keyStore)
      .filter(([, v]) => !planId || v.planId === planId)
      .map(([key, v]) => ({ key, ...v }));
  }

  revokeUser(userId) {
    this.client.db.premium.delete(`user:${userId}`);
  }
}

module.exports = { PremiumSystem, PLANS };
