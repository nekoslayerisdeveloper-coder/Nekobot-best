'use strict';

const { parseMs, formatMs } = require('../utils/ms');
const { Logger } = require('../utils/logger');

class ModerationSystem {
  constructor(client) {
    this.client = client;
  }

  async warn(guild, target, moderator, reason) {
    const userData = await this.client.db.user.get(`${guild.id}:${target.id}`) || {};
    if (!userData.warns) userData.warns = [];
    const warnId = `W${Date.now()}`;
    userData.warns.push({ id: warnId, reason, moderatorId: moderator.id, timestamp: Date.now() });
    await this.client.db.user.set(`${guild.id}:${target.id}`, userData);
    await this._logAction(guild, 'warn', target, moderator, reason, null, warnId);

    // Auto-punish on warn thresholds
    const config = await this.client.getGuildConfig(guild.id);
    const thresholds = config.warnThresholds || {};
    const warnCount = userData.warns.length;
    if (thresholds[warnCount]) {
      const action = thresholds[warnCount];
      if (action === 'mute') await this.timeout(guild, await guild.members.fetch(target.id), moderator, '10m', `Auto: ${warnCount} warns`);
      if (action === 'kick') await this.kick(guild, await guild.members.fetch(target.id), moderator, `Auto: ${warnCount} warns`);
      if (action === 'ban') await this.ban(guild, target, moderator, `Auto: ${warnCount} warns`, 0);
    }
    return { warnId, warnCount: userData.warns.length };
  }

  async removeWarn(guild, target, warnId) {
    const userData = await this.client.db.user.get(`${guild.id}:${target.id}`) || {};
    if (!userData.warns) return false;
    const before = userData.warns.length;
    userData.warns = userData.warns.filter(w => w.id !== warnId);
    await this.client.db.user.set(`${guild.id}:${target.id}`, userData);
    return userData.warns.length < before;
  }

  async getWarns(guild, target) {
    const userData = await this.client.db.user.get(`${guild.id}:${target.id}`) || {};
    return userData.warns || [];
  }

  async timeout(guild, member, moderator, duration, reason) {
    const ms = parseMs(duration);
    if (!ms) throw new Error('Invalid duration');
    await member.timeout(ms, reason);
    await this._logAction(guild, 'mute', member.user, moderator, reason, formatMs(ms));
    return { duration: formatMs(ms), expiresAt: Date.now() + ms };
  }

  async untimeout(guild, member, moderator, reason) {
    await member.timeout(null, reason);
    await this._logAction(guild, 'unmute', member.user, moderator, reason);
  }

  async kick(guild, member, moderator, reason) {
    const user = member.user;
    await member.kick(reason);
    await this._logAction(guild, 'kick', user, moderator, reason);
  }

  async ban(guild, user, moderator, reason, deleteMessageDays = 0) {
    await guild.members.ban(user.id, { reason, deleteMessageSeconds: deleteMessageDays * 86400 });
    await this._logAction(guild, 'ban', user, moderator, reason);
  }

  async unban(guild, userId, moderator, reason) {
    await guild.members.unban(userId, reason);
    const user = await this.client.users.fetch(userId).catch(() => ({ id: userId, tag: userId }));
    await this._logAction(guild, 'unban', user, moderator, reason);
  }

  async softban(guild, member, moderator, reason) {
    const user = member.user;
    await guild.members.ban(user.id, { reason: `Softban: ${reason}`, deleteMessageSeconds: 86400 });
    await guild.members.unban(user.id, 'Softban cleanup');
    await this._logAction(guild, 'softban', user, moderator, reason);
  }

  async nuke(channel, moderator, amount = 100) {
    const msgs = await channel.messages.fetch({ limit: Math.min(amount, 100) });
    await channel.bulkDelete(msgs, true);
    await this._logAction(channel.guild, 'nuke', moderator, moderator, `Nuked ${msgs.size} messages in ${channel.name}`);
    return msgs.size;
  }

  async lockChannel(channel, moderator, reason) {
    await channel.permissionOverwrites.edit(channel.guild.roles.everyone, { SendMessages: false });
    await this._logAction(channel.guild, 'lock', moderator, moderator, `Locked ${channel.name}: ${reason}`);
  }

  async unlockChannel(channel, moderator, reason) {
    await channel.permissionOverwrites.edit(channel.guild.roles.everyone, { SendMessages: null });
    await this._logAction(channel.guild, 'unlock', moderator, moderator, `Unlocked ${channel.name}: ${reason}`);
  }

  async setSlowmode(channel, seconds, moderator, reason) {
    await channel.setRateLimitPerUser(seconds, reason);
    await this._logAction(channel.guild, 'slowmode', moderator, moderator, `Slowmode ${seconds}s in ${channel.name}: ${reason}`);
  }

  async _logAction(guild, action, target, moderator, reason, extra = null, caseId = null) {
    try {
      const config = await this.client.getGuildConfig(guild.id);
      const logChannelId = config.modLogChannel;
      if (!logChannelId) return;

      const channel = guild.channels.cache.get(logChannelId);
      if (!channel) return;

      const { Embed } = require('../utils/embed');
      const embed = Embed.moderation(`${action.toUpperCase()} | ${target.tag || target.username}`)
        .addFields(
          { name: 'User', value: `${target} (${target.id})`, inline: true },
          { name: 'Moderator', value: `${moderator} (${moderator.id})`, inline: true },
          { name: 'Reason', value: reason || 'No reason provided', inline: false }
        );
      if (extra) embed.addFields({ name: 'Duration', value: extra, inline: true });
      if (caseId) embed.addFields({ name: 'Case ID', value: caseId, inline: true });

      await channel.send({ embeds: [embed] });
    } catch (e) {
      Logger.error('ModerationSystem', 'Log action failed:', e.message);
    }
  }
}

module.exports = { ModerationSystem };
