'use strict';

const { Logger } = require('../utils/logger');
const { Embed } = require('../utils/embed');

class LevelSystem {
  constructor(client) {
    this.client = client;
    this.cooldowns = new Map(); // userId -> lastMessageTimestamp
    this.XP_COOLDOWN = 60000; // 1 minute between XP gains
  }

  getXpForLevel(level) {
    return Math.floor(100 * Math.pow(1.5, level));
  }

  getLevelFromXp(xp) {
    let level = 0;
    let totalXp = 0;
    while (totalXp + this.getXpForLevel(level) <= xp) {
      totalXp += this.getXpForLevel(level);
      level++;
    }
    return level;
  }

  getProgressToNextLevel(xp) {
    let level = 0;
    let totalXp = 0;
    while (totalXp + this.getXpForLevel(level) <= xp) {
      totalXp += this.getXpForLevel(level);
      level++;
    }
    const currentLevelXp = xp - totalXp;
    const neededXp = this.getXpForLevel(level);
    return { level, currentLevelXp, neededXp, percentage: Math.floor((currentLevelXp / neededXp) * 100) };
  }

  randomXp(min = 15, max = 25) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  async handleMessage(message) {
    if (!message.guild || message.author.bot) return;

    const userId = message.author.id;
    const guildId = message.guild.id;
    const config = await this.client.getGuildConfig(guildId);
    if (!config.levelSystem?.enabled) return;

    // Cooldown check
    const cooldownKey = `${guildId}:${userId}`;
    const lastMsg = this.cooldowns.get(cooldownKey) || 0;
    if (Date.now() - lastMsg < this.XP_COOLDOWN) return;
    this.cooldowns.set(cooldownKey, Date.now());

    // Excluded channels
    if (config.levelSystem.excludedChannels?.includes(message.channelId)) return;

    // Get/update user data
    const key = `${guildId}:${userId}`;
    const data = this.client.db.user.get(key) || { xp: 0, level: 0, userId, guildId };
    const gainedXp = this.randomXp();
    data.xp = (data.xp || 0) + gainedXp;

    const oldLevel = data.level || 0;
    const newLevel = this.getLevelFromXp(data.xp);
    data.level = newLevel;
    data.lastXp = Date.now();

    this.client.db.user.set(key, data);

    // Level up!
    if (newLevel > oldLevel) {
      await this._handleLevelUp(message, data, newLevel, config);
    }
  }

  async _handleLevelUp(message, data, level, config) {
    try {
      const ls = config.levelSystem || {};
      const channelId = ls.announcementChannel || message.channelId;
      const channel = message.guild.channels.cache.get(channelId) || message.channel;

      const embed = Embed.level('Level Up!', `${message.author} has reached **Level ${level}**! 🎉`)
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }));

      await channel.send({ embeds: [embed] });

      // Apply level rewards
      if (ls.rewards && ls.rewards[level]) {
        const roleId = ls.rewards[level];
        const role = message.guild.roles.cache.get(roleId);
        if (role && message.member) {
          await message.member.roles.add(role).catch(() => {});
        }
      }
    } catch (e) {
      Logger.error('LevelSystem', 'LevelUp error:', e.message);
    }
  }

  async getLeaderboard(guildId, limit = 10) {
    const entries = this.client.db.user.filter((v, k) => k.startsWith(`${guildId}:`));
    return entries
      .map(([, v]) => v)
      .filter(v => v.xp > 0)
      .sort((a, b) => b.xp - a.xp)
      .slice(0, limit);
  }

  async getRank(guildId, userId) {
    const leaderboard = await this.getLeaderboard(guildId, 999);
    const rank = leaderboard.findIndex(u => u.userId === userId) + 1;
    return rank || null;
  }

  async resetUser(guildId, userId) {
    const key = `${guildId}:${userId}`;
    const data = this.client.db.user.get(key) || {};
    data.xp = 0;
    data.level = 0;
    this.client.db.user.set(key, data);
  }

  async setXp(guildId, userId, xp) {
    const key = `${guildId}:${userId}`;
    const data = this.client.db.user.get(key) || { userId, guildId };
    data.xp = xp;
    data.level = this.getLevelFromXp(xp);
    this.client.db.user.set(key, data);
    return data;
  }
}

module.exports = { LevelSystem };
