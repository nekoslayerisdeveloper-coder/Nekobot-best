'use strict';

class CustomCommandSystem {
  constructor(client) {
    this.client = client;
  }

  async handle(message) {
    if (!message.guild || message.author.bot) return;
    const config = await this.client.getGuildConfig(message.guild.id);
    const prefix = config.prefix || '!';
    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    const commands = config.customCommands || {};
    const cmd = commands[commandName];
    if (!cmd) return;

    const response = cmd.response
      .replace('{user}', `${message.author}`)
      .replace('{username}', message.author.username)
      .replace('{server}', message.guild.name)
      .replace('{membercount}', message.guild.memberCount);

    await message.channel.send({ content: response });
    if (cmd.deleteMessage) await message.delete().catch(() => {});
  }

  async create(guildId, name, response, options = {}) {
    const config = await this.client.getGuildConfig(guildId);
    if (!config.customCommands) config.customCommands = {};
    if (Object.keys(config.customCommands).length >= 50) throw new Error('Max 50 custom commands');
    config.customCommands[name.toLowerCase()] = {
      name: name.toLowerCase(),
      response,
      deleteMessage: options.deleteMessage || false,
      createdBy: options.createdBy || null,
      createdAt: Date.now(),
    };
    await this.client.setGuildConfig(guildId, config);
    return config.customCommands[name.toLowerCase()];
  }

  async delete(guildId, name) {
    const config = await this.client.getGuildConfig(guildId);
    if (!config.customCommands?.[name.toLowerCase()]) throw new Error('Command not found');
    delete config.customCommands[name.toLowerCase()];
    await this.client.setGuildConfig(guildId, config);
    return true;
  }

  async list(guildId) {
    const config = await this.client.getGuildConfig(guildId);
    return Object.values(config.customCommands || {});
  }
}

module.exports = { CustomCommandSystem };
