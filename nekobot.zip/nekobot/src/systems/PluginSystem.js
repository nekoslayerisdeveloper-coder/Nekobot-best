'use strict';

const fs = require('fs');
const path = require('path');
const { Logger } = require('../utils/logger');

const PLUGINS_DIR = path.join(process.cwd(), 'plugins');

class PluginSystem {
  constructor(client) {
    this.client = client;
    this.plugins = new Map();
    this.commands = new Map();
    if (!fs.existsSync(PLUGINS_DIR)) fs.mkdirSync(PLUGINS_DIR, { recursive: true });
  }

  async loadPlugins() {
    if (!fs.existsSync(PLUGINS_DIR)) return;
    const dirs = fs.readdirSync(PLUGINS_DIR).filter(f =>
      fs.statSync(path.join(PLUGINS_DIR, f)).isDirectory()
    );
    for (const dir of dirs) {
      await this.loadPlugin(dir).catch(e =>
        Logger.error('PluginSystem', `Failed to load plugin ${dir}:`, e.message)
      );
    }
  }

  async loadPlugin(name) {
    const pluginDir = path.join(PLUGINS_DIR, name);
    const manifestPath = path.join(pluginDir, 'manifest.json');
    const indexPath = path.join(pluginDir, 'index.js');
    if (!fs.existsSync(manifestPath) || !fs.existsSync(indexPath)) {
      Logger.warn('PluginSystem', `Plugin ${name} missing manifest.json or index.js`);
      return;
    }
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
    const plugin = require(indexPath);
    if (typeof plugin.setup === 'function') await plugin.setup(this.client);
    if (plugin.commands) {
      for (const cmd of plugin.commands) {
        if (cmd.data && cmd.execute) this.commands.set(cmd.data.name, cmd);
      }
    }
    this.plugins.set(name, { manifest, plugin, dir: pluginDir });
    Logger.info('PluginSystem', `Loaded plugin: ${manifest.name || name} v${manifest.version || '1.0'}`);
  }

  async unloadPlugin(name) {
    const plugin = this.plugins.get(name);
    if (!plugin) throw new Error(`Plugin "${name}" not loaded`);
    if (typeof plugin.plugin.teardown === 'function') await plugin.plugin.teardown(this.client);
    if (plugin.plugin.commands) {
      for (const cmd of plugin.plugin.commands) this.commands.delete(cmd.data.name);
    }
    // Clear require cache
    const indexPath = path.join(plugin.dir, 'index.js');
    delete require.cache[require.resolve(indexPath)];
    this.plugins.delete(name);
    Logger.info('PluginSystem', `Unloaded plugin: ${name}`);
  }

  async reloadPlugin(name) {
    await this.unloadPlugin(name);
    await this.loadPlugin(name);
  }

  getCommands() { return this.commands; }
  list() { return [...this.plugins.entries()].map(([name, p]) => ({ name, manifest: p.manifest })); }
}

module.exports = { PluginSystem };
