'use strict';

const { Logger } = require('../utils/logger');

class AntinukeSystem {
  constructor(client) {
    this.client = client;
    this.actionLog = new Map(); // guildId:userId -> [{action, timestamp}]
  }

  async track(guildId, userId, action) {
    const guildData = this.client.db.guild.get(guildId) || {};
    const an = guildData.antinuke;
    if (!an?.enabled) return;

    const key = `${guildId}:${userId}`;
    const now = Date.now();
    const log = this.actionLog.get(key) || [];
    log.push({ action, timestamp: now });
    // Keep only actions in the last 10 seconds
    const recent = log.filter(a => now - a.timestamp < 10000);
    this.actionLog.set(key, recent);

    const threshold = an.threshold || 5;
    if (recent.length >= threshold) {
      await this._punish(guildId, userId, recent.length, action);
      this.actionLog.delete(key);
    }
  }

  async _punish(guildId, userId, actionCount, lastAction) {
    try {
      const guild = this.client.guilds.cache.get(guildId);
      if (!guild) return;
      if (userId === guild.ownerId || userId === process.env.OWNER_ID) return;

      const member = guild.members.cache.get(userId);
      if (member) {
        await member.ban({ reason: `Anti-Nuke: ${actionCount} suspicious actions (${lastAction}) in 10s` }).catch(() => {});
        Logger.warn('AntinukeSystem', `Banned ${userId} in ${guildId} for ${actionCount} suspicious actions`);
      }

      const guildData = this.client.db.guild.get(guildId) || {};
      const logChannelId = guildData.logChannelId;
      if (logChannelId) {
        const channel = guild.channels.cache.get(logChannelId);
        if (channel) {
          await channel.send({
            embeds: [{
              title: '🛡️ Anti-Nuke Triggered',
              description: `User <@${userId}> was banned for performing **${actionCount}** suspicious actions in 10 seconds.\n**Last Action:** ${lastAction}`,
              color: 0xFF0000,
              timestamp: new Date().toISOString(),
            }],
          });
        }
      }
    } catch (e) {
      Logger.error('AntinukeSystem', `Failed to punish ${userId}:`, e.message);
    }
  }
}

module.exports = { AntinukeSystem };
