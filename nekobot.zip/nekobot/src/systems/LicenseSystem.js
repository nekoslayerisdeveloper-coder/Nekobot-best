'use strict';

const crypto = require('crypto');
const { Logger } = require('../utils/logger');

class LicenseSystem {
  constructor(client) {
    this.client = client;
  }

  _generateCode(prefix = 'LIC') {
    const rand = crypto.randomBytes(12).toString('hex').toUpperCase();
    return `${prefix}-${rand.slice(0,4)}-${rand.slice(4,8)}-${rand.slice(8,12)}-${rand.slice(12,16)}`;
  }

  create({ product, maxActivations = 1, expiresIn = null, metadata = {} }) {
    const code = this._generateCode();
    const license = {
      code,
      product,
      maxActivations,
      activations: [],
      expiresAt: expiresIn ? Date.now() + expiresIn : null,
      metadata,
      createdAt: Date.now(),
      revoked: false,
    };
    const store = this.client.db.global.get('licenses') || {};
    store[code] = license;
    this.client.db.global.set('licenses', store);
    Logger.info('License', `Created license: ${code} for product: ${product}`);
    return license;
  }

  activate(code, activatorId, hwid = null) {
    const store = this.client.db.global.get('licenses') || {};
    const lic = store[code];
    if (!lic) throw new Error('License not found');
    if (lic.revoked) throw new Error('License has been revoked');
    if (lic.expiresAt && Date.now() > lic.expiresAt) throw new Error('License has expired');
    if (lic.activations.length >= lic.maxActivations) {
      if (!lic.activations.find(a => a.activatorId === activatorId)) {
        throw new Error(`License has reached max activations (${lic.maxActivations})`);
      }
    }
    const existingIdx = lic.activations.findIndex(a => a.activatorId === activatorId);
    if (existingIdx >= 0) {
      lic.activations[existingIdx].lastUsed = Date.now();
    } else {
      lic.activations.push({ activatorId, hwid, activatedAt: Date.now(), lastUsed: Date.now() });
    }
    store[code] = lic;
    this.client.db.global.set('licenses', store);
    return lic;
  }

  validate(code, activatorId = null) {
    const store = this.client.db.global.get('licenses') || {};
    const lic = store[code];
    if (!lic) return { valid: false, reason: 'Not found' };
    if (lic.revoked) return { valid: false, reason: 'Revoked' };
    if (lic.expiresAt && Date.now() > lic.expiresAt) return { valid: false, reason: 'Expired' };
    if (activatorId && !lic.activations.find(a => a.activatorId === activatorId)) {
      return { valid: false, reason: 'Not activated for this user' };
    }
    return { valid: true, license: lic };
  }

  revoke(code) {
    const store = this.client.db.global.get('licenses') || {};
    if (!store[code]) throw new Error('License not found');
    store[code].revoked = true;
    store[code].revokedAt = Date.now();
    this.client.db.global.set('licenses', store);
    Logger.info('License', `Revoked license: ${code}`);
  }

  list(product = null) {
    const store = this.client.db.global.get('licenses') || {};
    return Object.values(store).filter(l => !product || l.product === product);
  }
}

module.exports = { LicenseSystem };
