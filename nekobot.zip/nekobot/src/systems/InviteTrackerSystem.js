'use strict';

const { Logger } = require('../utils/logger');

class InviteTrackerSystem {
  constructor(client) {
    this.client = client;
  }

  async cacheGuildInvites(guild) {
    try {
      const invites = await guild.invites.fetch();
      const cache = {};
      invites.forEach(inv => { cache[inv.code] = inv.uses; });
      this.client.inviteCache.set(guild.id, cache);
    } catch (e) {
      Logger.debug('InviteTracker', `Cannot fetch invites for ${guild.name}: ${e.message}`);
    }
  }

  async trackJoin(member) {
    const guild = member.guild;
    const oldCache = this.client.inviteCache.get(guild.id) || {};
    let usedInvite = null;
    try {
      const newInvites = await guild.invites.fetch();
      newInvites.forEach(inv => {
        if ((oldCache[inv.code] || 0) < inv.uses) {
          usedInvite = inv;
        }
      });
      // Update cache
      const newCache = {};
      newInvites.forEach(inv => { newCache[inv.code] = inv.uses; });
      this.client.inviteCache.set(guild.id, newCache);
    } catch (e) {
      Logger.error('InviteTracker', 'Failed to track join:', e.message);
    }

    if (!usedInvite) return null;

    // Store invite data
    const invData = this.client.db.global.get(`invites:${guild.id}`) || {};
    const inviterId = usedInvite.inviter?.id;
    if (inviterId) {
      if (!invData[inviterId]) invData[inviterId] = { total: 0, fake: 0, left: 0, joined: [] };
      invData[inviterId].total++;
      invData[inviterId].joined.push({ userId: member.id, at: Date.now(), code: usedInvite.code });
    }

    // Track invited-by for this user
    const userData = this.client.db.user.get(`${guild.id}:${member.id}`) || {};
    userData.invitedBy = inviterId || null;
    userData.inviteCode = usedInvite.code;
    this.client.db.user.set(`${guild.id}:${member.id}`, userData);
    this.client.db.global.set(`invites:${guild.id}`, invData);

    return { inviter: usedInvite.inviter, code: usedInvite.code, uses: usedInvite.uses };
  }

  async trackLeave(member) {
    const guild = member.guild;
    const userData = this.client.db.user.get(`${guild.id}:${member.id}`) || {};
    const inviterId = userData.invitedBy;
    if (!inviterId) return;

    const invData = this.client.db.global.get(`invites:${guild.id}`) || {};
    if (invData[inviterId]) {
      invData[inviterId].left = (invData[inviterId].left || 0) + 1;
      this.client.db.global.set(`invites:${guild.id}`, invData);
    }
  }

  getInviteCount(guildId, userId) {
    const invData = this.client.db.global.get(`invites:${guildId}`) || {};
    const data = invData[userId] || { total: 0, fake: 0, left: 0, joined: [] };
    return {
      total: data.total,
      fake: data.fake,
      left: data.left,
      real: data.total - data.fake - data.left,
    };
  }

  getLeaderboard(guildId, limit = 10) {
    const invData = this.client.db.global.get(`invites:${guildId}`) || {};
    return Object.entries(invData)
      .map(([userId, data]) => ({
        userId,
        total: data.total,
        real: data.total - (data.fake || 0) - (data.left || 0),
      }))
      .sort((a, b) => b.real - a.real)
      .slice(0, limit);
  }
}

module.exports = { InviteTrackerSystem };
