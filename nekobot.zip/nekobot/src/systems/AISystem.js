'use strict';

const { Logger } = require('../utils/logger');
const { Embed } = require('../utils/embed');

class AISystem {
  constructor(client) {
    this.client = client;
    this.conversations = new Map(); // userId -> message history
    this._openai = null;
  }

  _getClient() {
    if (!this._openai) {
      if (!process.env.OPENAI_API_KEY) throw new Error('OPENAI_API_KEY not set');
      const { OpenAI } = require('openai');
      this._openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    }
    return this._openai;
  }

  async chat(userId, message, systemPrompt) {
    const openai = this._getClient();
    const history = this.conversations.get(userId) || [];
    history.push({ role: 'user', content: message });

    const messages = [
      { role: 'system', content: systemPrompt || 'You are NekoBot, a helpful Discord assistant. Be concise, friendly, and helpful. Keep responses under 1500 characters.' },
      ...history.slice(-10), // Last 10 messages
    ];

    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages,
      max_tokens: 1000,
      temperature: 0.7,
    });

    const reply = response.choices[0].message.content;
    history.push({ role: 'assistant', content: reply });
    if (history.length > 20) history.splice(0, history.length - 20);
    this.conversations.set(userId, history);
    return reply;
  }

  async generateCode(prompt, language = 'javascript') {
    const openai = this._getClient();
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: `You are an expert programmer. Generate clean, working ${language} code. Include brief comments. Wrap code in markdown code blocks.` },
        { role: 'user', content: prompt },
      ],
      max_tokens: 2000,
      temperature: 0.2,
    });
    return response.choices[0].message.content;
  }

  async explain(text) {
    const openai = this._getClient();
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'Explain the following in simple, clear terms. Be educational and concise.' },
        { role: 'user', content: text },
      ],
      max_tokens: 800,
      temperature: 0.5,
    });
    return response.choices[0].message.content;
  }

  async summarize(text) {
    const openai = this._getClient();
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'Summarize the following text in bullet points. Be concise and capture the key points.' },
        { role: 'user', content: text },
      ],
      max_tokens: 500,
      temperature: 0.3,
    });
    return response.choices[0].message.content;
  }

  clearHistory(userId) {
    this.conversations.delete(userId);
  }
}

module.exports = { AISystem };
