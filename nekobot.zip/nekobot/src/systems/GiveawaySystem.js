'use strict';

const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { Embed } = require('../utils/embed');
const { formatMs } = require('../utils/ms');
const { Logger } = require('../utils/logger');

class GiveawaySystem {
  constructor(client) {
    this.client = client;
    this._interval = null;
  }

  start() {
    this._interval = setInterval(() => this._tick(), 15000);
  }

  stop() {
    if (this._interval) clearInterval(this._interval);
  }

  async _tick() {
    const now = Date.now();
    const all = this.client.db.giveaways.entries();
    for (const [key, g] of all) {
      if (g.ended || g.endsAt > now) continue;
      await this.endGiveaway(g.messageId, g.channelId, g.guildId).catch(e =>
        Logger.error('GiveawaySystem', `Failed to end giveaway ${g.messageId}:`, e.message)
      );
    }
  }

  async create({ channelId, guildId, hostId, prize, duration, winnerCount = 1, requirements = {} }) {
    const endsAt = Date.now() + duration;
    const giveaway = {
      messageId: null,
      channelId,
      guildId,
      hostId,
      prize,
      endsAt,
      winnerCount,
      requirements,
      entries: [],
      ended: false,
      winners: [],
      createdAt: Date.now(),
    };

    const channel = await this.client.channels.fetch(channelId).catch(() => null);
    if (!channel) throw new Error('Channel not found');

    const embed = this._buildEmbed(giveaway);
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('giveaway:enter').setLabel('Enter Giveaway').setStyle(ButtonStyle.Success).setEmoji('🎉')
    );

    const msg = await channel.send({ embeds: [embed], components: [row] });
    giveaway.messageId = msg.id;

    this.client.db.giveaways.set(`${guildId}:${msg.id}`, giveaway);
    return giveaway;
  }

  _buildEmbed(g) {
    const endsIn = g.endsAt - Date.now();
    const ended = g.ended;
    return Embed.giveaway(ended ? '🎉 Giveaway Ended' : '🎉 Giveaway')
      .addFields(
        { name: 'Prize', value: `**${g.prize}**`, inline: true },
        { name: 'Winners', value: `${g.winnerCount}`, inline: true },
        { name: 'Entries', value: `${g.entries.length}`, inline: true },
        { name: ended ? 'Ended' : 'Ends', value: `<t:${Math.floor(g.endsAt / 1000)}:R>`, inline: true },
        { name: 'Host', value: `<@${g.hostId}>`, inline: true },
      )
      .setDescription(ended
        ? `Winners: ${g.winners.length > 0 ? g.winners.map(w => `<@${w}>`).join(', ') : 'No valid entries'}`
        : 'Click the button below to enter!'
      );
  }

  async enterGiveaway(interaction) {
    const guild = interaction.guild;
    const userId = interaction.user.id;
    const messageId = interaction.message.id;

    const g = this.client.db.giveaways.get(`${guild.id}:${messageId}`);
    if (!g || g.ended) return interaction.reply({ content: 'This giveaway has ended.', ephemeral: true });

    if (g.entries.includes(userId)) {
      // Remove entry (toggle)
      g.entries = g.entries.filter(e => e !== userId);
      this.client.db.giveaways.set(`${guild.id}:${messageId}`, g);
      return interaction.reply({ content: '❌ You have left the giveaway.', ephemeral: true });
    }

    // Check requirements
    if (g.requirements.roleId) {
      const member = await guild.members.fetch(userId).catch(() => null);
      if (!member?.roles.cache.has(g.requirements.roleId)) {
        return interaction.reply({ content: `You need the <@&${g.requirements.roleId}> role to enter!`, ephemeral: true });
      }
    }

    g.entries.push(userId);
    this.client.db.giveaways.set(`${guild.id}:${messageId}`, g);

    // Update embed
    const embed = this._buildEmbed(g);
    await interaction.message.edit({ embeds: [embed] }).catch(() => {});
    await interaction.reply({ content: '✅ You have entered the giveaway!', ephemeral: true });
  }

  async endGiveaway(messageId, channelId, guildId) {
    const key = `${guildId}:${messageId}`;
    const g = this.client.db.giveaways.get(key);
    if (!g || g.ended) return;

    g.ended = true;
    const winners = this._pickWinners(g.entries, g.winnerCount);
    g.winners = winners;
    this.client.db.giveaways.set(key, g);

    const channel = await this.client.channels.fetch(channelId).catch(() => null);
    if (!channel) return;

    const msg = await channel.messages.fetch(messageId).catch(() => null);
    if (msg) {
      const embed = this._buildEmbed(g);
      await msg.edit({ embeds: [embed], components: [] }).catch(() => {});
    }

    const winnersText = winners.length > 0
      ? `🎉 Congratulations ${winners.map(w => `<@${w}>`).join(', ')}! You won **${g.prize}**!`
      : 'No valid entries. No winners selected.';

    await channel.send({ content: winnersText });
  }

  async rerollGiveaway(messageId, guildId, newWinnerCount) {
    const key = `${guildId}:${messageId}`;
    const g = this.client.db.giveaways.get(key);
    if (!g || !g.ended) throw new Error('Giveaway not ended or not found');

    const count = newWinnerCount || g.winnerCount;
    const excluded = g.winners;
    const pool = g.entries.filter(e => !excluded.includes(e));
    const newWinners = this._pickWinners(pool, count);
    g.winners = [...g.winners, ...newWinners];
    this.client.db.giveaways.set(key, g);

    const channel = await this.client.channels.fetch(g.channelId).catch(() => null);
    if (channel) {
      const text = newWinners.length > 0
        ? `🎉 Reroll! New winners: ${newWinners.map(w => `<@${w}>`).join(', ')} for **${g.prize}**!`
        : 'No new winners could be selected.';
      await channel.send({ content: text });
    }
    return newWinners;
  }

  _pickWinners(entries, count) {
    const pool = [...new Set(entries)];
    const winners = [];
    while (winners.length < count && pool.length > 0) {
      const idx = Math.floor(Math.random() * pool.length);
      winners.push(pool.splice(idx, 1)[0]);
    }
    return winners;
  }

  list(guildId) {
    return this.client.db.giveaways.filter((v, k) => k.startsWith(`${guildId}:`)).map(([, v]) => v);
  }

  async delete(messageId, guildId) {
    const key = `${guildId}:${messageId}`;
    const g = this.client.db.giveaways.get(key);
    if (!g) throw new Error('Giveaway not found');
    this.client.db.giveaways.delete(key);
    const channel = await this.client.channels.fetch(g.channelId).catch(() => null);
    if (channel) {
      const msg = await channel.messages.fetch(messageId).catch(() => null);
      if (msg) await msg.delete().catch(() => {});
    }
  }
}

module.exports = { GiveawaySystem };
