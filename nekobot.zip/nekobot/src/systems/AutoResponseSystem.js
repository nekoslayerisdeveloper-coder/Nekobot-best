'use strict';

class AutoResponseSystem {
  constructor(client) {
    this.client = client;
  }

  async handle(message) {
    if (!message.guild || message.author.bot) return;
    const config = await this.client.getGuildConfig(message.guild.id);
    const triggers = config.autoResponses || [];
    const content = message.content.toLowerCase();

    for (const trigger of triggers) {
      const match = trigger.matchType === 'exact'
        ? content === trigger.trigger.toLowerCase()
        : trigger.matchType === 'startsWith'
        ? content.startsWith(trigger.trigger.toLowerCase())
        : content.includes(trigger.trigger.toLowerCase());

      if (match) {
        const response = trigger.response
          .replace('{user}', `${message.author}`)
          .replace('{username}', message.author.username)
          .replace('{server}', message.guild.name);
        await message.reply({ content: response, allowedMentions: { repliedUser: false } });
        if (trigger.deleteOriginal) await message.delete().catch(() => {});
        return;
      }
    }
  }

  async addTrigger(guildId, trigger, response, matchType = 'includes', deleteOriginal = false) {
    const config = await this.client.getGuildConfig(guildId);
    if (!config.autoResponses) config.autoResponses = [];
    if (config.autoResponses.length >= 50) throw new Error('Maximum of 50 auto-responses reached');
    if (config.autoResponses.find(t => t.trigger.toLowerCase() === trigger.toLowerCase())) throw new Error('Trigger already exists');
    config.autoResponses.push({ trigger, response, matchType, deleteOriginal, createdAt: Date.now() });
    await this.client.setGuildConfig(guildId, config);
    return config.autoResponses;
  }

  async removeTrigger(guildId, trigger) {
    const config = await this.client.getGuildConfig(guildId);
    if (!config.autoResponses) return false;
    const before = config.autoResponses.length;
    config.autoResponses = config.autoResponses.filter(t => t.trigger.toLowerCase() !== trigger.toLowerCase());
    await this.client.setGuildConfig(guildId, config);
    return config.autoResponses.length < before;
  }

  async listTriggers(guildId) {
    const config = await this.client.getGuildConfig(guildId);
    return config.autoResponses || [];
  }
}

module.exports = { AutoResponseSystem };
