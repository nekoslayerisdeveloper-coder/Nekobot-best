'use strict';

const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { Embed } = require('../utils/embed');
const { Logger } = require('../utils/logger');

class VerificationSystem {
  constructor(client) {
    this.client = client;
    this.pendingCaptcha = new Map(); // userId -> { code, expires, guildId }
  }

  async sendPanel(channel, config) {
    const type = config.verify?.type || 'button';
    let embed = Embed.info('Verification Required',
      'You must verify to access this server.\nClick the button below to verify your identity.'
    ).setThumbnail(channel.guild.iconURL({ dynamic: true }));

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('verify:start')
        .setLabel('Verify Me')
        .setStyle(ButtonStyle.Success)
        .setEmoji('✅')
    );

    return channel.send({ embeds: [embed], components: [row] });
  }

  async handleVerifyButton(interaction) {
    const guild = interaction.guild;
    const user = interaction.user;
    const config = await this.client.getGuildConfig(guild.id);
    const verify = config.verify || {};

    if (!verify.enabled) return interaction.reply({ content: 'Verification is not configured.', ephemeral: true });

    const type = verify.type || 'button';
    if (type === 'button') {
      await this._grantVerification(interaction, guild, user, verify);
    } else if (type === 'captcha') {
      await this._startCaptcha(interaction, guild, user);
    } else {
      await this._grantVerification(interaction, guild, user, verify);
    }
  }

  async _grantVerification(interaction, guild, user, verify) {
    const member = await guild.members.fetch(user.id).catch(() => null);
    if (!member) return interaction.reply({ content: 'Could not find your member record.', ephemeral: true });

    if (verify.roleId) {
      const role = guild.roles.cache.get(verify.roleId);
      if (role) {
        await member.roles.add(role).catch(e => Logger.error('Verification', e.message));
        await interaction.reply({ content: `✅ You have been verified and granted the **${role.name}** role!`, ephemeral: true });
        return;
      }
    }
    await interaction.reply({ content: '✅ You have been verified!', ephemeral: true });
  }

  async _startCaptcha(interaction, guild, user) {
    const code = Math.random().toString(36).substring(2, 8).toUpperCase();
    this.pendingCaptcha.set(`${guild.id}:${user.id}`, {
      code,
      guildId: guild.id,
      userId: user.id,
      expires: Date.now() + 120000, // 2 min
    });

    await interaction.reply({
      content: `🔐 Your captcha code is: \`${code}\`\nType this code in the verification channel within 2 minutes.`,
      ephemeral: true,
    });
  }

  async handleCaptchaInput(message) {
    if (!message.guild || message.author.bot) return false;
    const key = `${message.guild.id}:${message.author.id}`;
    const pending = this.pendingCaptcha.get(key);
    if (!pending) return false;
    if (Date.now() > pending.expires) {
      this.pendingCaptcha.delete(key);
      return false;
    }
    if (message.content.toUpperCase() !== pending.code) return false;

    this.pendingCaptcha.delete(key);
    const config = await this.client.getGuildConfig(message.guild.id);
    const verify = config.verify || {};
    const member = await message.guild.members.fetch(message.author.id).catch(() => null);
    if (member && verify.roleId) {
      const role = message.guild.roles.cache.get(verify.roleId);
      if (role) await member.roles.add(role).catch(() => {});
    }
    await message.reply({ embeds: [Embed.success('Verified!', 'You have been successfully verified.')] });
    await message.delete().catch(() => {});
    return true;
  }
}

module.exports = { VerificationSystem };
