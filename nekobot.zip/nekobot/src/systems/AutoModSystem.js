'use strict';

const { Logger } = require('../utils/logger');
const { Embed } = require('../utils/embed');

const KNOWN_PHISHING_DOMAINS = [
  'discord-nitro-gift', 'free-nitro', 'discordapp.gift', 'steamcommunity.ru',
  'discord.gift.', 'dlscordapp', 'discorc', 'steamgifts.one',
];

const SCAM_PATTERNS = [
  /free\s*nitro/i, /discord\s*nitro.*gift/i, /steam.*gift/i,
  /claim.*prize/i, /you\s*won/i, /click.*link.*reward/i,
];

const INVITE_PATTERN = /(?:https?:\/\/)?(?:www\.)?(?:discord\.(?:gg|io|me|li|com\/invite)|discordapp\.com\/invite)\/([a-zA-Z0-9\-]+)/gi;

class AutoModSystem {
  constructor(client) {
    this.client = client;
    this.spamTracker = new Map();   // userId -> { count, firstMessage, timestamps }
    this.mentionTracker = new Map(); // userId -> { count, timestamp }
    this.webhookTracker = new Map(); // guildId -> attempts
  }

  async handle(message) {
    if (!message.guild) return;
    if (message.author.bot) return;
    if (message.author.id === process.env.OWNER_ID) return;

    const config = await this.client.getGuildConfig(message.guild.id);
    const automod = config.automod || {};
    if (!automod.enabled) return;

    // Check if user is exempt (has manage messages or higher)
    if (message.member && message.member.permissions.has('ManageMessages')) return;

    const checks = [
      automod.antiSpam     && this.checkSpam(message, automod),
      automod.antiScam     && this.checkScam(message),
      automod.antiPhishing && this.checkPhishing(message),
      automod.antiInvite   && this.checkInvite(message, automod),
      automod.antiMention  && this.checkMassMention(message, automod),
    ];

    for (const check of checks) {
      const result = await check;
      if (result) return; // Stop after first violation
    }
  }

  async checkSpam(message, automod) {
    const userId = message.author.id;
    const now = Date.now();
    const windowMs = 5000;
    const limit = automod.spamLimit || 5;

    let tracker = this.spamTracker.get(userId) || { count: 0, firstMessage: now, timestamps: [] };
    tracker.timestamps = tracker.timestamps.filter(t => now - t < windowMs);
    tracker.timestamps.push(now);
    tracker.count = tracker.timestamps.length;
    this.spamTracker.set(userId, tracker);

    if (tracker.count >= limit) {
      this.spamTracker.delete(userId);
      await this._punish(message, 'spam', automod.spamPunishment || 'mute', '5m');
      return true;
    }
    return false;
  }

  async checkScam(message) {
    const content = message.content;
    const isScam = SCAM_PATTERNS.some(p => p.test(content));
    if (isScam) {
      await this._punish(message, 'scam link', 'ban', null);
      return true;
    }
    return false;
  }

  async checkPhishing(message) {
    const content = message.content.toLowerCase();
    const isPhishing = KNOWN_PHISHING_DOMAINS.some(domain => content.includes(domain));
    if (isPhishing) {
      await this._punish(message, 'phishing link', 'ban', null);
      return true;
    }
    return false;
  }

  async checkInvite(message, automod) {
    INVITE_PATTERN.lastIndex = 0;
    if (INVITE_PATTERN.test(message.content)) {
      await this._punish(message, 'discord invite', automod.invitePunishment || 'warn', null);
      return true;
    }
    return false;
  }

  async checkMassMention(message, automod) {
    const limit = automod.mentionLimit || 5;
    if (message.mentions.users.size + message.mentions.roles.size >= limit) {
      await this._punish(message, 'mass mention', automod.mentionPunishment || 'mute', '10m');
      return true;
    }
    return false;
  }

  async _punish(message, reason, type, duration) {
    try {
      await message.delete().catch(() => {});

      const warnEmbed = Embed.error(
        'AutoMod Action',
        `${message.author}, your message was removed: **${reason}**\nPunishment: **${type}**`
      );
      const warning = await message.channel.send({ embeds: [warnEmbed] });
      setTimeout(() => warning.delete().catch(() => {}), 5000);

      const { ModerationSystem } = require('./ModerationSystem');
      const mod = new ModerationSystem(this.client);

      if (type === 'warn') {
        await mod.warn(message.guild, message.author, this.client.user, `AutoMod: ${reason}`);
      } else if (type === 'mute') {
        await mod.timeout(message.guild, message.member, this.client.user, duration || '5m', `AutoMod: ${reason}`);
      } else if (type === 'kick') {
        await message.member.kick(`AutoMod: ${reason}`).catch(() => {});
      } else if (type === 'ban') {
        await message.member.ban({ reason: `AutoMod: ${reason}`, deleteMessageSeconds: 86400 }).catch(() => {});
      }

      Logger.info('AutoMod', `${type} applied to ${message.author.tag} for ${reason} in ${message.guild.name}`);
    } catch (err) {
      Logger.error('AutoMod', 'Punishment failed:', err.message);
    }
  }

  // Anti-raid: track join rate
  trackJoin(guildId) {
    const now = Date.now();
    const tracker = this.spamTracker.get(`raid:${guildId}`) || { joins: [], alerted: false };
    tracker.joins = tracker.joins.filter(t => now - t < 10000);
    tracker.joins.push(now);
    this.spamTracker.set(`raid:${guildId}`, tracker);

    if (tracker.joins.length >= 10 && !tracker.alerted) {
      tracker.alerted = true;
      this.spamTracker.set(`raid:${guildId}`, tracker);
      return true; // Raid detected
    }
    return false;
  }
}

module.exports = { AutoModSystem };
