'use strict';

const { ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const { Embed } = require('../utils/embed');
const { Logger } = require('../utils/logger');

class ReactionRoleSystem {
  constructor(client) {
    this.client = client;
  }

  async createButtonPanel(channel, guildId, title, description, roles) {
    // roles: [{ roleId, label, emoji, style }]
    const components = [];
    const chunks = [];
    for (let i = 0; i < roles.length; i += 5) chunks.push(roles.slice(i, i + 5));

    for (const chunk of chunks) {
      const row = new ActionRowBuilder().addComponents(
        chunk.map(r => {
          const btn = new ButtonBuilder()
            .setCustomId(`rr:button:${r.roleId}`)
            .setLabel(r.label || 'Role')
            .setStyle(ButtonStyle[r.style] || ButtonStyle.Secondary);
          if (r.emoji) btn.setEmoji(r.emoji);
          return btn;
        })
      );
      components.push(row);
    }

    const embed = Embed.primary(title || 'Reaction Roles', description || 'Click a button to get/remove a role.')
      .addFields(roles.map(r => ({
        name: r.label || 'Role',
        value: `<@&${r.roleId}>`,
        inline: true,
      })));

    const msg = await channel.send({ embeds: [embed], components });

    // Save panel to DB
    const config = await this.client.getGuildConfig(guildId);
    if (!config.reactionRoles) config.reactionRoles = {};
    config.reactionRoles[msg.id] = { type: 'button', channelId: channel.id, roles, title, description };
    await this.client.setGuildConfig(guildId, config);
    return msg;
  }

  async createSelectPanel(channel, guildId, title, description, roles) {
    // roles: [{ roleId, label, emoji, description }]
    const options = roles.slice(0, 25).map(r => ({
      label: r.label || 'Role',
      value: r.roleId,
      description: r.description || null,
      emoji: r.emoji || null,
    }));

    const select = new StringSelectMenuBuilder()
      .setCustomId(`rr:select:${channel.id}`)
      .setPlaceholder('Select roles...')
      .setMinValues(0)
      .setMaxValues(options.length)
      .addOptions(options);

    const row = new ActionRowBuilder().addComponents(select);
    const embed = Embed.primary(title || 'Reaction Roles', description || 'Select roles from the menu below.');

    const msg = await channel.send({ embeds: [embed], components: [row] });

    const config = await this.client.getGuildConfig(guildId);
    if (!config.reactionRoles) config.reactionRoles = {};
    config.reactionRoles[msg.id] = { type: 'select', channelId: channel.id, roles, title, description };
    await this.client.setGuildConfig(guildId, config);
    return msg;
  }

  async handleButtonClick(interaction, roleId) {
    const member = interaction.member;
    const guild = interaction.guild;
    const role = guild.roles.cache.get(roleId);
    if (!role) return interaction.reply({ content: 'Role not found.', ephemeral: true });

    try {
      if (member.roles.cache.has(roleId)) {
        await member.roles.remove(role);
        await interaction.reply({ content: `❌ Removed role **${role.name}**`, ephemeral: true });
      } else {
        await member.roles.add(role);
        await interaction.reply({ content: `✅ Added role **${role.name}**`, ephemeral: true });
      }
    } catch (e) {
      await interaction.reply({ content: `Failed to assign role: ${e.message}`, ephemeral: true });
    }
  }

  async handleSelectMenu(interaction) {
    const member = interaction.member;
    const guild = interaction.guild;
    const config = await this.client.getGuildConfig(guild.id);
    const panel = config.reactionRoles?.[interaction.message.id];
    if (!panel) return interaction.reply({ content: 'Panel not found.', ephemeral: true });

    const allRoleIds = panel.roles.map(r => r.roleId);
    const selectedRoleIds = interaction.values;

    try {
      // Remove all panel roles then add selected
      for (const roleId of allRoleIds) {
        const role = guild.roles.cache.get(roleId);
        if (!role) continue;
        if (selectedRoleIds.includes(roleId)) {
          await member.roles.add(role).catch(() => {});
        } else {
          await member.roles.remove(role).catch(() => {});
        }
      }
      const added = selectedRoleIds.map(id => `<@&${id}>`).join(', ') || 'None';
      await interaction.reply({ content: `✅ Roles updated! Active: ${added}`, ephemeral: true });
    } catch (e) {
      await interaction.reply({ content: `Failed to update roles: ${e.message}`, ephemeral: true });
    }
  }
}

module.exports = { ReactionRoleSystem };
