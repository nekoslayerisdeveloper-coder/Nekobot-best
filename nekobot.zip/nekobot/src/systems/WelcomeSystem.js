'use strict';

const { Embed } = require('../utils/embed');
const { Logger } = require('../utils/logger');

class WelcomeSystem {
  constructor(client) {
    this.client = client;
  }

  async handleMemberJoin(member) {
    const config = await this.client.getGuildConfig(member.guild.id);
    const welcome = config.welcome;
    if (!welcome?.enabled || !welcome.channelId) return;

    const channel = member.guild.channels.cache.get(welcome.channelId);
    if (!channel) return;

    try {
      const embed = Embed.primary(
        welcome.title?.replace('{user}', member.user.username) || `Welcome to ${member.guild.name}!`,
        (welcome.message || 'Welcome {user} to **{server}**! You are member #{count}.')
          .replace('{user}', `${member}`)
          .replace('{username}', member.user.username)
          .replace('{server}', member.guild.name)
          .replace('{count}', member.guild.memberCount)
      )
        .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))
        .setImage(welcome.bannerUrl || null)
        .setColor(welcome.color || 0x9B59B6);

      await channel.send({ embeds: [embed] });

      // Auto roles
      if (welcome.autoRoles?.length > 0) {
        for (const roleId of welcome.autoRoles) {
          const role = member.guild.roles.cache.get(roleId);
          if (role) await member.roles.add(role).catch(() => {});
        }
      }
    } catch (err) {
      Logger.error('WelcomeSystem', 'Error sending welcome:', err.message);
    }
  }

  async handleMemberLeave(member) {
    const config = await this.client.getGuildConfig(member.guild.id);
    const goodbye = config.goodbye;
    if (!goodbye?.enabled || !goodbye.channelId) return;

    const channel = member.guild.channels.cache.get(goodbye.channelId);
    if (!channel) return;

    try {
      const embed = Embed.primary(
        goodbye.title || `Goodbye, ${member.user.username}!`,
        (goodbye.message || '**{username}** has left the server. We now have **{count}** members.')
          .replace('{username}', member.user.username)
          .replace('{server}', member.guild.name)
          .replace('{count}', member.guild.memberCount)
      )
        .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
        .setColor(goodbye.color || 0xE74C3C);

      await channel.send({ embeds: [embed] });
    } catch (err) {
      Logger.error('WelcomeSystem', 'Error sending goodbye:', err.message);
    }
  }
}

module.exports = { WelcomeSystem };
