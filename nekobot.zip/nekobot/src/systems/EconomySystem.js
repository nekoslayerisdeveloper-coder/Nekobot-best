'use strict';

const { Logger } = require('../utils/logger');

const JOBS = [
  { name: 'Developer', min: 500, max: 1200, cooldown: 3600000 },
  { name: 'Doctor', min: 800, max: 1500, cooldown: 3600000 },
  { name: 'Teacher', min: 300, max: 700, cooldown: 3600000 },
  { name: 'Chef', min: 250, max: 600, cooldown: 3600000 },
  { name: 'Driver', min: 150, max: 400, cooldown: 3600000 },
  { name: 'Streamer', min: 100, max: 2000, cooldown: 3600000 },
  { name: 'Artist', min: 200, max: 800, cooldown: 3600000 },
  { name: 'Miner', min: 400, max: 900, cooldown: 3600000 },
];

const SHOP_ITEMS = [
  { id: 'role_color', name: 'Role Color Change', price: 5000, description: 'Change your role color' },
  { id: 'vip_tag', name: 'VIP Tag', price: 10000, description: 'Get the VIP tag' },
  { id: 'lootbox', name: 'Loot Box', price: 2500, description: 'Open for random rewards (500-5000)' },
  { id: 'shield', name: 'Shield', price: 3000, description: 'Protect against rob for 24h' },
  { id: 'multiplier', name: 'XP Multiplier', price: 8000, description: '2x XP for 1 hour' },
];

class EconomySystem {
  constructor(client) {
    this.client = client;
  }

  _getKey(userId, guildId) {
    return `${guildId}:${userId}`;
  }

  async getUser(userId, guildId) {
    const key = this._getKey(userId, guildId);
    const data = this.client.db.economy.get(key) || {
      userId, guildId,
      wallet: 500,
      bank: 0,
      bankLimit: 10000,
      lastDaily: 0,
      lastWork: 0,
      job: null,
      inventory: [],
      transactions: [],
      streak: 0,
    };
    return data;
  }

  async saveUser(userId, guildId, data) {
    const key = this._getKey(userId, guildId);
    this.client.db.economy.set(key, data);
    return data;
  }

  async addMoney(userId, guildId, amount, source = 'unknown') {
    const data = await this.getUser(userId, guildId);
    data.wallet += amount;
    data.transactions = data.transactions || [];
    data.transactions.unshift({ type: 'credit', amount, source, timestamp: Date.now() });
    if (data.transactions.length > 50) data.transactions = data.transactions.slice(0, 50);
    await this.saveUser(userId, guildId, data);
    return data;
  }

  async removeMoney(userId, guildId, amount, source = 'unknown') {
    const data = await this.getUser(userId, guildId);
    if (data.wallet < amount) throw new Error('Insufficient wallet balance');
    data.wallet -= amount;
    data.transactions = data.transactions || [];
    data.transactions.unshift({ type: 'debit', amount, source, timestamp: Date.now() });
    if (data.transactions.length > 50) data.transactions = data.transactions.slice(0, 50);
    await this.saveUser(userId, guildId, data);
    return data;
  }

  async deposit(userId, guildId, amount) {
    const data = await this.getUser(userId, guildId);
    if (amount === 'all') amount = data.wallet;
    amount = Number(amount);
    if (isNaN(amount) || amount <= 0) throw new Error('Invalid amount');
    if (data.wallet < amount) throw new Error('Insufficient wallet balance');
    const space = data.bankLimit - data.bank;
    if (space <= 0) throw new Error('Bank is full');
    const deposited = Math.min(amount, space);
    data.wallet -= deposited;
    data.bank += deposited;
    await this.saveUser(userId, guildId, data);
    return { deposited, data };
  }

  async withdraw(userId, guildId, amount) {
    const data = await this.getUser(userId, guildId);
    if (amount === 'all') amount = data.bank;
    amount = Number(amount);
    if (isNaN(amount) || amount <= 0) throw new Error('Invalid amount');
    if (data.bank < amount) throw new Error('Insufficient bank balance');
    data.bank -= amount;
    data.wallet += amount;
    await this.saveUser(userId, guildId, data);
    return { withdrawn: amount, data };
  }

  async daily(userId, guildId) {
    const data = await this.getUser(userId, guildId);
    const now = Date.now();
    const cooldown = 86400000; // 24h
    if (now - data.lastDaily < cooldown) {
      const next = data.lastDaily + cooldown;
      throw new Error(`Already claimed. Next claim: <t:${Math.floor(next / 1000)}:R>`);
    }
    // Streak
    const streakBonus = data.streak >= 7 ? 2 : data.streak >= 3 ? 1.5 : 1;
    const base = 1000;
    const amount = Math.floor(base * streakBonus);
    data.streak = now - data.lastDaily < 172800000 ? (data.streak || 0) + 1 : 1;
    data.lastDaily = now;
    data.wallet += amount;
    await this.saveUser(userId, guildId, data);
    return { amount, streak: data.streak };
  }

  async work(userId, guildId) {
    const data = await this.getUser(userId, guildId);
    const now = Date.now();
    const job = JOBS[Math.floor(Math.random() * JOBS.length)];
    if (now - data.lastWork < job.cooldown) {
      const next = data.lastWork + job.cooldown;
      throw new Error(`On cooldown. Next work: <t:${Math.floor(next / 1000)}:R>`);
    }
    const earned = Math.floor(Math.random() * (job.max - job.min + 1)) + job.min;
    data.wallet += earned;
    data.lastWork = now;
    data.job = job.name;
    await this.saveUser(userId, guildId, data);
    return { job, earned };
  }

  async buyItem(userId, guildId, itemId) {
    const item = SHOP_ITEMS.find(i => i.id === itemId);
    if (!item) throw new Error('Item not found');
    const data = await this.getUser(userId, guildId);
    if (data.wallet < item.price) throw new Error('Insufficient funds');
    data.wallet -= item.price;
    data.inventory = data.inventory || [];
    data.inventory.push({ ...item, boughtAt: Date.now() });

    // Apply item effect
    if (itemId === 'lootbox') {
      const reward = Math.floor(Math.random() * 4500) + 500;
      data.wallet += reward;
      await this.saveUser(userId, guildId, data);
      return { item, lootboxReward: reward };
    }

    await this.saveUser(userId, guildId, data);
    return { item };
  }

  async transfer(fromUserId, toUserId, guildId, amount) {
    amount = Number(amount);
    if (isNaN(amount) || amount <= 0) throw new Error('Invalid amount');
    const from = await this.getUser(fromUserId, guildId);
    if (from.wallet < amount) throw new Error('Insufficient funds');
    const to = await this.getUser(toUserId, guildId);
    from.wallet -= amount;
    to.wallet += amount;
    await this.saveUser(fromUserId, guildId, from);
    await this.saveUser(toUserId, guildId, to);
    return { from, to, amount };
  }

  async getLeaderboard(guildId, type = 'wallet', limit = 10) {
    const entries = this.client.db.economy.filter((v, k) => k.startsWith(`${guildId}:`));
    return entries
      .map(([, v]) => v)
      .sort((a, b) => (b[type] || 0) - (a[type] || 0))
      .slice(0, limit);
  }

  getShop() {
    return SHOP_ITEMS;
  }

  getJobs() {
    return JOBS;
  }

  async rob(robberId, targetId, guildId) {
    const robber = await this.getUser(robberId, guildId);
    const target = await this.getUser(targetId, guildId);

    const hasShield = target.inventory?.some(i => i.id === 'shield' && Date.now() - i.boughtAt < 86400000);
    if (hasShield) throw new Error('Target has a shield!');
    if (target.wallet < 100) throw new Error('Target is too broke to rob!');

    const success = Math.random() > 0.45;
    if (success) {
      const amount = Math.floor(target.wallet * (Math.random() * 0.3 + 0.1));
      target.wallet -= amount;
      robber.wallet += amount;
      await this.saveUser(robberId, guildId, robber);
      await this.saveUser(targetId, guildId, target);
      return { success: true, amount };
    } else {
      const fine = Math.floor(robber.wallet * 0.1);
      robber.wallet = Math.max(0, robber.wallet - fine);
      await this.saveUser(robberId, guildId, robber);
      return { success: false, fine };
    }
  }
}

module.exports = { EconomySystem, SHOP_ITEMS, JOBS };
