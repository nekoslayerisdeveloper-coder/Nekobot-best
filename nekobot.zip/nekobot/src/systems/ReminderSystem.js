'use strict';

const { Logger } = require('../utils/logger');
const { Embed } = require('../utils/embed');

class ReminderSystem {
  constructor(client) {
    this.client = client;
    this._interval = null;
  }

  start() {
    this._interval = setInterval(() => this._tick(), 15000);
  }

  stop() {
    if (this._interval) clearInterval(this._interval);
  }

  async _tick() {
    const now = Date.now();
    const reminders = this.client.db.global.get('reminders') || [];
    const due = reminders.filter(r => !r.sent && r.remindAt <= now);
    if (due.length === 0) return;

    for (const reminder of due) {
      await this._send(reminder);
      reminder.sent = true;
    }

    // Update DB
    const updated = reminders.map(r => due.find(d => d.id === r.id) || r);
    // Cleanup old sent reminders (older than 1 day)
    const cleaned = updated.filter(r => !r.sent || Date.now() - r.remindAt < 86400000);
    this.client.db.global.set('reminders', cleaned);
  }

  async _send(reminder) {
    try {
      const user = await this.client.users.fetch(reminder.userId).catch(() => null);
      if (!user) return;

      const embed = Embed.info('⏰ Reminder!', reminder.message)
        .addFields({ name: 'Set At', value: `<t:${Math.floor(reminder.createdAt / 1000)}:R>`, inline: true });

      // Try DM first, then channel
      let sent = false;
      try {
        await user.send({ embeds: [embed] });
        sent = true;
      } catch {}

      if (!sent && reminder.channelId) {
        const channel = this.client.channels.cache.get(reminder.channelId);
        if (channel) await channel.send({ content: `${user}`, embeds: [embed] });
      }
    } catch (e) {
      Logger.error('ReminderSystem', 'Failed to send reminder:', e.message);
    }
  }

  async addReminder(userId, channelId, message, remindAt) {
    const reminders = this.client.db.global.get('reminders') || [];
    const reminder = {
      id: `rem_${Date.now()}_${Math.random().toString(36).slice(2)}`,
      userId,
      channelId,
      message,
      remindAt,
      createdAt: Date.now(),
      sent: false,
    };
    reminders.push(reminder);
    this.client.db.global.set('reminders', reminders);
    return reminder;
  }

  getUserReminders(userId) {
    const reminders = this.client.db.global.get('reminders') || [];
    return reminders.filter(r => r.userId === userId && !r.sent);
  }

  deleteReminder(userId, reminderId) {
    const reminders = this.client.db.global.get('reminders') || [];
    const idx = reminders.findIndex(r => r.id === reminderId && r.userId === userId);
    if (idx === -1) return false;
    reminders.splice(idx, 1);
    this.client.db.global.set('reminders', reminders);
    return true;
  }
}

module.exports = { ReminderSystem };
