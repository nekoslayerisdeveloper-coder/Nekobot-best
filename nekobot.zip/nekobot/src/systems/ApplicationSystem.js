'use strict';

const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const { Embed } = require('../utils/embed');

const APPLICATION_TYPES = {
  staff:     { label: 'Staff',     questions: ['Why do you want to be staff?', 'How old are you?', 'How active are you?', 'Previous moderation experience?', 'Time zone?'] },
  developer: { label: 'Developer', questions: ['What languages do you know?', 'GitHub/portfolio?', 'Discord bot experience?', 'Availability per week?', 'Why NekoBot?'] },
  moderator: { label: 'Moderator', questions: ['Previous mod experience?', 'How do you handle rule breakers?', 'Daily availability?', 'Time zone?', 'Why this server?'] },
};

class ApplicationSystem {
  constructor(client) {
    this.client = client;
  }

  async sendPanel(channel, guildId) {
    const buttons = Object.entries(APPLICATION_TYPES).map(([id, type]) =>
      new ButtonBuilder().setCustomId(`apply:${id}`).setLabel(`Apply: ${type.label}`).setStyle(ButtonStyle.Primary).setEmoji('📋')
    );
    const row = new ActionRowBuilder().addComponents(buttons);
    const embed = Embed.primary('Staff Applications', 'Click a button below to apply for a position on our team!')
      .addFields(Object.entries(APPLICATION_TYPES).map(([id, t]) => ({ name: t.label, value: `Click **Apply: ${t.label}** to apply`, inline: true })));
    return channel.send({ embeds: [embed], components: [row] });
  }

  async showApplicationModal(interaction, type) {
    const appType = APPLICATION_TYPES[type];
    if (!appType) return interaction.reply({ content: 'Unknown application type.', ephemeral: true });

    const modal = new ModalBuilder().setCustomId(`apply:modal:${type}`).setTitle(`${appType.label} Application`);
    const inputs = appType.questions.slice(0, 5).map((q, i) =>
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId(`q${i}`)
          .setLabel(q.slice(0, 45))
          .setStyle(i === 0 ? TextInputStyle.Paragraph : TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(500)
      )
    );
    modal.addComponents(...inputs);
    await interaction.showModal(modal);
  }

  async submitApplication(interaction, type) {
    const appType = APPLICATION_TYPES[type];
    if (!appType) return;

    const config = await this.client.getGuildConfig(interaction.guild.id);
    const reviewChannelId = config.applicationChannel;
    const answers = appType.questions.map((q, i) => ({
      question: q,
      answer: interaction.fields.getTextInputValue(`q${i}`) || 'No answer',
    }));

    const app = {
      id: `app_${Date.now()}`,
      type,
      userId: interaction.user.id,
      guildId: interaction.guild.id,
      answers,
      status: 'pending',
      createdAt: Date.now(),
      messageId: null,
    };

    const embed = Embed.primary(`📋 ${appType.label} Application`)
      .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: 'Applicant', value: `${interaction.user.tag} (${interaction.user.id})`, inline: true },
        { name: 'Type', value: appType.label, inline: true },
        ...answers.map(a => ({ name: a.question, value: a.answer.slice(0, 1024), inline: false }))
      );

    const reviewButtons = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`app:approve:${app.id}`).setLabel('Approve').setStyle(ButtonStyle.Success).setEmoji('✅'),
      new ButtonBuilder().setCustomId(`app:reject:${app.id}`).setLabel('Reject').setStyle(ButtonStyle.Danger).setEmoji('❌'),
    );

    if (reviewChannelId) {
      const reviewCh = interaction.guild.channels.cache.get(reviewChannelId);
      if (reviewCh) {
        const msg = await reviewCh.send({ embeds: [embed], components: [reviewButtons] });
        app.messageId = msg.id;
      }
    }

    const store = this.client.db.global.get(`applications:${interaction.guild.id}`) || {};
    store[app.id] = app;
    this.client.db.global.set(`applications:${interaction.guild.id}`, store);

    await interaction.reply({ embeds: [Embed.success('Application Submitted!', 'Your application has been submitted. You will be notified of the result.')], ephemeral: true });
  }

  async reviewApplication(interaction, appId, decision) {
    const store = this.client.db.global.get(`applications:${interaction.guild.id}`) || {};
    const app = store[appId];
    if (!app) return interaction.reply({ content: 'Application not found.', ephemeral: true });

    app.status = decision;
    app.reviewedBy = interaction.user.id;
    app.reviewedAt = Date.now();
    store[appId] = app;
    this.client.db.global.set(`applications:${interaction.guild.id}`, store);

    const user = await this.client.users.fetch(app.userId).catch(() => null);
    if (user) {
      const dmEmbed = decision === 'approved'
        ? Embed.success('Application Approved!', `Your **${APPLICATION_TYPES[app.type]?.label}** application has been approved! Welcome to the team.`)
        : Embed.error('Application Rejected', `Your **${APPLICATION_TYPES[app.type]?.label}** application has been rejected. You can reapply in the future.`);
      await user.send({ embeds: [dmEmbed] }).catch(() => {});
    }

    await interaction.message.edit({ components: [] });
    await interaction.reply({ embeds: [Embed.success('Application Reviewed', `Application ${decision} by ${interaction.user.tag}`)] });
  }
}

module.exports = { ApplicationSystem, APPLICATION_TYPES };
