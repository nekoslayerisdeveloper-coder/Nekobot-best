'use strict';

const { Logger } = require('../utils/logger');

const REP_COOLDOWN = 43200000; // 12 hours

class ReputationSystem {
  constructor(client) {
    this.client = client;
  }

  async giveRep(fromId, toId, guildId) {
    if (fromId === toId) throw new Error('You cannot give rep to yourself.');
    const fromKey = `${guildId}:${fromId}`;
    const fromData = this.client.db.user.get(fromKey) || {};
    const lastGive = fromData.lastRepGiven || 0;
    const now = Date.now();
    if (now - lastGive < REP_COOLDOWN) {
      const next = lastGive + REP_COOLDOWN;
      throw new Error(`You can give rep again <t:${Math.floor(next / 1000)}:R>`);
    }

    const toKey = `${guildId}:${toId}`;
    const toData = this.client.db.user.get(toKey) || {};
    toData.reputation = (toData.reputation || 0) + 1;
    fromData.lastRepGiven = now;

    this.client.db.user.set(toKey, toData);
    this.client.db.user.set(fromKey, fromData);
    return toData.reputation;
  }

  getReputation(userId, guildId) {
    const data = this.client.db.user.get(`${guildId}:${userId}`) || {};
    return data.reputation || 0;
  }

  getLeaderboard(guildId, limit = 10) {
    return this.client.db.user.filter((_v, k) => k.startsWith(`${guildId}:`))
      .map(([k, v]) => ({ userId: k.split(':')[1], rep: v.reputation || 0 }))
      .filter(e => e.rep > 0)
      .sort((a, b) => b.rep - a.rep)
      .slice(0, limit);
  }
}

module.exports = { ReputationSystem };
