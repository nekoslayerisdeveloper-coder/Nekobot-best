'use strict';

const { Embed } = require('../utils/embed');
const { Logger } = require('../utils/logger');

class BirthdaySystem {
  constructor(client) {
    this.client = client;
    this._interval = null;
  }

  start() {
    this._tick();
    this._interval = setInterval(() => this._tick(), 3600000); // Check hourly
  }

  stop() {
    if (this._interval) clearInterval(this._interval);
  }

  async _tick() {
    const now = new Date();
    const today = `${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    if (now.getHours() !== 8) return; // Only announce at 8 AM

    const entries = this.client.db.user.entries();
    for (const [key, data] of entries) {
      if (!data.birthday || !data.birthday.date) continue;
      const [, month, day] = data.birthday.date.split('-');
      const bdayToday = `${month}-${day}`;
      if (bdayToday !== today) continue;
      if (data.birthday.announced === now.getFullYear()) continue;

      const [guildId, userId] = key.split(':');
      await this._announceBirthday(guildId, userId, now.getFullYear());
      data.birthday.announced = now.getFullYear();
      this.client.db.user.set(key, data);
    }
  }

  async _announceBirthday(guildId, userId, year) {
    try {
      const guild = this.client.guilds.cache.get(guildId);
      if (!guild) return;
      const guildData = this.client.db.guild.get(guildId) || {};
      const channelId = guildData.birthdayChannelId;
      if (!channelId) return;
      const channel = guild.channels.cache.get(channelId);
      if (!channel) return;
      const user = await this.client.users.fetch(userId).catch(() => null);
      if (!user) return;
      await channel.send({ content: `🎂 <@${userId}>`, embeds: [Embed.primary(`🎉 Happy Birthday, ${user.username}!`, `Today is ${user.username}'s birthday! Wish them a great day! 🎂🎈`)] });
    } catch (e) {
      Logger.error('BirthdaySystem', `Failed to announce birthday for ${userId}:`, e.message);
    }
  }

  async setChannel(guildId, channelId) {
    const guildData = this.client.db.guild.get(guildId) || {};
    guildData.birthdayChannelId = channelId;
    this.client.db.guild.set(guildId, guildData);
  }

  async setBirthday(guildId, userId, date) {
    const key = `${guildId}:${userId}`;
    const data = this.client.db.user.get(key) || {};
    data.birthday = { date, setAt: Date.now() };
    this.client.db.user.set(key, data);
  }

  async getBirthday(guildId, userId) {
    const key = `${guildId}:${userId}`;
    const data = this.client.db.user.get(key) || {};
    return data.birthday || null;
  }

  async getUpcoming(guildId, days = 7) {
    const now = new Date();
    const upcoming = [];
    const entries = this.client.db.user.entries();
    for (const [key, data] of entries) {
      if (!key.startsWith(`${guildId}:`) || !data.birthday?.date) continue;
      const userId = key.split(':')[1];
      const [, month, day] = data.birthday.date.split('-');
      const bday = new Date(now.getFullYear(), parseInt(month) - 1, parseInt(day));
      if (bday < now) bday.setFullYear(now.getFullYear() + 1);
      const diff = Math.ceil((bday - now) / 86400000);
      if (diff <= days) upcoming.push({ userId, date: data.birthday.date, daysUntil: diff });
    }
    return upcoming.sort((a, b) => a.daysUntil - b.daysUntil);
  }
}

module.exports = { BirthdaySystem };
