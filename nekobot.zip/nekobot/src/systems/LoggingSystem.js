'use strict';

const { Embed } = require('../utils/embed');
const { Logger } = require('../utils/logger');

const LOG_TYPES = {
  messageDelete: 'messageDeleteLog',
  messageEdit:   'messageEditLog',
  memberBan:     'modLogChannel',
  memberKick:    'modLogChannel',
  voiceJoin:     'voiceLogChannel',
  voiceLeave:    'voiceLogChannel',
  voiceMove:     'voiceLogChannel',
  roleCreate:    'serverLogChannel',
  roleDelete:    'serverLogChannel',
  roleUpdate:    'serverLogChannel',
  channelCreate: 'serverLogChannel',
  channelDelete: 'serverLogChannel',
  memberJoin:    'memberLogChannel',
  memberLeave:   'memberLogChannel',
  memberUpdate:  'memberLogChannel',
  guildUpdate:   'serverLogChannel',
};

class LoggingSystem {
  constructor(client) {
    this.client = client;
  }

  async send(guildId, logType, embed) {
    try {
      const config = await this.client.getGuildConfig(guildId);
      const configKey = LOG_TYPES[logType];
      if (!configKey) return;
      const channelId = config[configKey];
      if (!channelId) return;
      const guild = this.client.guilds.cache.get(guildId);
      if (!guild) return;
      const channel = guild.channels.cache.get(channelId);
      if (!channel) return;
      await channel.send({ embeds: [embed] });
    } catch (err) {
      Logger.error('LoggingSystem', `Failed to send log (${logType}):`, err.message);
    }
  }

  async logMessageDelete(message) {
    if (!message.guild || message.author?.bot) return;
    const embed = Embed.log('Message Deleted')
      .addFields(
        { name: 'Author', value: `${message.author?.tag || 'Unknown'} (${message.author?.id || '?'})`, inline: true },
        { name: 'Channel', value: `${message.channel}`, inline: true },
        { name: 'Content', value: message.content?.slice(0, 1024) || '*No content*', inline: false },
      )
      .setColor(0xE74C3C)
      .setTimestamp();
    await this.send(message.guild.id, 'messageDelete', embed);
  }

  async logMessageEdit(oldMessage, newMessage) {
    if (!newMessage.guild || newMessage.author?.bot) return;
    if (oldMessage.content === newMessage.content) return;
    const embed = Embed.log('Message Edited')
      .addFields(
        { name: 'Author', value: `${newMessage.author.tag} (${newMessage.author.id})`, inline: true },
        { name: 'Channel', value: `${newMessage.channel}`, inline: true },
        { name: 'Before', value: oldMessage.content?.slice(0, 512) || '*No content*', inline: false },
        { name: 'After', value: newMessage.content?.slice(0, 512) || '*No content*', inline: false },
        { name: 'Jump', value: `[Click here](${newMessage.url})`, inline: true },
      )
      .setColor(0xF39C12)
      .setTimestamp();
    await this.send(newMessage.guild.id, 'messageEdit', embed);
  }

  async logMemberJoin(member) {
    const createdAt = Math.floor(member.user.createdTimestamp / 1000);
    const embed = Embed.log('Member Joined')
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: 'User', value: `${member.user.tag} (${member.id})`, inline: true },
        { name: 'Account Created', value: `<t:${createdAt}:R>`, inline: true },
        { name: 'Member Count', value: `${member.guild.memberCount}`, inline: true },
      )
      .setColor(0x2ECC71)
      .setTimestamp();
    await this.send(member.guild.id, 'memberJoin', embed);
  }

  async logMemberLeave(member) {
    const embed = Embed.log('Member Left')
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: 'User', value: `${member.user.tag} (${member.id})`, inline: true },
        { name: 'Roles', value: member.roles.cache.filter(r => r.id !== member.guild.id).map(r => r.name).join(', ') || 'None', inline: false },
        { name: 'Member Count', value: `${member.guild.memberCount}`, inline: true },
      )
      .setColor(0xE74C3C)
      .setTimestamp();
    await this.send(member.guild.id, 'memberLeave', embed);
  }

  async logVoiceState(oldState, newState) {
    const member = newState.member || oldState.member;
    if (!member) return;
    let action, color, desc;
    if (!oldState.channelId && newState.channelId) {
      action = 'Joined Voice'; color = 0x2ECC71;
      desc = `${member} joined ${newState.channel}`;
    } else if (oldState.channelId && !newState.channelId) {
      action = 'Left Voice'; color = 0xE74C3C;
      desc = `${member} left ${oldState.channel}`;
    } else if (oldState.channelId !== newState.channelId) {
      action = 'Moved Voice'; color = 0xF39C12;
      desc = `${member} moved from ${oldState.channel} to ${newState.channel}`;
    } else return;

    const embed = Embed.log(action).setDescription(desc).setColor(color).setTimestamp();
    await this.send(member.guild.id, action.includes('Joined') ? 'voiceJoin' : action.includes('Left') ? 'voiceLeave' : 'voiceMove', embed);
  }

  async logBan(guild, user, executor, reason) {
    const embed = Embed.log('Member Banned')
      .addFields(
        { name: 'User', value: `${user.tag} (${user.id})`, inline: true },
        { name: 'Moderator', value: executor ? `${executor.tag}` : 'Unknown', inline: true },
        { name: 'Reason', value: reason || 'No reason provided', inline: false },
      )
      .setColor(0xE74C3C)
      .setTimestamp();
    await this.send(guild.id, 'memberBan', embed);
  }

  async logRole(action, role, executor) {
    const embed = Embed.log(`Role ${action}`)
      .addFields(
        { name: 'Role', value: `${role.name} (${role.id})`, inline: true },
        { name: 'Moderator', value: executor ? `${executor.tag}` : 'Unknown', inline: true },
      )
      .setColor(action === 'Created' ? 0x2ECC71 : action === 'Deleted' ? 0xE74C3C : 0xF39C12)
      .setTimestamp();
    await this.send(role.guild.id, 'roleCreate', embed);
  }

  async logChannel(action, channel, executor) {
    const embed = Embed.log(`Channel ${action}`)
      .addFields(
        { name: 'Channel', value: `#${channel.name} (${channel.id})`, inline: true },
        { name: 'Type', value: channel.type.toString(), inline: true },
        { name: 'Moderator', value: executor ? `${executor.tag}` : 'Unknown', inline: true },
      )
      .setColor(action === 'Created' ? 0x2ECC71 : 0xE74C3C)
      .setTimestamp();
    await this.send(channel.guild.id, 'channelCreate', embed);
  }
}

module.exports = { LoggingSystem, LOG_TYPES };
