'use strict';

const { ChannelType } = require('discord.js');
const { Logger } = require('../utils/logger');

class ServerStatsSystem {
  constructor(client) {
    this.client = client;
    this._interval = null;
  }

  start() {
    // Update every 10 minutes
    this._interval = setInterval(() => this._tick(), 600000);
    setTimeout(() => this._tick(), 5000); // Initial update
  }

  stop() {
    if (this._interval) clearInterval(this._interval);
  }

  async _tick() {
    for (const guild of this.client.guilds.cache.values()) {
      const config = await this.client.getGuildConfig(guild.id);
      if (!config.statsChannels) continue;
      await this._updateStats(guild, config.statsChannels).catch(e =>
        Logger.error('ServerStats', `Failed for ${guild.name}:`, e.message)
      );
    }
  }

  async _updateStats(guild, statsChannels) {
    await guild.members.fetch().catch(() => {});
    const memberCount = guild.memberCount;
    const botCount = guild.members.cache.filter(m => m.user.bot).size;
    const humanCount = memberCount - botCount;
    const channelCount = guild.channels.cache.size;
    const roleCount = guild.roles.cache.size;
    const onlineCount = guild.members.cache.filter(m => m.presence?.status !== 'offline' && !m.user.bot).size;
    const boostCount = guild.premiumSubscriptionCount || 0;

    const replacements = {
      '{total}': memberCount,
      '{bots}': botCount,
      '{humans}': humanCount,
      '{channels}': channelCount,
      '{roles}': roleCount,
      '{online}': onlineCount,
      '{boosts}': boostCount,
    };

    for (const [channelId, template] of Object.entries(statsChannels)) {
      const channel = guild.channels.cache.get(channelId);
      if (!channel || channel.type !== ChannelType.GuildVoice) continue;
      let name = template;
      for (const [token, val] of Object.entries(replacements)) {
        name = name.replace(token, val);
      }
      if (channel.name !== name) {
        await channel.setName(name).catch(() => {});
      }
    }
  }

  async setupStatChannel(guild, type) {
    const templates = {
      members:  '👥 Members: {total}',
      humans:   '🙍 Users: {humans}',
      bots:     '🤖 Bots: {bots}',
      online:   '🟢 Online: {online}',
      channels: '📁 Channels: {channels}',
      roles:    '🎭 Roles: {roles}',
      boosts:   '🚀 Boosts: {boosts}',
    };
    const template = templates[type];
    if (!template) throw new Error('Invalid stat type');

    const channel = await guild.channels.create({
      name: template.replace('{total}', '...').replace('{humans}', '...').replace('{bots}', '...').replace(/{[^}]+}/g, '...'),
      type: ChannelType.GuildVoice,
      permissionOverwrites: [
        { id: guild.roles.everyone, deny: ['Connect'] },
      ],
    });

    const config = await this.client.getGuildConfig(guild.id);
    if (!config.statsChannels) config.statsChannels = {};
    config.statsChannels[channel.id] = template;
    await this.client.setGuildConfig(guild.id, config);
    return channel;
  }
}

module.exports = { ServerStatsSystem };
