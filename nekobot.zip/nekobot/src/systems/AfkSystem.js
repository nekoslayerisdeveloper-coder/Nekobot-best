'use strict';

const { Embed } = require('../utils/embed');
const { formatMs } = require('../utils/ms');

class AfkSystem {
  constructor(client) {
    this.client = client;
  }

  async setAfk(member, reason) {
    const data = {
      userId: member.id,
      guildId: member.guild.id,
      reason: reason || 'AFK',
      since: Date.now(),
    };
    this.client.afkUsers.set(`${member.guild.id}:${member.id}`, data);

    // Store in DB
    const userData = this.client.db.user.get(`${member.guild.id}:${member.id}`) || {};
    userData.afk = data;
    this.client.db.user.set(`${member.guild.id}:${member.id}`, userData);

    // Try to prefix nickname
    const nickname = member.displayName;
    if (!nickname.startsWith('[AFK] ')) {
      await member.setNickname(`[AFK] ${nickname}`.slice(0, 32)).catch(() => {});
    }
    return data;
  }

  async removeAfk(member) {
    const key = `${member.guild.id}:${member.id}`;
    const afkData = this.client.afkUsers.get(key);
    if (!afkData) return null;

    this.client.afkUsers.delete(key);
    const userData = this.client.db.user.get(key) || {};
    const duration = Date.now() - (afkData.since || Date.now());
    userData.afk = null;
    this.client.db.user.set(key, userData);

    // Remove AFK prefix from nickname
    if (member.displayName.startsWith('[AFK] ')) {
      await member.setNickname(member.displayName.slice(6)).catch(() => {});
    }
    return { ...afkData, duration };
  }

  isAfk(guildId, userId) {
    return this.client.afkUsers.get(`${guildId}:${userId}`) || null;
  }

  async handleMessage(message) {
    if (!message.guild || message.author.bot) return;
    const guildId = message.guild.id;

    // Check if the message author is AFK → remove AFK
    const authorAfk = this.isAfk(guildId, message.author.id);
    if (authorAfk) {
      const member = message.member;
      if (member) {
        const afkData = await this.removeAfk(member);
        if (afkData) {
          const duration = formatMs(afkData.duration || 0);
          const reply = await message.reply({ embeds: [Embed.info('Welcome back!', `Removed your AFK. You were away for **${duration}**.`)], allowedMentions: { repliedUser: false } });
          setTimeout(() => reply.delete().catch(() => {}), 5000);
        }
      }
    }

    // Check if any mentioned users are AFK
    for (const [, user] of message.mentions.users) {
      if (user.bot) continue;
      const afkData = this.isAfk(guildId, user.id);
      if (afkData) {
        const since = formatMs(Date.now() - afkData.since);
        const embed = Embed.info(`${user.username} is AFK`, `**Reason:** ${afkData.reason}\n**Away for:** ${since}`);
        await message.reply({ embeds: [embed], allowedMentions: { repliedUser: false } });
      }
    }
  }

  // Load AFKs from DB on startup
  async loadAfks(client) {
    const entries = client.db.user.entries();
    for (const [key, data] of entries) {
      if (data.afk && data.afk.since) {
        client.afkUsers.set(key, data.afk);
      }
    }
  }
}

module.exports = { AfkSystem };
