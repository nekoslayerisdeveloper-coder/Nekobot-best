'use strict';

const { DisTube } = require('distube');
const { SpotifyPlugin } = require('@distube/spotify');
const { Embed } = require('../utils/embed');
const { Logger } = require('../utils/logger');

class MusicSystem {
  constructor(client) {
    this.client = client;
    this.distube = null;
  }

  init() {
    try {
      const plugins = [];
      if (process.env.SPOTIFY_CLIENT_ID && process.env.SPOTIFY_CLIENT_SECRET) {
        plugins.push(new SpotifyPlugin({
          emitEventsAfterFetching: true,
          api: {
            clientId: process.env.SPOTIFY_CLIENT_ID,
            clientSecret: process.env.SPOTIFY_CLIENT_SECRET,
          },
        }));
      }

      this.distube = new DisTube(this.client, {
        emitNewSongOnly: false,
        joinNewVoiceChannel: true,
        plugins,
      });

      this._attachEvents();
      Logger.info('MusicSystem', 'DisTube initialized');
    } catch (e) {
      Logger.error('MusicSystem', 'Failed to init DisTube:', e.message);
    }
  }

  _attachEvents() {
    const dt = this.distube;

    dt.on('playSong', (queue, song) => {
      const embed = Embed.music('Now Playing 🎵', `[${song.name}](${song.url})`)
        .addFields(
          { name: 'Duration', value: song.formattedDuration, inline: true },
          { name: 'Requested by', value: `${song.user}`, inline: true },
          { name: 'Queue', value: `${queue.songs.length} song(s)`, inline: true },
        )
        .setThumbnail(song.thumbnail || null);
      queue.textChannel?.send({ embeds: [embed] }).catch(() => {});
    });

    dt.on('addSong', (queue, song) => {
      const embed = Embed.music('Added to Queue', `[${song.name}](${song.url})\nPosition: **#${queue.songs.length - 1}**`);
      queue.textChannel?.send({ embeds: [embed] }).catch(() => {});
    });

    dt.on('addList', (queue, playlist) => {
      const embed = Embed.music('Playlist Added', `**${playlist.name}** (${playlist.songs.length} songs)`);
      queue.textChannel?.send({ embeds: [embed] }).catch(() => {});
    });

    dt.on('finish', queue => {
      queue.textChannel?.send({ embeds: [Embed.music('Queue Finished', 'No more songs in the queue.')] }).catch(() => {});
    });

    dt.on('error', (channel, error) => {
      Logger.error('MusicSystem', 'DisTube error:', error.message);
      channel?.send({ embeds: [Embed.error('Music Error', error.message.slice(0, 1024))] }).catch(() => {});
    });

    dt.on('disconnect', queue => {
      queue.textChannel?.send({ embeds: [Embed.info('Disconnected', 'Left the voice channel.')] }).catch(() => {});
    });
  }

  get queue() { return this.distube; }

  async play(voiceChannel, textChannel, query, member) {
    if (!this.distube) throw new Error('Music system not initialized');
    await this.distube.play(voiceChannel, query, {
      member,
      textChannel,
    });
  }

  async skip(guildId) {
    const queue = this.distube.getQueue(guildId);
    if (!queue) throw new Error('No active queue');
    if (queue.songs.length <= 1) throw new Error('No more songs in queue');
    return queue.skip();
  }

  async stop(guildId) {
    const queue = this.distube.getQueue(guildId);
    if (!queue) throw new Error('No active queue');
    await queue.stop();
  }

  async pause(guildId) {
    const queue = this.distube.getQueue(guildId);
    if (!queue) throw new Error('No active queue');
    return queue.pause();
  }

  async resume(guildId) {
    const queue = this.distube.getQueue(guildId);
    if (!queue) throw new Error('No active queue');
    return queue.resume();
  }

  getQueue(guildId) {
    return this.distube?.getQueue(guildId) || null;
  }

  async setVolume(guildId, volume) {
    const queue = this.distube.getQueue(guildId);
    if (!queue) throw new Error('No active queue');
    queue.setVolume(Math.max(1, Math.min(100, volume)));
  }

  async setLoop(guildId, mode) {
    // 0 = off, 1 = song, 2 = queue
    const queue = this.distube.getQueue(guildId);
    if (!queue) throw new Error('No active queue');
    queue.setRepeatMode(mode);
    return mode;
  }

  async shuffle(guildId) {
    const queue = this.distube.getQueue(guildId);
    if (!queue) throw new Error('No active queue');
    return queue.shuffle();
  }

  async setAutoplay(guildId, enabled) {
    const queue = this.distube.getQueue(guildId);
    if (!queue) throw new Error('No active queue');
    queue.toggleAutoplay();
    return enabled;
  }
}

module.exports = { MusicSystem };
