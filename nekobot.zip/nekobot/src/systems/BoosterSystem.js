'use strict';

const { Embed } = require('../utils/embed');
const { Logger } = require('../utils/logger');

class BoosterSystem {
  constructor(client) {
    this.client = client;
  }

  async handleBoost(member) {
    const config = await this.client.getGuildConfig(member.guild.id);
    const booster = config.boosterSystem || {};
    if (!booster.enabled) return;

    // Grant booster role
    if (booster.roleId) {
      const role = member.guild.roles.cache.get(booster.roleId);
      if (role) await member.roles.add(role).catch(() => {});
    }

    // Announce boost
    if (booster.channelId) {
      const channel = member.guild.channels.cache.get(booster.channelId);
      if (channel) {
        const embed = Embed.premium('New Server Boost! 🚀',
          `${member} just boosted the server! We now have **${member.guild.premiumSubscriptionCount}** boosts!`
        ).setThumbnail(member.user.displayAvatarURL({ dynamic: true }));
        await channel.send({ embeds: [embed] });
      }
    }
  }

  async handleUnboost(member) {
    const config = await this.client.getGuildConfig(member.guild.id);
    const booster = config.boosterSystem || {};

    if (booster.roleId) {
      const role = member.guild.roles.cache.get(booster.roleId);
      if (role) await member.roles.remove(role).catch(() => {});
    }
    // Remove custom role if any
    const userData = this.client.db.user.get(`${member.guild.id}:${member.id}`) || {};
    if (userData.customRoleId) {
      const customRole = member.guild.roles.cache.get(userData.customRoleId);
      if (customRole) await customRole.delete('Booster left').catch(() => {});
      delete userData.customRoleId;
      this.client.db.user.set(`${member.guild.id}:${member.id}`, userData);
    }
  }

  async createCustomRole(member, name, color) {
    const config = await this.client.getGuildConfig(member.guild.id);
    if (!member.premiumSince) throw new Error('You must be a server booster to create a custom role.');

    const userData = this.client.db.user.get(`${member.guild.id}:${member.id}`) || {};
    if (userData.customRoleId) {
      const existingRole = member.guild.roles.cache.get(userData.customRoleId);
      if (existingRole) await existingRole.edit({ name, color }).catch(() => {});
      return existingRole;
    }

    const boosterRole = config.boosterSystem?.roleId
      ? member.guild.roles.cache.get(config.boosterSystem.roleId)
      : null;

    const role = await member.guild.roles.create({
      name: name.slice(0, 100),
      color: color || '#000000',
      position: boosterRole ? boosterRole.position + 1 : 1,
      reason: `Custom booster role for ${member.user.tag}`,
    });
    await member.roles.add(role);
    userData.customRoleId = role.id;
    this.client.db.user.set(`${member.guild.id}:${member.id}`, userData);
    return role;
  }
}

module.exports = { BoosterSystem };
