'use strict';

const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { Embed } = require('../utils/embed');
const { Logger } = require('../utils/logger');

class PollSystem {
  constructor(client) {
    this.client = client;
    this._interval = null;
  }

  start() {
    this._interval = setInterval(() => this._tick(), 15000);
  }

  async _tick() {
    const now = Date.now();
    const polls = this.client.db.global.get('polls') || {};
    for (const [id, poll] of Object.entries(polls)) {
      if (!poll.ended && poll.endsAt && poll.endsAt <= now) {
        await this._endPoll(poll).catch(e => Logger.error('PollSystem', e.message));
        polls[id].ended = true;
      }
    }
    this.client.db.global.set('polls', polls);
  }

  async create({ channelId, guildId, question, options, duration, hostId }) {
    const endsAt = duration ? Date.now() + duration : null;
    const pollId = `poll_${Date.now()}`;
    const poll = {
      id: pollId,
      channelId,
      guildId,
      question,
      options,
      endsAt,
      hostId,
      votes: {},
      messageId: null,
      ended: false,
      createdAt: Date.now(),
    };

    const channel = await this.client.channels.fetch(channelId).catch(() => null);
    if (!channel) throw new Error('Channel not found');

    const embed = this._buildEmbed(poll);
    const buttons = this._buildButtons(poll);
    const msg = await channel.send({ embeds: [embed], components: buttons });
    poll.messageId = msg.id;

    const polls = this.client.db.global.get('polls') || {};
    polls[pollId] = poll;
    this.client.db.global.set('polls', polls);
    return poll;
  }

  _buildEmbed(poll) {
    const totalVotes = Object.values(poll.votes).length;
    const optionResults = poll.options.map((opt, i) => {
      const count = Object.values(poll.votes).filter(v => v === i).length;
      const pct = totalVotes > 0 ? Math.round((count / totalVotes) * 100) : 0;
      const bar = '█'.repeat(Math.floor(pct / 10)) + '░'.repeat(10 - Math.floor(pct / 10));
      return `**${i + 1}.** ${opt}\n${bar} ${pct}% (${count} votes)`;
    });

    return Embed.primary(`📊 ${poll.question}`)
      .setDescription(optionResults.join('\n\n'))
      .addFields(
        { name: 'Total Votes', value: `${totalVotes}`, inline: true },
        { name: poll.ended ? 'Ended' : 'Ends', value: poll.endsAt ? `<t:${Math.floor(poll.endsAt / 1000)}:R>` : 'No end time', inline: true },
      )
      .setColor(poll.ended ? 0x95A5A6 : 0x3498DB);
  }

  _buildButtons(poll) {
    const rows = [];
    const btnChunks = [];
    for (let i = 0; i < poll.options.length; i += 5) btnChunks.push(poll.options.slice(i, i + 5).map((_, j) => i + j));
    for (const chunk of btnChunks) {
      const row = new ActionRowBuilder().addComponents(
        chunk.map(i => new ButtonBuilder()
          .setCustomId(`poll:vote:${poll.id}:${i}`)
          .setLabel(`${i + 1}. ${poll.options[i].slice(0, 20)}`)
          .setStyle(ButtonStyle.Primary)
          .setDisabled(poll.ended)
        )
      );
      rows.push(row);
    }
    return rows;
  }

  async handleVote(interaction, pollId, optionIndex) {
    const polls = this.client.db.global.get('polls') || {};
    const poll = polls[pollId];
    if (!poll || poll.ended) return interaction.reply({ content: 'This poll has ended.', ephemeral: true });

    const userId = interaction.user.id;
    const prevVote = poll.votes[userId];
    if (prevVote === optionIndex) {
      delete poll.votes[userId];
      await interaction.reply({ content: `❌ Removed your vote from option ${optionIndex + 1}.`, ephemeral: true });
    } else {
      poll.votes[userId] = optionIndex;
      await interaction.reply({ content: `✅ Voted for: **${poll.options[optionIndex]}**`, ephemeral: true });
    }

    polls[pollId] = poll;
    this.client.db.global.set('polls', polls);

    const embed = this._buildEmbed(poll);
    const buttons = this._buildButtons(poll);
    await interaction.message.edit({ embeds: [embed], components: buttons }).catch(() => {});
  }

  async _endPoll(poll) {
    const channel = await this.client.channels.fetch(poll.channelId).catch(() => null);
    if (!channel) return;
    const msg = await channel.messages.fetch(poll.messageId).catch(() => null);
    if (!msg) return;

    poll.ended = true;
    const embed = this._buildEmbed(poll);
    const buttons = this._buildButtons(poll);
    await msg.edit({ embeds: [embed], components: buttons });

    const totalVotes = Object.values(poll.votes).length;
    let winnerText = 'No votes!';
    if (totalVotes > 0) {
      const counts = poll.options.map((_, i) => Object.values(poll.votes).filter(v => v === i).length);
      const maxVotes = Math.max(...counts);
      const winners = poll.options.filter((_, i) => counts[i] === maxVotes);
      winnerText = `**Winner${winners.length > 1 ? 's' : ''}:** ${winners.map(w => `"${w}"`).join(', ')} with ${maxVotes} vote${maxVotes !== 1 ? 's' : ''}!`;
    }
    await channel.send({ embeds: [Embed.success('Poll Ended!', `${poll.question}\n\n${winnerText}`)] });
  }
}

module.exports = { PollSystem };
