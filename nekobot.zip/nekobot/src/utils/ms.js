'use strict';

/**
 * Parse human-readable duration strings to milliseconds
 * e.g. "1d", "2h", "30m", "45s", "1h30m"
 */
function parseMs(str) {
  if (typeof str === 'number') return str;
  if (!str) return null;

  const units = {
    y: 365 * 24 * 60 * 60 * 1000,
    mo: 30 * 24 * 60 * 60 * 1000,
    w: 7 * 24 * 60 * 60 * 1000,
    d: 24 * 60 * 60 * 1000,
    h: 60 * 60 * 1000,
    m: 60 * 1000,
    s: 1000,
  };

  let total = 0;
  const regex = /(\d+\.?\d*)\s*(y|mo|w|d|h|m|s)/gi;
  let match;
  while ((match = regex.exec(str)) !== null) {
    const amount = parseFloat(match[1]);
    const unit = match[2].toLowerCase();
    total += amount * (units[unit] || 0);
  }
  return total || null;
}

function formatMs(ms) {
  if (!ms || ms < 0) return '0s';
  const d = Math.floor(ms / 86400000);
  const h = Math.floor((ms % 86400000) / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);

  const parts = [];
  if (d > 0) parts.push(`${d}d`);
  if (h > 0) parts.push(`${h}h`);
  if (m > 0) parts.push(`${m}m`);
  if (s > 0 && d === 0) parts.push(`${s}s`);
  return parts.join(' ') || '0s';
}

function formatTimestamp(ms, style = 'R') {
  const seconds = Math.floor(ms / 1000);
  return `<t:${seconds}:${style}>`;
}

module.exports = { parseMs, formatMs, formatTimestamp };
