'use strict';

const chalk = require('chalk');
const fs = require('fs');
const path = require('path');

const LOG_DIR = path.join(process.cwd(), 'logs');
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });

const levels = {
  error: { color: chalk.red, label: 'ERROR', priority: 0 },
  warn:  { color: chalk.yellow, label: 'WARN ', priority: 1 },
  info:  { color: chalk.cyan, label: 'INFO ', priority: 2 },
  success: { color: chalk.green, label: 'OK   ', priority: 3 },
  debug: { color: chalk.gray, label: 'DEBUG', priority: 4 },
};

function getTimestamp() {
  return new Date().toISOString().replace('T', ' ').split('.')[0];
}

function writeToFile(level, tag, message) {
  const date = new Date().toISOString().split('T')[0];
  const logFile = path.join(LOG_DIR, `${date}.log`);
  const line = `[${getTimestamp()}] [${level}] [${tag}] ${message}\n`;
  fs.appendFileSync(logFile, line);
}

function log(level, tag, ...args) {
  const lvl = levels[level] || levels.info;
  const msg = args.map(a => (typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a))).join(' ');
  const timestamp = chalk.gray(`[${getTimestamp()}]`);
  const badge = lvl.color(`[${lvl.label}]`);
  const tagStr = chalk.magenta(`[${tag}]`);
  console.log(`${timestamp} ${badge} ${tagStr} ${msg}`);
  writeToFile(lvl.label.trim(), tag, msg);
}

const Logger = {
  error: (tag, ...args) => log('error', tag, ...args),
  warn:  (tag, ...args) => log('warn', tag, ...args),
  info:  (tag, ...args) => log('info', tag, ...args),
  success: (tag, ...args) => log('success', tag, ...args),
  debug: (tag, ...args) => { if (process.env.LOG_LEVEL === 'debug') log('debug', tag, ...args); },
  getLogs(date) {
    const d = date || new Date().toISOString().split('T')[0];
    const f = path.join(LOG_DIR, `${d}.log`);
    if (!fs.existsSync(f)) return [];
    return fs.readFileSync(f, 'utf-8').trim().split('\n').filter(Boolean);
  },
};

module.exports = { Logger };
