'use strict';

const { EmbedBuilder, Colors } = require('discord.js');

const COLORS = {
  primary:   0x9B59B6,
  success:   0x2ECC71,
  error:     0xE74C3C,
  warning:   0xF39C12,
  info:      0x3498DB,
  moderation:0xFF6B6B,
  economy:   0xF1C40F,
  music:     0x1ABC9C,
  level:     0x9B59B6,
  ticket:    0x5DADE2,
  giveaway:  0xFF69B4,
  premium:   0xFFD700,
};

const NEKO_ICON = 'https://i.imgur.com/AfFp7pu.png';

function base(color) {
  return new EmbedBuilder()
    .setColor(color)
    .setTimestamp()
    .setFooter({ text: 'NekoBot • Ultra Advanced', iconURL: NEKO_ICON });
}

const Embed = {
  success(title, description) {
    return base(COLORS.success).setTitle(`✅  ${title}`).setDescription(description || null);
  },
  error(title, description) {
    return base(COLORS.error).setTitle(`❌  ${title}`).setDescription(description || null);
  },
  warning(title, description) {
    return base(COLORS.warning).setTitle(`⚠️  ${title}`).setDescription(description || null);
  },
  info(title, description) {
    return base(COLORS.info).setTitle(`ℹ️  ${title}`).setDescription(description || null);
  },
  primary(title, description) {
    return base(COLORS.primary).setTitle(title).setDescription(description || null);
  },
  moderation(title, description) {
    return base(COLORS.moderation).setTitle(`🔨  ${title}`).setDescription(description || null);
  },
  economy(title, description) {
    return base(COLORS.economy).setTitle(`💰  ${title}`).setDescription(description || null);
  },
  music(title, description) {
    return base(COLORS.music).setTitle(`🎵  ${title}`).setDescription(description || null);
  },
  level(title, description) {
    return base(COLORS.level).setTitle(`⭐  ${title}`).setDescription(description || null);
  },
  ticket(title, description) {
    return base(COLORS.ticket).setTitle(`🎫  ${title}`).setDescription(description || null);
  },
  giveaway(title, description) {
    return base(COLORS.giveaway).setTitle(`🎉  ${title}`).setDescription(description || null);
  },
  premium(title, description) {
    return base(COLORS.premium).setTitle(`👑  ${title}`).setDescription(description || null);
  },
  log(title, description) {
    return base(COLORS.info).setTitle(`📋  ${title}`).setDescription(description || null);
  },
  custom(color, title, description) {
    return base(color).setTitle(title).setDescription(description || null);
  },
};

module.exports = { Embed, COLORS };
