'use strict';

const { PermissionFlagsBits } = require('discord.js');

const PERMISSION_NAMES = {
  Administrator: 'Administrator',
  ManageGuild: 'Manage Server',
  ManageRoles: 'Manage Roles',
  ManageChannels: 'Manage Channels',
  ManageMessages: 'Manage Messages',
  ManageNicknames: 'Manage Nicknames',
  ManageWebhooks: 'Manage Webhooks',
  KickMembers: 'Kick Members',
  BanMembers: 'Ban Members',
  MuteMembers: 'Mute Members',
  DeafenMembers: 'Deafen Members',
  MoveMembers: 'Move Members',
  ModerateMembers: 'Timeout Members',
  SendMessages: 'Send Messages',
  EmbedLinks: 'Embed Links',
  AttachFiles: 'Attach Files',
  UseExternalEmojis: 'Use External Emojis',
  AddReactions: 'Add Reactions',
  ViewAuditLog: 'View Audit Log',
  ViewChannel: 'View Channels',
  Connect: 'Connect',
  Speak: 'Speak',
  PrioritySpeaker: 'Priority Speaker',
  Stream: 'Stream',
  RequestToSpeak: 'Request to Speak',
};

function hasPermission(member, permission) {
  if (!member) return false;
  if (member.id === process.env.OWNER_ID) return true;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  return member.permissions.has(PermissionFlagsBits[permission] || permission);
}

function getPermissionName(perm) {
  return PERMISSION_NAMES[perm] || perm;
}

function formatPermissions(perms) {
  if (!perms || perms.length === 0) return 'None';
  return perms.map(p => `\`${getPermissionName(p)}\``).join(', ');
}

function checkPermissions(member, required) {
  const missing = [];
  for (const perm of required) {
    if (!hasPermission(member, perm)) missing.push(perm);
  }
  return missing;
}

module.exports = { hasPermission, getPermissionName, formatPermissions, checkPermissions, PERMISSION_NAMES };
