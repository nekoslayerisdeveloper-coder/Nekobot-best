'use strict';

const express = require('express');
const session = require('express-session');
const passport = require('passport');
const { Strategy } = require('passport-discord');
const path = require('path');
const helmet = require('helmet');
const cors = require('cors');
const { Logger: logger } = require('../utils/logger');

class DashboardServer {
  constructor(client) {
    this.client = client;
    this.app = express();
    this.server = null;
    this._setup();
  }

  _setup() {
    const app = this.app;
    const client = this.client;

    app.use(helmet({ contentSecurityPolicy: false }));
    app.use(cors({ origin: process.env.DASHBOARD_URL || '*', credentials: true }));
    app.use(express.json());
    app.use(express.urlencoded({ extended: true }));
    app.use(express.static(path.join(__dirname, 'public')));

    app.use(session({
      secret: process.env.SESSION_SECRET || 'nekobot-dashboard-secret',
      resave: false,
      saveUninitialized: false,
      cookie: { secure: process.env.NODE_ENV === 'production', maxAge: 604800000 },
    }));

    app.use(passport.initialize());
    app.use(passport.session());

    if (process.env.CLIENT_ID && process.env.CLIENT_SECRET) {
      passport.use(new Strategy({
        clientID: process.env.CLIENT_ID,
        clientSecret: process.env.CLIENT_SECRET,
        callbackURL: process.env.CALLBACK_URL || 'http://localhost:3000/auth/callback',
        scope: ['identify', 'guilds'],
      }, (accessToken, _refreshToken, profile, done) => {
        profile.accessToken = accessToken;
        return done(null, profile);
      }));
    }

    passport.serializeUser((user, done) => done(null, user));
    passport.deserializeUser((user, done) => done(null, user));

    const checkAuth = (req, res, next) => {
      if (req.isAuthenticated()) return next();
      res.redirect('/auth/login');
    };

    const checkOwner = (req, res, next) => {
      if (req.user?.id === process.env.OWNER_ID) return next();
      res.status(403).json({ error: 'Owner only' });
    };

    app.get('/auth/login', passport.authenticate('discord'));
    app.get('/auth/callback', passport.authenticate('discord', { failureRedirect: '/' }), (_req, res) => res.redirect('/dashboard'));
    app.get('/auth/logout', (req, res) => { req.logout(() => res.redirect('/')); });

    app.get('/api/dashboard/user', checkAuth, (req, res) => {
      const user = req.user;
      res.json({ id: user.id, username: user.username, avatar: user.avatar ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png` : null, guilds: user.guilds || [] });
    });

    app.get('/api/dashboard/guilds', checkAuth, (req, res) => {
      const user = req.user;
      const manageable = (user.guilds || []).filter(g => (BigInt(g.permissions) & BigInt(0x8)) === BigInt(0x8));
      const mutual = manageable.map(g => {
        const clientGuild = client.guilds.cache.get(g.id);
        return { ...g, botIn: !!clientGuild, memberCount: clientGuild?.memberCount };
      });
      res.json({ guilds: mutual });
    });

    app.get('/api/dashboard/guild/:guildId', checkAuth, (req, res) => {
      const { guildId } = req.params;
      const guild = client.guilds.cache.get(guildId);
      if (!guild) return res.status(404).json({ error: 'Guild not found or bot not in guild' });
      const member = guild.members.cache.get(req.user.id);
      if (!member || !member.permissions.has('ManageGuild')) return res.status(403).json({ error: 'Insufficient permissions' });
      const config = client.db.guild.get(guildId) || {};
      res.json({
        guild: {
          id: guild.id, name: guild.name, icon: guild.iconURL({ dynamic: true }), memberCount: guild.memberCount,
          channels: guild.channels.cache.filter(c => c.type === 0).map(c => ({ id: c.id, name: c.name })),
          roles: guild.roles.cache.filter(r => r.id !== guild.id).map(r => ({ id: r.id, name: r.name, color: r.hexColor })),
        },
        config,
      });
    });

    app.patch('/api/dashboard/guild/:guildId', checkAuth, (req, res) => {
      const { guildId } = req.params;
      const guild = client.guilds.cache.get(guildId);
      if (!guild) return res.status(404).json({ error: 'Guild not found' });
      const member = guild.members.cache.get(req.user.id);
      if (!member || !member.permissions.has('ManageGuild')) return res.status(403).json({ error: 'Insufficient permissions' });
      const current = client.db.guild.get(guildId) || {};
      const updated = { ...current, ...req.body };
      client.db.guild.set(guildId, updated);
      res.json({ success: true, config: updated });
    });

    app.get('/api/dashboard/stats', checkAuth, checkOwner, (_req, res) => {
      res.json({
        guilds: client.guilds.cache.size,
        users: client.guilds.cache.reduce((a, g) => a + g.memberCount, 0),
        commands: client.commands.size,
        ping: client.ws.ping,
        uptime: process.uptime(),
        memory: process.memoryUsage().rss,
      });
    });

    app.get('/api/health', (_req, res) => res.json({ status: 'dashboard-ok' }));

    app.get('*', (_req, res) => {
      const indexPath = path.join(__dirname, 'public', 'index.html');
      res.sendFile(indexPath);
    });
  }

  async start() {
    const port = process.env.DASHBOARD_PORT || 3000;
    this.server = this.app.listen(port, () => {
      logger.info(`Dashboard server listening on port ${port}`);
    });
    return this.server;
  }

  async stop() {
    if (this.server) this.server.close();
  }
}

module.exports = { DashboardServer };
