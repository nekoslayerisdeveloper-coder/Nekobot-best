'use strict';

const { Router } = require('express');
const router = Router();

router.get('/', (req, res) => {
  const commands = [...req.client.commands.values()].map(cmd => ({
    name: cmd.data.name,
    description: cmd.data.description,
    category: cmd.category,
    cooldown: cmd.cooldown || 3,
    premium: cmd.premium || false,
    ownerOnly: cmd.ownerOnly || false,
    permissions: cmd.permissions || [],
  }));
  const byCategory = commands.reduce((acc, cmd) => {
    acc[cmd.category] = acc[cmd.category] || [];
    acc[cmd.category].push(cmd);
    return acc;
  }, {});
  res.json({ commands, byCategory, total: commands.length });
});

router.get('/:name', (req, res) => {
  const cmd = req.client.commands.get(req.params.name);
  if (!cmd) return res.status(404).json({ error: 'Command not found' });
  res.json({ name: cmd.data.name, description: cmd.data.description, category: cmd.category, cooldown: cmd.cooldown || 3, premium: cmd.premium || false, ownerOnly: cmd.ownerOnly || false, permissions: cmd.permissions || [], botPermissions: cmd.botPermissions || [] });
});

module.exports = router;
