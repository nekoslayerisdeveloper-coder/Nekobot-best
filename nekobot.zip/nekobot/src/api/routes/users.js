'use strict';

const { Router } = require('express');
const router = Router();

router.get('/:userId', async (req, res) => {
  try {
    const user = await req.client.users.fetch(req.params.userId);
    res.json({ id: user.id, username: user.username, tag: user.tag, avatar: user.displayAvatarURL({ dynamic: true }), bot: user.bot, createdAt: user.createdAt });
  } catch {
    res.status(404).json({ error: 'User not found' });
  }
});

router.get('/:userId/premium', (req, res) => {
  const data = req.client.db.premium.get(req.params.userId) || { active: false };
  res.json(data);
});

router.get('/:userId/economy/:guildId', (req, res) => {
  const { userId, guildId } = req.params;
  const data = req.client.db.economy.get(`${guildId}:${userId}`) || { wallet: 0, bank: 0, bankLimit: 10000 };
  res.json(data);
});

router.get('/:userId/level/:guildId', (req, res) => {
  const { userId, guildId } = req.params;
  const data = req.client.db.user.get(`${guildId}:${userId}`) || { level: 0, xp: 0, messages: 0 };
  res.json({ level: data.level || 0, xp: data.xp || 0, messages: data.messages || 0 });
});

router.get('/:userId/warnings/:guildId', (req, res) => {
  const { userId, guildId } = req.params;
  const data = req.client.db.user.get(`${guildId}:${userId}`) || {};
  res.json({ warnings: data.warns || [] });
});

module.exports = router;
