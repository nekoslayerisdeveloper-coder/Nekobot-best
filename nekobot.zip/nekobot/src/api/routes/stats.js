'use strict';

const { Router } = require('express');
const os = require('os');
const router = Router();

router.get('/', (req, res) => {
  const client = req.client;
  const memUsage = process.memoryUsage();
  res.json({
    bot: {
      guilds: client.guilds.cache.size,
      users: client.guilds.cache.reduce((a, g) => a + g.memberCount, 0),
      channels: client.channels.cache.size,
      commands: client.commands.size,
      ping: client.ws.ping,
      uptime: process.uptime(),
    },
    system: {
      platform: os.platform(),
      arch: os.arch(),
      nodeVersion: process.version,
      ram: { used: memUsage.rss, total: os.totalmem(), heapUsed: memUsage.heapUsed, heapTotal: memUsage.heapTotal },
      cpu: { cores: os.cpus().length, load: os.loadavg() },
    },
    timestamp: new Date().toISOString(),
  });
});

router.get('/commands', (req, res) => {
  const stats = req.client.db.global.get('commandStats') || {};
  const sorted = Object.entries(stats).sort((a, b) => b[1] - a[1]).slice(0, 50);
  res.json({ stats: Object.fromEntries(sorted), total: sorted.reduce((a, [, v]) => a + v, 0) });
});

module.exports = router;
