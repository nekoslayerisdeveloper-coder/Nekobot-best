'use strict';

const { Router } = require('express');
const router = Router();

router.get('/', (req, res) => {
  const guilds = req.client.guilds.cache.map(g => ({
    id: g.id, name: g.name, icon: g.iconURL({ dynamic: true }),
    memberCount: g.memberCount, premiumTier: g.premiumTier,
  }));
  res.json({ guilds, total: guilds.length });
});

router.get('/:guildId', (req, res) => {
  const guild = req.client.guilds.cache.get(req.params.guildId);
  if (!guild) return res.status(404).json({ error: 'Guild not found' });
  res.json({
    id: guild.id, name: guild.name, icon: guild.iconURL({ dynamic: true }),
    memberCount: guild.memberCount, ownerId: guild.ownerId,
    premiumTier: guild.premiumTier, premiumSubscriptionCount: guild.premiumSubscriptionCount,
    channels: guild.channels.cache.size, roles: guild.roles.cache.size,
    emojis: guild.emojis.cache.size, createdAt: guild.createdAt,
  });
});

router.get('/:guildId/config', (req, res) => {
  const config = req.client.db.guild.get(req.params.guildId) || {};
  res.json(config);
});

router.patch('/:guildId/config', (req, res) => {
  const { guildId } = req.params;
  const current = req.client.db.guild.get(guildId) || {};
  const updated = { ...current, ...req.body };
  req.client.db.guild.set(guildId, updated);
  res.json({ success: true, config: updated });
});

router.get('/:guildId/members', (req, res) => {
  const guild = req.client.guilds.cache.get(req.params.guildId);
  if (!guild) return res.status(404).json({ error: 'Guild not found' });
  const limit = Math.min(parseInt(req.query.limit) || 50, 100);
  const members = [...guild.members.cache.values()].slice(0, limit).map(m => ({
    id: m.id, username: m.user.username, tag: m.user.tag,
    avatar: m.user.displayAvatarURL(), roles: m.roles.cache.size,
    joinedAt: m.joinedAt, premiumSince: m.premiumSince, bot: m.user.bot,
  }));
  res.json({ members, total: guild.memberCount });
});

router.get('/:guildId/economy/leaderboard', (req, res) => {
  const { guildId } = req.params;
  const entries = req.client.db.economy.filter((_v, k) => k.startsWith(`${guildId}:`));
  const sorted = entries
    .map(([, v]) => v)
    .sort((a, b) => ((b.wallet || 0) + (b.bank || 0)) - ((a.wallet || 0) + (a.bank || 0)))
    .slice(0, 20);
  res.json({ leaderboard: sorted });
});

router.get('/:guildId/levels/leaderboard', (req, res) => {
  const { guildId } = req.params;
  const entries = req.client.db.user.filter((_v, k) => k.startsWith(`${guildId}:`));
  const sorted = entries
    .map(([, v]) => v)
    .sort((a, b) => (b.xp || 0) - (a.xp || 0))
    .slice(0, 20);
  res.json({ leaderboard: sorted });
});

module.exports = router;
