'use strict';

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
const { Logger: logger } = require('../utils/logger');

const guildRoutes = require('./routes/guilds');
const userRoutes = require('./routes/users');
const statsRoutes = require('./routes/stats');
const commandRoutes = require('./routes/commands');

class ApiServer {
  constructor(client) {
    this.client = client;
    this.app = express();
    this.server = null;
    this._setup();
  }

  _setup() {
    const app = this.app;
    const client = this.client;

    app.use(helmet({ contentSecurityPolicy: false }));
    app.use(cors({ origin: process.env.DASHBOARD_URL || '*', credentials: true }));
    app.use(express.json({ limit: '10mb' }));
    app.use(express.urlencoded({ extended: true }));

    const limiter = rateLimit({ windowMs: 60000, max: 100, standardHeaders: true, legacyHeaders: false });
    app.use('/api/', limiter);

    app.use((req, _res, next) => { req.client = client; next(); });

    const authMiddleware = (req, res, next) => {
      const token = req.headers.authorization?.split(' ')[1];
      if (!token) return res.status(401).json({ error: 'Unauthorized' });
      try {
        req.user = jwt.verify(token, process.env.JWT_SECRET || 'nekobot-secret');
        next();
      } catch {
        res.status(401).json({ error: 'Invalid token' });
      }
    };

    app.get('/api/health', (_req, res) => {
      res.json({ status: 'ok', uptime: process.uptime(), guilds: client.guilds.cache.size, ping: client.ws.ping, timestamp: new Date().toISOString() });
    });

    app.post('/api/auth/token', (req, res) => {
      const { secret } = req.body;
      if (secret !== process.env.API_SECRET) return res.status(403).json({ error: 'Invalid secret' });
      const token = jwt.sign({ type: 'api', iat: Date.now() }, process.env.JWT_SECRET || 'nekobot-secret', { expiresIn: '24h' });
      res.json({ token, expiresIn: 86400 });
    });

    app.use('/api/guilds', authMiddleware, guildRoutes);
    app.use('/api/users', authMiddleware, userRoutes);
    app.use('/api/stats', authMiddleware, statsRoutes);
    app.use('/api/commands', commandRoutes);

    app.use((err, _req, res, _next) => {
      logger.error('API Error:', err);
      res.status(500).json({ error: 'Internal Server Error', message: err.message });
    });

    app.use((_req, res) => res.status(404).json({ error: 'Not Found' }));
  }

  async start() {
    const port = process.env.API_PORT || 3001;
    this.server = this.app.listen(port, () => {
      logger.info(`API Server listening on port ${port}`);
    });
    return this.server;
  }

  async stop() {
    if (this.server) this.server.close();
  }
}

module.exports = { ApiServer };
