'use strict';

const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const { Logger } = require('./utils/logger');
const { DatabaseManager } = require('./database');
const { CommandHandler } = require('./handlers/commandHandler');
const { EventHandler } = require('./handlers/eventHandler');
const { BackupEngine } = require('./database/BackupEngine');
const { ReminderSystem } = require('./systems/ReminderSystem');
const { GiveawaySystem } = require('./systems/GiveawaySystem');
const { ServerStatsSystem } = require('./systems/ServerStatsSystem');
const { PluginSystem } = require('./systems/PluginSystem');
const { DashboardServer } = require('./dashboard/server');
const { ApiServer } = require('./api/server');

class NekoClient extends Client {
  constructor() {
    super({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildModeration,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.GuildEmojisAndStickers,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildInvites,
      ],
      partials: [
        Partials.Message,
        Partials.Channel,
        Partials.Reaction,
        Partials.GuildMember,
        Partials.User,
      ],
      allowedMentions: { parse: ['users', 'roles'], repliedUser: true },
    });

    // Collections
    this.commands = new Collection();
    this.aliases = new Collection();
    this.cooldowns = new Collection();
    this.activeTickets = new Collection();
    this.giveaways = new Collection();
    this.afkUsers = new Collection();
    this.inviteCache = new Collection();
    this.musicPlayers = new Collection();

    // Systems
    this.db = null;
    this.commandHandler = null;
    this.eventHandler = null;
    this.reminderSystem = null;
    this.giveawaySystem = null;
    this.statsSystem = null;
    this.pluginSystem = null;
    this.dashboard = null;
    this.api = null;

    this.startTime = Date.now();
    this.maintenance = false;
    this.blacklistedUsers = new Set();
    this.blacklistedGuilds = new Set();
  }

  async initialize() {
    Logger.info('NekoBot', 'Initializing systems...');

    // 1. Database
    this.db = new DatabaseManager();
    await this.db.initialize();
    Logger.info('Database', 'Encrypted JSON database initialized');

    // 2. Backup engine
    this.backupEngine = new BackupEngine(this.db);
    await this.backupEngine.startAutoBackups();
    Logger.info('Backup', 'Auto-backup engine started');

    // 3. Plugin system
    this.pluginSystem = new PluginSystem(this);
    await this.pluginSystem.loadPlugins();
    Logger.info('Plugins', 'Plugin system initialized');

    // 4. Commands
    this.commandHandler = new CommandHandler(this);
    await this.commandHandler.loadCommands();
    Logger.info('Commands', `Loaded ${this.commands.size} commands`);

    // 5. Events
    this.eventHandler = new EventHandler(this);
    await this.eventHandler.loadEvents();
    Logger.info('Events', 'Event handlers registered');

    // 6. Scheduled systems
    this.reminderSystem = new ReminderSystem(this);
    this.reminderSystem.start();

    this.giveawaySystem = new GiveawaySystem(this);
    this.giveawaySystem.start();

    this.statsSystem = new ServerStatsSystem(this);
    this.statsSystem.start();

    // 7. Dashboard & API
    if (process.env.DASHBOARD_PORT) {
      this.dashboard = new DashboardServer(this);
      await this.dashboard.start();
      Logger.info('Dashboard', `Web dashboard started on port ${process.env.DASHBOARD_PORT}`);
    }

    if (process.env.API_PORT) {
      this.api = new ApiServer(this);
      await this.api.start();
      Logger.info('API', `REST API started on port ${process.env.API_PORT}`);
    }

    Logger.success('NekoBot', 'All systems initialized successfully!');
  }

  // Utility: get guild config
  async getGuildConfig(guildId) {
    return this.db.guild.get(guildId, 'config') || {};
  }

  // Utility: set guild config
  async setGuildConfig(guildId, config) {
    return this.db.guild.set(guildId, 'config', config);
  }

  // Utility: get user data
  async getUserData(userId, guildId) {
    const key = guildId ? `${guildId}:${userId}` : userId;
    return this.db.user.get(key) || {};
  }

  // Utility: set user data
  async setUserData(userId, guildId, data) {
    const key = guildId ? `${guildId}:${userId}` : userId;
    return this.db.user.set(key, data);
  }

  // Get bot uptime in human-readable format
  getUptime() {
    const uptime = Date.now() - this.startTime;
    const d = Math.floor(uptime / 86400000);
    const h = Math.floor((uptime % 86400000) / 3600000);
    const m = Math.floor((uptime % 3600000) / 60000);
    const s = Math.floor((uptime % 60000) / 1000);
    return `${d}d ${h}h ${m}m ${s}s`;
  }

  // Check if user is owner
  isOwner(userId) {
    return userId === process.env.OWNER_ID;
  }

  // Blacklist management
  async blacklistUser(userId, reason) {
    this.blacklistedUsers.add(userId);
    const bl = await this.db.global.get('blacklist') || { users: [], guilds: [] };
    if (!bl.users.find(u => u.id === userId)) {
      bl.users.push({ id: userId, reason, timestamp: Date.now() });
      await this.db.global.set('blacklist', bl);
    }
  }

  async unblacklistUser(userId) {
    this.blacklistedUsers.delete(userId);
    const bl = await this.db.global.get('blacklist') || { users: [], guilds: [] };
    bl.users = bl.users.filter(u => u.id !== userId);
    await this.db.global.set('blacklist', bl);
  }

  async blacklistGuild(guildId, reason) {
    this.blacklistedGuilds.add(guildId);
    const bl = await this.db.global.get('blacklist') || { users: [], guilds: [] };
    if (!bl.guilds.find(g => g.id === guildId)) {
      bl.guilds.push({ id: guildId, reason, timestamp: Date.now() });
      await this.db.global.set('blacklist', bl);
    }
  }

  // Load blacklists from DB on startup
  async loadBlacklists() {
    const bl = await this.db.global.get('blacklist') || { users: [], guilds: [] };
    bl.users.forEach(u => this.blacklistedUsers.add(u.id));
    bl.guilds.forEach(g => this.blacklistedGuilds.add(g.id));
  }
}

module.exports = { NekoClient };
