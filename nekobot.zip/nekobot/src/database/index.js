'use strict';

const path = require('path');
const { DatabaseEngine } = require('./DatabaseEngine');
const { CacheEngine } = require('./CacheEngine');

const DATA_DIR = path.join(process.cwd(), 'data');

class DatabaseManager {
  constructor() {
    this.cache = new CacheEngine({ maxSize: 2000, defaultTtl: 600000 }); // 10min TTL

    // Separate DB files per domain
    this.guild    = new DatabaseEngine(path.join(DATA_DIR, 'guilds.ndb'),    process.env.DB_ENCRYPTION_KEY);
    this.user     = new DatabaseEngine(path.join(DATA_DIR, 'users.ndb'),     process.env.DB_ENCRYPTION_KEY);
    this.economy  = new DatabaseEngine(path.join(DATA_DIR, 'economy.ndb'),   process.env.DB_ENCRYPTION_KEY);
    this.tickets  = new DatabaseEngine(path.join(DATA_DIR, 'tickets.ndb'),   process.env.DB_ENCRYPTION_KEY);
    this.giveaways= new DatabaseEngine(path.join(DATA_DIR, 'giveaways.ndb'), process.env.DB_ENCRYPTION_KEY);
    this.premium  = new DatabaseEngine(path.join(DATA_DIR, 'premium.ndb'),   process.env.DB_ENCRYPTION_KEY);
    this.global   = new DatabaseEngine(path.join(DATA_DIR, 'global.ndb'),    process.env.DB_ENCRYPTION_KEY);
  }

  async initialize() {
    this.guild.load();
    this.user.load();
    this.economy.load();
    this.tickets.load();
    this.giveaways.load();
    this.premium.load();
    this.global.load();

    // Repair on startup
    this.guild.repair();
    this.user.repair();
    this.economy.repair();
    this.tickets.repair();
    this.giveaways.repair();
    this.premium.repair();
    this.global.repair();
  }

  // Cached guild config
  async getGuildConfig(guildId) {
    const cacheKey = `guild:${guildId}:config`;
    return this.cache.getOrSet(cacheKey, () => {
      return this.guild.getPath(guildId, 'config') || {};
    }, 30000);
  }

  async setGuildConfig(guildId, config) {
    if (!this.guild.get(guildId)) this.guild.set(guildId, {});
    const g = this.guild.get(guildId);
    g.config = config;
    this.guild.set(guildId, g);
    this.cache.delete(`guild:${guildId}:config`);
    return config;
  }

  // Cached user profile
  async getUserProfile(userId, guildId) {
    const key = guildId ? `${guildId}:${userId}` : userId;
    const cacheKey = `user:${key}`;
    return this.cache.getOrSet(cacheKey, () => {
      return this.user.get(key) || this._defaultUserProfile(userId, guildId);
    }, 60000);
  }

  async setUserProfile(userId, guildId, data) {
    const key = guildId ? `${guildId}:${userId}` : userId;
    this.user.set(key, data);
    this.cache.delete(`user:${key}`);
    return data;
  }

  _defaultUserProfile(userId, guildId) {
    return {
      userId,
      guildId,
      xp: 0,
      level: 0,
      warns: [],
      afk: null,
      joinedAt: Date.now(),
    };
  }

  // Flush all DBs (for shutdown)
  flushAll() {
    this.guild.flush();
    this.user.flush();
    this.economy.flush();
    this.tickets.flush();
    this.giveaways.flush();
    this.premium.flush();
    this.global.flush();
  }
}

module.exports = { DatabaseManager };
