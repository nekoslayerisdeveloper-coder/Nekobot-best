'use strict';

/**
 * In-memory LRU cache with TTL support
 */
class CacheEngine {
  constructor({ maxSize = 1000, defaultTtl = 300000 } = {}) {
    this.maxSize = maxSize;
    this.defaultTtl = defaultTtl;
    this.cache = new Map();
    this.timers = new Map();
    // Periodic cleanup every 60s
    this._cleanupInterval = setInterval(() => this._cleanup(), 60000);
    this._cleanupInterval.unref();
  }

  _evict() {
    // Remove the oldest entry (LRU approximation)
    const firstKey = this.cache.keys().next().value;
    if (firstKey !== undefined) {
      this._delete(firstKey);
    }
  }

  _delete(key) {
    this.cache.delete(key);
    if (this.timers.has(key)) {
      clearTimeout(this.timers.get(key));
      this.timers.delete(key);
    }
  }

  _cleanup() {
    const now = Date.now();
    for (const [key, entry] of this.cache.entries()) {
      if (entry.expiresAt && entry.expiresAt <= now) {
        this._delete(key);
      }
    }
  }

  set(key, value, ttl = this.defaultTtl) {
    // Evict if at capacity
    if (!this.cache.has(key) && this.cache.size >= this.maxSize) {
      this._evict();
    }

    // Clear existing timer
    if (this.timers.has(key)) {
      clearTimeout(this.timers.get(key));
      this.timers.delete(key);
    }

    const entry = {
      value,
      createdAt: Date.now(),
      expiresAt: ttl > 0 ? Date.now() + ttl : null,
    };
    this.cache.set(key, entry);

    if (ttl > 0) {
      const timer = setTimeout(() => this._delete(key), ttl);
      timer.unref();
      this.timers.set(key, timer);
    }
    return value;
  }

  get(key) {
    const entry = this.cache.get(key);
    if (!entry) return undefined;
    if (entry.expiresAt && entry.expiresAt <= Date.now()) {
      this._delete(key);
      return undefined;
    }
    // Move to end (LRU)
    this.cache.delete(key);
    this.cache.set(key, entry);
    return entry.value;
  }

  has(key) {
    return this.get(key) !== undefined;
  }

  delete(key) {
    this._delete(key);
  }

  clear() {
    for (const timer of this.timers.values()) clearTimeout(timer);
    this.timers.clear();
    this.cache.clear();
  }

  size() {
    return this.cache.size;
  }

  keys() {
    return [...this.cache.keys()];
  }

  // Get or set pattern
  async getOrSet(key, fetchFn, ttl = this.defaultTtl) {
    const cached = this.get(key);
    if (cached !== undefined) return cached;
    const value = await fetchFn();
    if (value !== undefined) this.set(key, value, ttl);
    return value;
  }

  // Stats
  stats() {
    return {
      size: this.cache.size,
      maxSize: this.maxSize,
      keys: this.keys(),
    };
  }

  destroy() {
    clearInterval(this._cleanupInterval);
    this.clear();
  }
}

module.exports = { CacheEngine };
