'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');

const ALGORITHM = 'aes-256-gcm';
const KEY_LENGTH = 32;
const IV_LENGTH = 16;
const AUTH_TAG_LENGTH = 16;
const MAGIC = Buffer.from('NEKODB01');

class DatabaseEngine {
  constructor(filePath, encryptionKey) {
    this.filePath = filePath;
    this.backupPath = filePath + '.bak';
    this.tmpPath = filePath + '.tmp';
    this.key = this._deriveKey(encryptionKey);
    this.data = {};
    this.dirty = false;
    this.saveQueue = null;
    this._ensureDir();
  }

  _ensureDir() {
    const dir = path.dirname(this.filePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  }

  _deriveKey(secret) {
    return crypto.createHash('sha256').update(secret).digest();
  }

  _encrypt(plaintext) {
    const iv = crypto.randomBytes(IV_LENGTH);
    const cipher = crypto.createCipheriv(ALGORITHM, this.key, iv);
    const compressed = zlib.deflateSync(Buffer.from(plaintext, 'utf-8'));
    const encrypted = Buffer.concat([cipher.update(compressed), cipher.final()]);
    const authTag = cipher.getAuthTag();
    // Format: MAGIC(8) + IV(16) + AUTH_TAG(16) + ENCRYPTED(n)
    return Buffer.concat([MAGIC, iv, authTag, encrypted]);
  }

  _decrypt(buffer) {
    if (buffer.length < MAGIC.length + IV_LENGTH + AUTH_TAG_LENGTH) {
      throw new Error('Invalid database file: too short');
    }
    const magic = buffer.slice(0, MAGIC.length);
    if (!magic.equals(MAGIC)) throw new Error('Invalid database file: bad magic');

    const iv = buffer.slice(8, 8 + IV_LENGTH);
    const authTag = buffer.slice(24, 24 + AUTH_TAG_LENGTH);
    const encrypted = buffer.slice(40);

    const decipher = crypto.createDecipheriv(ALGORITHM, this.key, iv);
    decipher.setAuthTag(authTag);
    const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
    const decompressed = zlib.inflateSync(decrypted);
    return decompressed.toString('utf-8');
  }

  load() {
    // Try primary file
    if (fs.existsSync(this.filePath)) {
      try {
        const buf = fs.readFileSync(this.filePath);
        const json = this._decrypt(buf);
        this.data = JSON.parse(json);
        return;
      } catch (err) {
        console.error(`[DB] Primary file corrupt, trying backup: ${err.message}`);
      }
    }

    // Try backup file
    if (fs.existsSync(this.backupPath)) {
      try {
        const buf = fs.readFileSync(this.backupPath);
        const json = this._decrypt(buf);
        this.data = JSON.parse(json);
        console.log('[DB] Restored from backup successfully');
        this.save(); // Write recovered data to primary
        return;
      } catch (err) {
        console.error(`[DB] Backup also corrupt: ${err.message}`);
      }
    }

    // Fresh database
    this.data = {};
  }

  save() {
    try {
      const json = JSON.stringify(this.data);
      const encrypted = this._encrypt(json);

      // Atomic write: write to tmp, then rename
      fs.writeFileSync(this.tmpPath, encrypted);

      // Rotate backup
      if (fs.existsSync(this.filePath)) {
        fs.copyFileSync(this.filePath, this.backupPath);
      }

      fs.renameSync(this.tmpPath, this.filePath);
      this.dirty = false;
    } catch (err) {
      console.error('[DB] Save failed:', err.message);
      throw err;
    }
  }

  // Debounced save (100ms)
  scheduleSave() {
    this.dirty = true;
    if (this.saveQueue) clearTimeout(this.saveQueue);
    this.saveQueue = setTimeout(() => {
      this.save();
      this.saveQueue = null;
    }, 100);
  }

  get(key) {
    return this.data[key];
  }

  set(key, value) {
    this.data[key] = value;
    this.scheduleSave();
    return value;
  }

  delete(key) {
    const existed = key in this.data;
    delete this.data[key];
    if (existed) this.scheduleSave();
    return existed;
  }

  has(key) {
    return key in this.data;
  }

  keys() {
    return Object.keys(this.data);
  }

  values() {
    return Object.values(this.data);
  }

  entries() {
    return Object.entries(this.data);
  }

  size() {
    return Object.keys(this.data).length;
  }

  clear() {
    this.data = {};
    this.scheduleSave();
  }

  // Get nested value using dot notation
  getPath(key, ...paths) {
    let obj = this.data[key];
    for (const p of paths) {
      if (obj == null) return undefined;
      obj = obj[p];
    }
    return obj;
  }

  // Set nested value using dot notation
  setPath(key, nestedKey, value) {
    if (!this.data[key]) this.data[key] = {};
    this.data[key][nestedKey] = value;
    this.scheduleSave();
    return value;
  }

  // Push to array
  push(key, value) {
    if (!Array.isArray(this.data[key])) this.data[key] = [];
    this.data[key].push(value);
    this.scheduleSave();
    return this.data[key];
  }

  // Math operations
  add(key, amount) {
    const current = Number(this.data[key]) || 0;
    this.data[key] = current + amount;
    this.scheduleSave();
    return this.data[key];
  }

  subtract(key, amount) {
    const current = Number(this.data[key]) || 0;
    this.data[key] = current - amount;
    this.scheduleSave();
    return this.data[key];
  }

  // Find entries matching predicate
  filter(predicate) {
    return Object.entries(this.data).filter(([k, v]) => predicate(v, k));
  }

  // Repair: remove all null/undefined top-level keys
  repair() {
    let repaired = 0;
    for (const [k, v] of Object.entries(this.data)) {
      if (v === null || v === undefined) {
        delete this.data[k];
        repaired++;
      }
    }
    if (repaired > 0) {
      this.scheduleSave();
      console.log(`[DB] Repaired ${repaired} corrupt entries`);
    }
    return repaired;
  }

  // Flush immediately (for shutdown)
  flush() {
    if (this.saveQueue) {
      clearTimeout(this.saveQueue);
      this.saveQueue = null;
    }
    if (this.dirty) this.save();
  }

  // Export raw (decrypted) snapshot
  export() {
    return JSON.parse(JSON.stringify(this.data));
  }

  // Import raw snapshot
  import(data) {
    this.data = data;
    this.save();
  }
}

module.exports = { DatabaseEngine };
