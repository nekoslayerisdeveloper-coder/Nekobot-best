'use strict';

const fs = require('fs');
const path = require('path');
const cron = require('node-cron');
const { Logger } = require('../utils/logger');

const BACKUP_DIR = path.join(process.cwd(), 'data', 'backups');
const MAX_BACKUPS = 24; // Keep 24 hourly backups

class BackupEngine {
  constructor(db) {
    this.db = db;
    this._ensureDir();
  }

  _ensureDir() {
    if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });
  }

  async createBackup(label = 'auto') {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupName = `${label}_${timestamp}`;
      const backupPath = path.join(BACKUP_DIR, backupName);
      if (!fs.existsSync(backupPath)) fs.mkdirSync(backupPath, { recursive: true });

      // Export all DBs
      const snapshot = {
        guild: this.db.guild.export(),
        user: this.db.user.export(),
        global: this.db.global.export(),
        economy: this.db.economy.export(),
        tickets: this.db.tickets.export(),
        giveaways: this.db.giveaways.export(),
        premium: this.db.premium.export(),
        timestamp: Date.now(),
        label,
      };

      fs.writeFileSync(
        path.join(backupPath, 'snapshot.json'),
        JSON.stringify(snapshot, null, 2)
      );

      // Write metadata
      fs.writeFileSync(
        path.join(backupPath, 'meta.json'),
        JSON.stringify({ label, timestamp: Date.now(), name: backupName }, null, 2)
      );

      Logger.info('Backup', `Backup created: ${backupName}`);
      this._rotateBackups();
      return backupName;
    } catch (err) {
      Logger.error('Backup', 'Failed to create backup:', err.message);
      throw err;
    }
  }

  async restoreBackup(backupName) {
    const backupPath = path.join(BACKUP_DIR, backupName);
    if (!fs.existsSync(backupPath)) throw new Error(`Backup "${backupName}" not found`);

    const snapshotFile = path.join(backupPath, 'snapshot.json');
    if (!fs.existsSync(snapshotFile)) throw new Error('Backup snapshot missing');

    const snapshot = JSON.parse(fs.readFileSync(snapshotFile, 'utf-8'));

    this.db.guild.import(snapshot.guild || {});
    this.db.user.import(snapshot.user || {});
    this.db.global.import(snapshot.global || {});
    this.db.economy.import(snapshot.economy || {});
    this.db.tickets.import(snapshot.tickets || {});
    this.db.giveaways.import(snapshot.giveaways || {});
    this.db.premium.import(snapshot.premium || {});

    Logger.success('Backup', `Restored from backup: ${backupName}`);
    return snapshot;
  }

  listBackups() {
    if (!fs.existsSync(BACKUP_DIR)) return [];
    return fs.readdirSync(BACKUP_DIR)
      .filter(f => fs.statSync(path.join(BACKUP_DIR, f)).isDirectory())
      .map(name => {
        try {
          const meta = JSON.parse(fs.readFileSync(path.join(BACKUP_DIR, name, 'meta.json'), 'utf-8'));
          return { name, ...meta };
        } catch {
          return { name, label: 'unknown', timestamp: 0 };
        }
      })
      .sort((a, b) => b.timestamp - a.timestamp);
  }

  _rotateBackups() {
    const backups = this.listBackups();
    const autoBackups = backups.filter(b => b.label === 'auto');
    if (autoBackups.length > MAX_BACKUPS) {
      const toDelete = autoBackups.slice(MAX_BACKUPS);
      for (const backup of toDelete) {
        try {
          fs.rmSync(path.join(BACKUP_DIR, backup.name), { recursive: true, force: true });
          Logger.debug('Backup', `Rotated old backup: ${backup.name}`);
        } catch {}
      }
    }
  }

  startAutoBackups() {
    // Every hour
    cron.schedule('0 * * * *', async () => {
      await this.createBackup('auto').catch(e => Logger.error('Backup', e));
    });

    // Daily backup at midnight
    cron.schedule('0 0 * * *', async () => {
      await this.createBackup('daily').catch(e => Logger.error('Backup', e));
    });

    Logger.info('Backup', 'Auto-backup scheduled (hourly + daily)');
  }

  deleteBackup(backupName) {
    const backupPath = path.join(BACKUP_DIR, backupName);
    if (!fs.existsSync(backupPath)) throw new Error(`Backup "${backupName}" not found`);
    fs.rmSync(backupPath, { recursive: true, force: true });
    Logger.info('Backup', `Deleted backup: ${backupName}`);
  }
}

module.exports = { BackupEngine };
