'use strict';

const { LoggingSystem } = require('../systems/LoggingSystem');
const { BoosterSystem } = require('../systems/BoosterSystem');

module.exports = {
  name: 'voiceStateUpdate',
  async execute(client, oldState, newState) {
    const logging = new LoggingSystem(client);
    await logging.logVoiceState(oldState, newState).catch(() => {});
  },
};
