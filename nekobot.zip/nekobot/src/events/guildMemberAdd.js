'use strict';

const { WelcomeSystem } = require('../systems/WelcomeSystem');
const { InviteTrackerSystem } = require('../systems/InviteTrackerSystem');
const { AutoModSystem } = require('../systems/AutoModSystem');
const { Logger } = require('../utils/logger');
const { LoggingSystem } = require('../systems/LoggingSystem');
const { VerificationSystem } = require('../systems/VerificationSystem');

const welcome = new WelcomeSystem(null);
const logging = new LoggingSystem(null);

module.exports = {
  name: 'guildMemberAdd',
  async execute(client, member) {
    welcome.client = client;
    logging.client = client;
    if (!client.inviteTracker) client.inviteTracker = new InviteTrackerSystem(client);

    // Anti-raid detection
    const automod = new AutoModSystem(client);
    const isRaid = automod.trackJoin(member.guild.id);
    if (isRaid) {
      const config = await client.getGuildConfig(member.guild.id);
      const raidChannelId = config.modLogChannel;
      if (raidChannelId) {
        const ch = member.guild.channels.cache.get(raidChannelId);
        if (ch) await ch.send({ content: `⚠️ **RAID ALERT!** Rapid joins detected in ${member.guild.name}. Consider enabling slowmode or lockdown.` }).catch(() => {});
      }
    }

    // Track invite
    const inviteInfo = await client.inviteTracker.trackJoin(member).catch(() => null);

    // Welcome
    await welcome.handleMemberJoin(member).catch(e => Logger.error('GuildMemberAdd', e.message));

    // Logging
    await logging.logMemberJoin(member).catch(() => {});

    // Server stats update
    if (client.statsSystem) client.statsSystem._tick().catch(() => {});

    // Set up verification system if needed
    if (!client.verificationSystem) {
      client.verificationSystem = new VerificationSystem(client);
    }

    Logger.debug('GuildMemberAdd', `${member.user.tag} joined ${member.guild.name}${inviteInfo ? ` (invited by ${inviteInfo.inviter?.tag})` : ''}`);
  },
};
