'use strict';

const { LoggingSystem } = require('../systems/LoggingSystem');

module.exports = {
  name: 'roleCreate',
  async execute(client, role) {
    const logging = new LoggingSystem(client);
    let executor = null;
    try {
      const logs = await role.guild.fetchAuditLogs({ type: 30, limit: 1 });
      const entry = logs.entries.first();
      if (entry && Date.now() - entry.createdTimestamp < 5000) executor = entry.executor;
    } catch {}
    await logging.logRole('Created', role, executor).catch(() => {});
  },
};
