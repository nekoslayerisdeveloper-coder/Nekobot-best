'use strict';

const { ActivityType } = require('discord.js');
const { Logger } = require('../utils/logger');
const { InviteTrackerSystem } = require('../systems/InviteTrackerSystem');
const { AfkSystem } = require('../systems/AfkSystem');
const { MusicSystem } = require('../systems/MusicSystem');
const { PremiumSystem } = require('../systems/PremiumSystem');
const { LicenseSystem } = require('../systems/LicenseSystem');
const { PollSystem } = require('../systems/PollSystem');

module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    Logger.success('Ready', `Logged in as ${client.user.tag}`);
    Logger.info('Ready', `Serving ${client.guilds.cache.size} guilds | ${client.users.cache.size} users`);

    // Set up global systems
    client.inviteTracker = new InviteTrackerSystem(client);
    client.afkSystem = new AfkSystem(client);
    client.premiumSystem = new PremiumSystem(client);
    client.licenseSystem = new LicenseSystem(client);
    client.pollSystem = new PollSystem(client);
    client.pollSystem.start();

    // Load AFKs from DB
    await client.afkSystem.loadAfks(client);

    // Init music
    client.musicSystem = new MusicSystem(client);
    client.musicSystem.init();

    // Cache all guild invites
    for (const guild of client.guilds.cache.values()) {
      await client.inviteTracker.cacheGuildInvites(guild).catch(() => {});
    }

    // Load blacklists
    await client.loadBlacklists().catch(() => {});

    // Set activity
    const activities = [
      { name: '/help | NekoBot', type: ActivityType.Watching },
      { name: `${client.guilds.cache.size} servers`, type: ActivityType.Watching },
      { name: 'with discord.js v14', type: ActivityType.Playing },
    ];
    let i = 0;
    const setActivity = () => {
      const a = activities[i % activities.length];
      client.user.setActivity(a.name, { type: a.type });
      i++;
    };
    setActivity();
    setInterval(setActivity, 30000);

    Logger.success('Ready', '✨ NekoBot is fully operational!');
  },
};
