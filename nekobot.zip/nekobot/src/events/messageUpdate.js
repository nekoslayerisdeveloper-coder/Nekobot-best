'use strict';

const { LoggingSystem } = require('../systems/LoggingSystem');

module.exports = {
  name: 'messageUpdate',
  async execute(client, oldMessage, newMessage) {
    if (newMessage.partial || newMessage.author?.bot) return;
    const logging = new LoggingSystem(client);
    await logging.logMessageEdit(oldMessage, newMessage).catch(() => {});
  },
};
