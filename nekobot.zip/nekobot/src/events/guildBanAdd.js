'use strict';

const { LoggingSystem } = require('../systems/LoggingSystem');

module.exports = {
  name: 'guildBanAdd',
  async execute(client, ban) {
    const logging = new LoggingSystem(client);
    let executor = null;
    try {
      const logs = await ban.guild.fetchAuditLogs({ type: 22, limit: 1 });
      const entry = logs.entries.first();
      if (entry && Date.now() - entry.createdTimestamp < 5000) executor = entry.executor;
    } catch {}
    await logging.logBan(ban.guild, ban.user, executor, ban.reason).catch(() => {});
  },
};
