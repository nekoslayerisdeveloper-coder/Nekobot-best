'use strict';

const { BoosterSystem } = require('../systems/BoosterSystem');

module.exports = {
  name: 'guildMemberUpdate',
  async execute(client, oldMember, newMember) {
    // Boost detection
    const wasBooster = oldMember.premiumSince;
    const isBooster = newMember.premiumSince;
    const bs = new BoosterSystem(client);
    if (!wasBooster && isBooster) {
      await bs.handleBoost(newMember).catch(() => {});
    } else if (wasBooster && !isBooster) {
      await bs.handleUnboost(newMember).catch(() => {});
    }
  },
};
