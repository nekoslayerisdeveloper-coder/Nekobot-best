'use strict';

const { LoggingSystem } = require('../systems/LoggingSystem');

module.exports = {
  name: 'channelCreate',
  async execute(client, channel) {
    if (!channel.guild) return;
    const logging = new LoggingSystem(client);
    let executor = null;
    try {
      const logs = await channel.guild.fetchAuditLogs({ type: 10, limit: 1 });
      const entry = logs.entries.first();
      if (entry && Date.now() - entry.createdTimestamp < 5000) executor = entry.executor;
    } catch {}
    await logging.logChannel('Created', channel, executor).catch(() => {});
  },
};
