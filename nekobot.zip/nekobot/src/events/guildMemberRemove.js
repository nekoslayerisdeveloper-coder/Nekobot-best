'use strict';

const { WelcomeSystem } = require('../systems/WelcomeSystem');
const { LoggingSystem } = require('../systems/LoggingSystem');
const { Logger } = require('../utils/logger');

module.exports = {
  name: 'guildMemberRemove',
  async execute(client, member) {
    const welcome = new WelcomeSystem(client);
    const logging = new LoggingSystem(client);

    await welcome.handleMemberLeave(member).catch(e => Logger.error('GuildMemberRemove', e.message));
    await logging.logMemberLeave(member).catch(() => {});

    if (client.inviteTracker) await client.inviteTracker.trackLeave(member).catch(() => {});
    if (client.statsSystem) client.statsSystem._tick().catch(() => {});

    // Booster system cleanup
    if (member.premiumSince) {
      const { BoosterSystem } = require('../systems/BoosterSystem');
      const bs = new BoosterSystem(client);
      await bs.handleUnboost(member).catch(() => {});
    }
  },
};
