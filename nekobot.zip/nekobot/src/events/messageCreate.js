'use strict';

const { AutoModSystem } = require('../systems/AutoModSystem');
const { Logger } = require('../utils/logger');

const autoMod = new Map(); // guildId -> AutoModSystem instance

module.exports = {
  name: 'messageCreate',
  async execute(client, message) {
    if (message.author.bot) return;
    if (client.maintenance && !client.isOwner(message.author.id)) return;
    if (client.blacklistedUsers.has(message.author.id)) return;

    // AutoMod
    if (message.guild) {
      if (!autoMod.has(message.guild.id)) autoMod.set(message.guild.id, new AutoModSystem(client));
      const am = autoMod.get(message.guild.id);
      await am.handle(message).catch(() => {});
    }

    // AFK system
    if (client.afkSystem) await client.afkSystem.handleMessage(message).catch(() => {});

    // Auto-responses
    if (message.guild) {
      const { AutoResponseSystem } = require('../systems/AutoResponseSystem');
      const ars = new AutoResponseSystem(client);
      await ars.handle(message).catch(() => {});
    }

    // Custom commands (prefix-based)
    if (message.guild) {
      const { CustomCommandSystem } = require('../systems/CustomCommandSystem');
      const ccs = new CustomCommandSystem(client);
      await ccs.handle(message).catch(() => {});
    }

    // Captcha verification
    if (message.guild && client.verificationSystem) {
      await client.verificationSystem.handleCaptchaInput(message).catch(() => {});
    }

    // XP / Leveling
    if (message.guild) {
      const { LevelSystem } = require('../systems/LevelSystem');
      const ls = new LevelSystem(client);
      await ls.handleMessage(message).catch(() => {});
    }
  },
};
