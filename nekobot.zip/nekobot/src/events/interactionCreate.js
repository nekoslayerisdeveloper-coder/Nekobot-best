'use strict';

const { Logger } = require('../utils/logger');
const { Embed } = require('../utils/embed');
const { SecuritySystem } = require('../systems/SecuritySystem');

const security = new SecuritySystem();

module.exports = {
  name: 'interactionCreate',
  async execute(client, interaction) {
    // Blacklist check
    if (client.blacklistedUsers.has(interaction.user.id)) {
      if (interaction.isRepliable()) {
        return interaction.reply({ content: '❌ You are blacklisted from NekoBot.', ephemeral: true });
      }
      return;
    }

    // Maintenance check
    if (client.maintenance && !client.isOwner(interaction.user.id)) {
      if (interaction.isRepliable()) {
        return interaction.reply({ embeds: [Embed.warning('Maintenance Mode', 'NekoBot is currently under maintenance. Please check back later.')], ephemeral: true });
      }
      return;
    }

    // === Slash Commands ===
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;

      // Anti-exploit
      if (security.checkExploit(interaction.user.id, interaction.commandName)) {
        return interaction.reply({ content: '⚠️ Rate limited. Please slow down.', ephemeral: true });
      }

      // Cooldown
      const cooldownKey = `${interaction.user.id}:${command.data.name}`;
      const cooldownMs = (command.cooldown || 3) * 1000;
      const now = Date.now();
      const cooldowns = client.cooldowns;
      const lastUsed = cooldowns.get(cooldownKey) || 0;
      if (now - lastUsed < cooldownMs) {
        const remaining = ((cooldownMs - (now - lastUsed)) / 1000).toFixed(1);
        return interaction.reply({ embeds: [Embed.warning('Cooldown', `Wait **${remaining}s** before using \`/${command.data.name}\` again.`)], ephemeral: true });
      }
      cooldowns.set(cooldownKey, now);

      // Premium check
      if (command.premium && !client.premiumSystem?.isPremium(interaction.user.id) && !client.isOwner(interaction.user.id)) {
        return interaction.reply({ embeds: [Embed.premium('Premium Required', 'This command requires a premium subscription. Use `/premium` to learn more.')], ephemeral: true });
      }

      // Permission check
      if (command.permissions && interaction.guild) {
        const missing = command.permissions.filter(p => !interaction.member?.permissions.has(p));
        if (missing.length > 0 && !client.isOwner(interaction.user.id)) {
          return interaction.reply({ embeds: [Embed.error('Missing Permissions', `You need: ${missing.map(p => `\`${p}\``).join(', ')}`)], ephemeral: true });
        }
      }

      // Bot permission check
      if (command.botPermissions && interaction.guild) {
        const missing = command.botPermissions.filter(p => !interaction.guild.members.me?.permissions.has(p));
        if (missing.length > 0) {
          return interaction.reply({ embeds: [Embed.error('Bot Missing Permissions', `I need: ${missing.map(p => `\`${p}\``).join(', ')}`)], ephemeral: true });
        }
      }

      // Owner-only
      if (command.ownerOnly && !client.isOwner(interaction.user.id)) {
        return interaction.reply({ embeds: [Embed.error('Owner Only', 'This command is restricted to the bot owner.')], ephemeral: true });
      }

      try {
        await command.execute(interaction, client);
      } catch (err) {
        Logger.error('Command', `${interaction.commandName} error:`, err);
        const errEmbed = Embed.error('Command Error', `An error occurred: ${err.message?.slice(0, 500) || 'Unknown error'}`);
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ embeds: [errEmbed], ephemeral: true }).catch(() => {});
        } else {
          await interaction.reply({ embeds: [errEmbed], ephemeral: true }).catch(() => {});
        }
      }
      return;
    }

    // === Buttons ===
    if (interaction.isButton()) {
      const [action, ...args] = interaction.customId.split(':');
      try {
        if (action === 'ticket') {
          const { TicketSystem } = require('../systems/TicketSystem');
          const ts = new TicketSystem(client);
          if (args[0] === 'close')      await ts.closeTicket(interaction, args[1]);
          else if (args[0] === 'claim') await ts.claimTicket(interaction, args[1]);
          else if (args[0] === 'transcript') {
            const html = await ts.generateTranscript(args[1], interaction.guild);
            if (html) {
              const { AttachmentBuilder } = require('discord.js');
              const att = new AttachmentBuilder(Buffer.from(html), { name: `transcript-${args[1]}.html` });
              await interaction.reply({ files: [att], ephemeral: true });
            }
          } else if (args[0] === 'priority') {
            await ts.setPriority(interaction, args[1], 'high');
          }
        } else if (action === 'verify') {
          if (!client.verificationSystem) {
            const { VerificationSystem } = require('../systems/VerificationSystem');
            client.verificationSystem = new VerificationSystem(client);
          }
          await client.verificationSystem.handleVerifyButton(interaction);
        } else if (action === 'giveaway') {
          if (args[0] === 'enter') await client.giveawaySystem.enterGiveaway(interaction);
        } else if (action === 'rr') {
          const { ReactionRoleSystem } = require('../systems/ReactionRoleSystem');
          const rrs = new ReactionRoleSystem(client);
          if (args[0] === 'button') await rrs.handleButtonClick(interaction, args[1]);
        } else if (action === 'sug') {
          const { SuggestionSystem } = require('../systems/SuggestionSystem');
          const ss = new SuggestionSystem(client);
          await ss.handleVote(interaction, args[0], args[1]);
        } else if (action === 'poll') {
          if (args[0] === 'vote') await client.pollSystem.handleVote(interaction, args[1], parseInt(args[2]));
        } else if (action === 'app') {
          const { ApplicationSystem } = require('../systems/ApplicationSystem');
          const as = new ApplicationSystem(client);
          await as.reviewApplication(interaction, args[1], args[0] === 'approve' ? 'approved' : 'rejected');
        } else if (action === 'apply') {
          const { ApplicationSystem } = require('../systems/ApplicationSystem');
          const as = new ApplicationSystem(client);
          await as.showApplicationModal(interaction, args[0]);
        }
      } catch (err) {
        Logger.error('Button', `${interaction.customId} error:`, err.message);
        if (!interaction.replied) await interaction.reply({ content: `Error: ${err.message}`, ephemeral: true }).catch(() => {});
      }
      return;
    }

    // === Select Menus ===
    if (interaction.isStringSelectMenu()) {
      const [action, ...args] = interaction.customId.split(':');
      try {
        if (action === 'ticket' && args[0] === 'open') {
          const { TicketSystem } = require('../systems/TicketSystem');
          const ts = new TicketSystem(client);
          await ts.openTicket(interaction, interaction.values[0]);
        } else if (action === 'rr' && args[0] === 'select') {
          const { ReactionRoleSystem } = require('../systems/ReactionRoleSystem');
          const rrs = new ReactionRoleSystem(client);
          await rrs.handleSelectMenu(interaction);
        }
      } catch (err) {
        Logger.error('Select', `${interaction.customId} error:`, err.message);
        if (!interaction.replied) await interaction.reply({ content: `Error: ${err.message}`, ephemeral: true }).catch(() => {});
      }
      return;
    }

    // === Modals ===
    if (interaction.isModalSubmit()) {
      const [action, ...args] = interaction.customId.split(':');
      try {
        if (action === 'apply') {
          const { ApplicationSystem } = require('../systems/ApplicationSystem');
          const as = new ApplicationSystem(client);
          await as.submitApplication(interaction, args[1]);
        }
      } catch (err) {
        Logger.error('Modal', `${interaction.customId} error:`, err.message);
        if (!interaction.replied) await interaction.reply({ content: `Error: ${err.message}`, ephemeral: true }).catch(() => {});
      }
    }
  },
};
