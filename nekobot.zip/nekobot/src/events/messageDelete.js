'use strict';

const { LoggingSystem } = require('../systems/LoggingSystem');

module.exports = {
  name: 'messageDelete',
  async execute(client, message) {
    if (message.partial || message.author?.bot) return;
    const logging = new LoggingSystem(client);
    await logging.logMessageDelete(message).catch(() => {});
  },
};
