'use strict';

module.exports = {
  name: 'inviteCreate',
  async execute(client, invite) {
    if (!client.inviteTracker) return;
    await client.inviteTracker.cacheGuildInvites(invite.guild).catch(() => {});
  },
};
