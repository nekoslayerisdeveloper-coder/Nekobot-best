'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'moderation',
  permissions: ['ManageMessages'],
  botPermissions: ['ManageMessages'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('purge')
    .setDescription('Delete messages in bulk')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption(o => o.setName('amount').setDescription('Number of messages to delete (1-100)').setMinValue(1).setMaxValue(100).setRequired(true))
    .addUserOption(o => o.setName('user').setDescription('Only delete messages from this user').setRequired(false))
    .addStringOption(o => o.setName('contains').setDescription('Only delete messages containing this text').setRequired(false)),

  async execute(interaction, client) {
    const amount = interaction.options.getInteger('amount');
    const filterUser = interaction.options.getUser('user');
    const contains = interaction.options.getString('contains');
    await interaction.deferReply({ ephemeral: true });

    try {
      let messages = await interaction.channel.messages.fetch({ limit: 100 });
      messages = [...messages.values()].filter(m => {
        if (m.createdTimestamp < Date.now() - 1209600000) return false; // 14 day limit
        if (filterUser && m.author.id !== filterUser.id) return false;
        if (contains && !m.content.includes(contains)) return false;
        return true;
      }).slice(0, amount);

      const deleted = await interaction.channel.bulkDelete(messages, true);
      await interaction.editReply({ embeds: [Embed.success('Messages Purged', `Deleted **${deleted.size}** message(s)${filterUser ? ` from ${filterUser.tag}` : ''}.`)] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Purge Failed', e.message)] });
    }
  },
};
