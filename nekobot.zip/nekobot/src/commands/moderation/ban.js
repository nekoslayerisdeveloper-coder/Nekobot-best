'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { ModerationSystem } = require('../../systems/ModerationSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'moderation',
  permissions: ['BanMembers'],
  botPermissions: ['BanMembers'],
  cooldown: 5,
  examples: ['/ban @user cheating', '/ban @user spam 7'],
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a member from the server')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(o => o.setName('user').setDescription('User to ban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for the ban').setRequired(false))
    .addIntegerOption(o => o.setName('delete_days').setDescription('Days of messages to delete (0-7)').setMinValue(0).setMaxValue(7).setRequired(false)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const deleteDays = interaction.options.getInteger('delete_days') ?? 0;

    if (target.id === interaction.user.id) return interaction.reply({ embeds: [Embed.error('Error', 'You cannot ban yourself.')], ephemeral: true });
    if (target.id === client.user.id) return interaction.reply({ embeds: [Embed.error('Error', 'I cannot ban myself.')], ephemeral: true });
    if (target.id === process.env.OWNER_ID) return interaction.reply({ embeds: [Embed.error('Error', 'Cannot ban the bot owner.')], ephemeral: true });

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (member) {
      if (member.roles.highest.position >= interaction.member.roles.highest.position && !client.isOwner(interaction.user.id)) {
        return interaction.reply({ embeds: [Embed.error('Error', 'You cannot ban someone with a higher or equal role.')], ephemeral: true });
      }
    }

    await interaction.deferReply();
    try {
      // DM the user before banning
      await target.send({ embeds: [Embed.error(`Banned from ${interaction.guild.name}`, `**Reason:** ${reason}\n**Moderator:** ${interaction.user.tag}`)] }).catch(() => {});
      const mod = new ModerationSystem(client);
      await mod.ban(interaction.guild, target, interaction.user, reason, deleteDays);
      await interaction.editReply({ embeds: [Embed.moderation('User Banned', `**${target.tag}** has been banned.\n**Reason:** ${reason}\n**Deleted Messages:** ${deleteDays} day(s)`)] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Ban Failed', e.message)] });
    }
  },
};
