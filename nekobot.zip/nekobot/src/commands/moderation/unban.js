'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { ModerationSystem } = require('../../systems/ModerationSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'moderation',
  permissions: ['BanMembers'],
  botPermissions: ['BanMembers'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Unban a user by their ID')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addStringOption(o => o.setName('user_id').setDescription('The user ID to unban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for unban').setRequired(false)),

  async execute(interaction, client) {
    const userId = interaction.options.getString('user_id');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    await interaction.deferReply();
    try {
      const mod = new ModerationSystem(client);
      await mod.unban(interaction.guild, userId, interaction.user, reason);
      await interaction.editReply({ embeds: [Embed.success('User Unbanned', `User \`${userId}\` has been unbanned.\n**Reason:** ${reason}`)] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Unban Failed', e.message)] });
    }
  },
};
