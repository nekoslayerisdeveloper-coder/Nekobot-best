'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { ModerationSystem } = require('../../systems/ModerationSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'moderation',
  permissions: ['ModerateMembers'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('clearwarns')
    .setDescription('Clear all warnings for a user')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('User to clear warnings for').setRequired(true)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user');
    await interaction.deferReply();
    const key = `${interaction.guild.id}:${target.id}`;
    const data = client.db.user.get(key) || {};
    const count = (data.warns || []).length;
    data.warns = [];
    client.db.user.set(key, data);
    await interaction.editReply({ embeds: [Embed.success('Warnings Cleared', `Cleared **${count}** warning(s) from **${target.tag}**.`)] });
  },
};
