'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Embed } = require('../../utils/embed');
const { checkPermission } = require('../../utils/permissions');

module.exports = {
  category: 'moderation',
  permissions: ['BanMembers'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('softban')
    .setDescription('Softban a user (ban then immediately unban to delete messages)')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(o => o.setName('user').setDescription('User to softban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for softban').setRequired(false)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = interaction.guild.members.cache.get(target.id);

    if (!member) return interaction.reply({ embeds: [Embed.error('Not Found', 'User is not in this server.')], ephemeral: true });
    const permErr = checkPermission(interaction.member, member);
    if (permErr) return interaction.reply({ embeds: [Embed.error('Permission Denied', permErr)], ephemeral: true });

    await interaction.deferReply();
    try {
      await interaction.guild.members.ban(target.id, { reason: `Softban: ${reason}`, deleteMessageSeconds: 86400 });
      await interaction.guild.members.unban(target.id, 'Softban cleanup');
      await interaction.editReply({ embeds: [Embed.moderation('Softban').setDescription(`**${target.username}** has been softbanned.\n**Reason:** ${reason}\n*Their messages from the last 24h were deleted.*`)] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Softban Failed', e.message)] });
    }
  },
};
