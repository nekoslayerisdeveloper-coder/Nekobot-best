'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'moderation',
  permissions: ['ModerateMembers'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('history')
    .setDescription('View moderation history for a user')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('User to look up').setRequired(true)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user');
    await interaction.deferReply();
    const userData = client.db.user.get(`${interaction.guild.id}:${target.id}`) || {};
    const warns = userData.warns || [];
    if (!warns.length) {
      return interaction.editReply({ embeds: [Embed.success('Clean Record', `**${target.username}** has no moderation history.`)] });
    }
    const list = warns.slice(0, 10).map((w, i) =>
      `**#${i + 1}** [${new Date(w.timestamp).toLocaleDateString()}] ${w.reason || 'No reason'} — *by <@${w.moderatorId}>*`
    ).join('\n');
    await interaction.editReply({
      embeds: [Embed.moderation(`📋 Mod History — ${target.username}`)
        .setThumbnail(target.displayAvatarURL({ dynamic: true }))
        .setDescription(list)
        .setFooter({ text: `${warns.length} total actions` })
      ],
    });
  },
};
