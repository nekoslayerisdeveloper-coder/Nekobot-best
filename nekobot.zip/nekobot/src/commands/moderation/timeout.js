'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { ModerationSystem } = require('../../systems/ModerationSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'moderation',
  permissions: ['ModerateMembers'],
  botPermissions: ['ModerateMembers'],
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Apply a timeout to a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('User to timeout').setRequired(true))
    .addStringOption(o => o.setName('duration').setDescription('Duration e.g. 5m, 1h, 7d (max 28d)').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user');
    const duration = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!member) return interaction.reply({ embeds: [Embed.error('Error', 'Member not found.')], ephemeral: true });
    await interaction.deferReply();
    try {
      const mod = new ModerationSystem(client);
      const result = await mod.timeout(interaction.guild, member, interaction.user, duration, reason);
      await interaction.editReply({ embeds: [Embed.moderation('Timeout Applied', `**${target.tag}** timed out for **${result.duration}**.\n**Reason:** ${reason}\n**Expires:** <t:${Math.floor(result.expiresAt / 1000)}:R>`)] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Timeout Failed', e.message)] });
    }
  },
};
