'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { ModerationSystem } = require('../../systems/ModerationSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'moderation',
  permissions: ['KickMembers'],
  botPermissions: ['KickMembers'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a member from the server')
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption(o => o.setName('user').setDescription('User to kick').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for the kick').setRequired(false)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    if (target.id === interaction.user.id) return interaction.reply({ embeds: [Embed.error('Error', 'You cannot kick yourself.')], ephemeral: true });
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!member) return interaction.reply({ embeds: [Embed.error('Error', 'Member not found.')], ephemeral: true });
    if (member.roles.highest.position >= interaction.member.roles.highest.position && !client.isOwner(interaction.user.id)) {
      return interaction.reply({ embeds: [Embed.error('Error', 'Cannot kick someone with higher or equal role.')], ephemeral: true });
    }
    await interaction.deferReply();
    try {
      await target.send({ embeds: [Embed.error(`Kicked from ${interaction.guild.name}`, `**Reason:** ${reason}`)] }).catch(() => {});
      const mod = new ModerationSystem(client);
      await mod.kick(interaction.guild, member, interaction.user, reason);
      await interaction.editReply({ embeds: [Embed.moderation('User Kicked', `**${target.tag}** has been kicked.\n**Reason:** ${reason}`)] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Kick Failed', e.message)] });
    }
  },
};
