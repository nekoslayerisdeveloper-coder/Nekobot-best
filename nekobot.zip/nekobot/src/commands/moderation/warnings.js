'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { ModerationSystem } = require('../../systems/ModerationSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'moderation',
  permissions: ['ModerateMembers'],
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('View warnings for a user')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('User to check').setRequired(true)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user');
    await interaction.deferReply();
    const mod = new ModerationSystem(client);
    const warns = await mod.getWarns(interaction.guild, target);
    if (warns.length === 0) {
      return interaction.editReply({ embeds: [Embed.success('No Warnings', `**${target.tag}** has no warnings.`)] });
    }
    const warnList = warns.slice(-10).map((w, i) =>
      `**#${warns.length - warns.slice(-10).length + i + 1}** \`${w.id}\`\n> ${w.reason}\n> By <@${w.moderatorId}> • <t:${Math.floor(w.timestamp / 1000)}:R>`
    ).join('\n\n');
    await interaction.editReply({ embeds: [Embed.moderation(`Warnings for ${target.username}`, warnList).addFields({ name: 'Total', value: `${warns.length}`, inline: true })] });
  },
};
