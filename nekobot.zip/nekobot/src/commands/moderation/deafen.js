'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'moderation',
  permissions: ['MuteMembers'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('deafen')
    .setDescription('Deafen or undeafen a user in voice')
    .setDefaultMemberPermissions(PermissionFlagsBits.MuteMembers)
    .addUserOption(o => o.setName('user').setDescription('User to deafen').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false)),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = interaction.guild.members.cache.get(target.id);
    if (!member?.voice.channel) return interaction.reply({ embeds: [Embed.error('Not in Voice', `${target.username} is not in a voice channel.`)], ephemeral: true });
    const deafened = member.voice.serverDeaf;
    await member.voice.setDeaf(!deafened, reason);
    const action = deafened ? 'Undeafened' : 'Deafened';
    await interaction.reply({ embeds: [Embed.moderation(`🔇 ${action}`).setDescription(`**${target.username}** has been ${action.toLowerCase()}.\n**Reason:** ${reason}`)] });
  },
};
