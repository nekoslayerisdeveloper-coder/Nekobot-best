'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { ModerationSystem } = require('../../systems/ModerationSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'moderation',
  permissions: ['ModerateMembers'],
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('User to warn').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for the warning').setRequired(true)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');
    if (target.id === interaction.user.id) return interaction.reply({ embeds: [Embed.error('Error', 'Cannot warn yourself.')], ephemeral: true });
    if (target.bot) return interaction.reply({ embeds: [Embed.error('Error', 'Cannot warn a bot.')], ephemeral: true });
    await interaction.deferReply();
    try {
      const mod = new ModerationSystem(client);
      const { warnId, warnCount } = await mod.warn(interaction.guild, target, interaction.user, reason);
      await target.send({ embeds: [Embed.warning(`Warning in ${interaction.guild.name}`, `**Reason:** ${reason}\n**Warn #:** ${warnCount}\n**Moderator:** ${interaction.user.tag}`)] }).catch(() => {});
      await interaction.editReply({ embeds: [Embed.moderation('Warning Issued', `**${target.tag}** has been warned.\n**Reason:** ${reason}\n**Total Warns:** ${warnCount}\n**Case ID:** \`${warnId}\``)] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Warn Failed', e.message)] });
    }
  },
};
