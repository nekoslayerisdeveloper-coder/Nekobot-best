'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { ModerationSystem } = require('../../systems/ModerationSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'moderation',
  permissions: ['ManageMessages'],
  botPermissions: ['ManageMessages'],
  cooldown: 10,
  data: new SlashCommandBuilder()
    .setName('nuke')
    .setDescription('Delete up to 100 messages from a channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption(o => o.setName('amount').setDescription('Number of messages to delete (1-100)').setMinValue(1).setMaxValue(100).setRequired(false))
    .addChannelOption(o => o.setName('channel').setDescription('Channel to nuke (defaults to current)').setRequired(false)),

  async execute(interaction, client) {
    const amount = interaction.options.getInteger('amount') ?? 100;
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    await interaction.deferReply({ ephemeral: true });
    try {
      const mod = new ModerationSystem(client);
      const deleted = await mod.nuke(channel, interaction.user, amount);
      await interaction.editReply({ embeds: [Embed.success('Channel Nuked', `Deleted **${deleted}** messages from ${channel}.`)] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Nuke Failed', e.message)] });
    }
  },
};
