'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { ModerationSystem } = require('../../systems/ModerationSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'moderation',
  permissions: ['ModerateMembers'],
  botPermissions: ['ModerateMembers'],
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Timeout (mute) a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('User to mute').setRequired(true))
    .addStringOption(o => o.setName('duration').setDescription('Duration e.g. 10m, 1h, 1d').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user');
    const duration = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!member) return interaction.reply({ embeds: [Embed.error('Error', 'Member not found.')], ephemeral: true });
    await interaction.deferReply();
    try {
      const mod = new ModerationSystem(client);
      const result = await mod.timeout(interaction.guild, member, interaction.user, duration, reason);
      await target.send({ embeds: [Embed.warning(`Muted in ${interaction.guild.name}`, `**Reason:** ${reason}\n**Duration:** ${result.duration}`)] }).catch(() => {});
      await interaction.editReply({ embeds: [Embed.moderation('User Muted', `**${target.tag}** has been muted for **${result.duration}**.\n**Reason:** ${reason}`)] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Mute Failed', e.message)] });
    }
  },
};
