'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { ModerationSystem } = require('../../systems/ModerationSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'moderation',
  permissions: ['ManageChannels'],
  botPermissions: ['ManageChannels'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('unlock')
    .setDescription('Unlock a channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addChannelOption(o => o.setName('channel').setDescription('Channel to unlock (defaults to current)').setRequired(false))
    .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false)),

  async execute(interaction, client) {
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    const reason = interaction.options.getString('reason') || 'No reason provided';
    await interaction.deferReply();
    try {
      const mod = new ModerationSystem(client);
      await mod.unlockChannel(channel, interaction.user, reason);
      await interaction.editReply({ embeds: [Embed.success('Channel Unlocked', `${channel} has been unlocked.\n**Reason:** ${reason}`)] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Unlock Failed', e.message)] });
    }
  },
};
