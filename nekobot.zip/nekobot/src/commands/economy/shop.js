'use strict';

const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { EconomySystem, SHOP_ITEMS } = require('../../systems/EconomySystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'economy',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('shop')
    .setDescription('View the item shop'),

  async execute(interaction, client) {
    const eco = new EconomySystem(client);
    const userData = await eco.getUser(interaction.user.id, interaction.guild.id);
    const items = eco.getShop();
    const itemList = items.map(item =>
      `**${item.name}** — \`${item.price.toLocaleString()} coins\`\n> ${item.description}\n> ID: \`${item.id}\``
    ).join('\n\n');
    await interaction.reply({
      embeds: [Embed.economy('🛒 Item Shop')
        .setDescription(itemList)
        .addFields({ name: '💰 Your Balance', value: `${userData.wallet.toLocaleString()} coins`, inline: true })
        .setFooter({ text: 'Use /buy <item_id> to purchase an item' })
      ],
    });
  },
};
