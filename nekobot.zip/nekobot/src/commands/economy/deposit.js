'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { EconomySystem } = require('../../systems/EconomySystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'economy',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('deposit')
    .setDescription('Deposit coins into your bank')
    .addStringOption(o => o.setName('amount').setDescription('Amount to deposit or "all"').setRequired(true)),

  async execute(interaction, client) {
    const amount = interaction.options.getString('amount');
    await interaction.deferReply();
    const eco = new EconomySystem(client);
    try {
      const { deposited, data } = await eco.deposit(interaction.user.id, interaction.guild.id, amount);
      await interaction.editReply({ embeds: [Embed.economy('Deposit Successful').addFields({ name: 'Deposited', value: `**${deposited.toLocaleString()}** coins`, inline: true }, { name: '🏦 Bank', value: `**${data.bank.toLocaleString()}** / **${data.bankLimit.toLocaleString()}**`, inline: true })] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Deposit Failed', e.message)] });
    }
  },
};
