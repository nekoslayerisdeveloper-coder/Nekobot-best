'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { EconomySystem } = require('../../systems/EconomySystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'economy',
  cooldown: 30,
  data: new SlashCommandBuilder()
    .setName('rob')
    .setDescription('Attempt to rob another user\'s wallet')
    .addUserOption(o => o.setName('user').setDescription('User to rob').setRequired(true)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user');
    if (target.id === interaction.user.id) return interaction.reply({ embeds: [Embed.error('Error', 'Cannot rob yourself.')], ephemeral: true });
    if (target.bot) return interaction.reply({ embeds: [Embed.error('Error', 'Cannot rob a bot.')], ephemeral: true });
    await interaction.deferReply();
    const eco = new EconomySystem(client);
    try {
      const result = await eco.rob(interaction.user.id, target.id, interaction.guild.id);
      if (result.success) {
        await interaction.editReply({ embeds: [Embed.economy('Heist Successful! 🦝').setDescription(`You stole **${result.amount.toLocaleString()} coins** from ${target}!`).setColor(0x2ECC71)] });
      } else {
        await interaction.editReply({ embeds: [Embed.error('Caught! 👮', `You were caught trying to rob ${target}! You paid a fine of **${result.fine.toLocaleString()} coins**.`)] });
      }
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Rob Failed', e.message)] });
    }
  },
};
