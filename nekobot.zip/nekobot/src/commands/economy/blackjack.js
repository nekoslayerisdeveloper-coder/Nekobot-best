'use strict';

const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { EconomySystem } = require('../../systems/EconomySystem');
const { Embed } = require('../../utils/embed');

const SUITS = ['♠', '♥', '♦', '♣'];
const VALUES = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
const activeSessions = new Map();

function createDeck() {
  const deck = [];
  for (const s of SUITS) for (const v of VALUES) deck.push({ suit: s, value: v });
  for (let i = deck.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [deck[i], deck[j]] = [deck[j], deck[i]]; }
  return deck;
}

function cardValue(card) {
  if (['J', 'Q', 'K'].includes(card.value)) return 10;
  if (card.value === 'A') return 11;
  return parseInt(card.value);
}

function handValue(hand) {
  let total = hand.reduce((s, c) => s + cardValue(c), 0);
  let aces = hand.filter(c => c.value === 'A').length;
  while (total > 21 && aces-- > 0) total -= 10;
  return total;
}

function formatHand(hand, hideSecond = false) {
  return hand.map((c, i) => (hideSecond && i === 1 ? '🂠' : `${c.value}${c.suit}`)).join(' ');
}

module.exports = {
  category: 'economy',
  cooldown: 10,
  data: new SlashCommandBuilder()
    .setName('blackjack')
    .setDescription('Play a game of blackjack')
    .addIntegerOption(o => o.setName('bet').setDescription('Bet amount').setMinValue(10).setRequired(true)),

  async execute(interaction, client) {
    const bet = interaction.options.getInteger('bet');
    const eco = new EconomySystem(client);
    const guildId = interaction.guild.id;
    const userData = await eco.getUser(interaction.user.id, guildId);
    if (userData.wallet < bet) return interaction.reply({ embeds: [Embed.error('Insufficient Funds', `You need $${bet} in your wallet. You have $${userData.wallet}.`)], ephemeral: true });

    await eco.removeMoney(interaction.user.id, guildId, bet, 'blackjack-bet');

    const deck = createDeck();
    const playerHand = [deck.pop(), deck.pop()];
    const dealerHand = [deck.pop(), deck.pop()];
    const gameId = interaction.user.id;
    activeSessions.set(gameId, { deck, playerHand, dealerHand, bet });

    const playerVal = handValue(playerHand);
    if (playerVal === 21) {
      const winnings = Math.floor(bet * 2.5);
      await eco.addMoney(interaction.user.id, guildId, winnings, 'blackjack-win');
      activeSessions.delete(gameId);
      return interaction.reply({ embeds: [Embed.economy('🃏 Blackjack! You Win!').addFields({ name: 'Your Hand', value: `${formatHand(playerHand)} (21)` }, { name: '💰 Won', value: `$${winnings}` })] });
    }

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('bj:hit').setLabel('Hit').setStyle(ButtonStyle.Primary).setEmoji('🃏'),
      new ButtonBuilder().setCustomId('bj:stand').setLabel('Stand').setStyle(ButtonStyle.Secondary).setEmoji('✋'),
      new ButtonBuilder().setCustomId('bj:double').setLabel('Double Down').setStyle(ButtonStyle.Success).setEmoji('💰'),
    );

    const embed = Embed.economy('🃏 Blackjack')
      .addFields(
        { name: '🃏 Your Hand', value: `${formatHand(playerHand)} **(${playerVal})**`, inline: true },
        { name: '🎩 Dealer Hand', value: `${formatHand(dealerHand, true)} **(?)**`, inline: true },
        { name: '💰 Bet', value: `$${bet}`, inline: true },
      );

    const msg = await interaction.reply({ embeds: [embed], components: [row], fetchReply: true });

    const collector = msg.createMessageComponentCollector({ filter: i => i.user.id === interaction.user.id, time: 60000 });
    collector.on('collect', async i => {
      const session = activeSessions.get(gameId);
      if (!session) return;

      if (i.customId === 'bj:hit' || i.customId === 'bj:double') {
        if (i.customId === 'bj:double') {
          if (userData.wallet < bet) { await i.reply({ content: "You don't have enough for double down!", ephemeral: true }); return; }
          await eco.removeMoney(interaction.user.id, guildId, bet, 'blackjack-double');
          session.bet *= 2;
        }
        session.playerHand.push(session.deck.pop());
        const pv = handValue(session.playerHand);
        if (pv >= 21 || i.customId === 'bj:double') { collector.stop('done'); return i.deferUpdate(); }
        await i.update({ embeds: [Embed.economy('🃏 Blackjack').addFields({ name: '🃏 Your Hand', value: `${formatHand(session.playerHand)} **(${pv})**`, inline: true }, { name: '🎩 Dealer Hand', value: `${formatHand(session.dealerHand, true)} **(?)**`, inline: true }, { name: '💰 Bet', value: `$${session.bet}`, inline: true })], components: [row] });
      } else if (i.customId === 'bj:stand') {
        collector.stop('done');
        await i.deferUpdate();
      }
    });

    collector.on('end', async () => {
      const session = activeSessions.get(gameId);
      if (!session) return;
      activeSessions.delete(gameId);
      const { playerHand: pH, dealerHand: dH, deck: d, bet: b } = session;
      while (handValue(dH) < 17) dH.push(d.pop());
      const pv = handValue(pH), dv = handValue(dH);
      let result, winnings = 0;
      if (pv > 21) { result = '💀 Bust! You lose.'; }
      else if (dv > 21 || pv > dv) { winnings = b * 2; result = `🎉 You win $${winnings}!`; await eco.addMoney(interaction.user.id, guildId, winnings, 'blackjack-win'); }
      else if (pv === dv) { winnings = b; result = `🤝 Push! Bet returned.`; await eco.addMoney(interaction.user.id, guildId, winnings, 'blackjack-push'); }
      else { result = `😢 Dealer wins.`; }
      const finalEmbed = Embed.economy('🃏 Blackjack — Game Over').addFields({ name: '🃏 Your Hand', value: `${formatHand(pH)} **(${pv})**`, inline: true }, { name: '🎩 Dealer Hand', value: `${formatHand(dH)} **(${dv})**`, inline: true }, { name: '📊 Result', value: result, inline: false });
      await interaction.editReply({ embeds: [finalEmbed], components: [] });
    });
  },
};
