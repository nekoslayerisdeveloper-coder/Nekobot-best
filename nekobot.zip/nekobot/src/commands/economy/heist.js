'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { EconomySystem } = require('../../systems/EconomySystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'economy',
  cooldown: 300,
  data: new SlashCommandBuilder()
    .setName('heist')
    .setDescription('Plan and execute a bank heist with other members')
    .addIntegerOption(o => o.setName('amount').setDescription('Amount to steal').setMinValue(100).setRequired(true)),

  async execute(interaction, client) {
    await interaction.deferReply();
    const eco = new EconomySystem(client);
    const guildId = interaction.guild.id;
    const amount = interaction.options.getInteger('amount');
    const data = await eco.getUser(interaction.user.id, guildId);

    const membersCount = interaction.guild.memberCount;
    const successChance = Math.min(0.7, 0.2 + (membersCount / 1000) * 0.5);
    const success = Math.random() < successChance;

    if (success) {
      const earned = Math.floor(amount * (1 + Math.random() * 0.5));
      await eco.addMoney(interaction.user.id, guildId, earned, 'heist');
      await interaction.editReply({
        embeds: [Embed.economy('🏦 Heist Successful!')
          .setDescription('Your crew executed the heist perfectly!')
          .addFields(
            { name: '🎯 Target', value: `$${amount.toLocaleString()}`, inline: true },
            { name: '💰 Stolen', value: `$${earned.toLocaleString()}`, inline: true },
            { name: '📊 Success Chance', value: `${Math.floor(successChance * 100)}%`, inline: true },
          )
        ],
      });
    } else {
      const fine = Math.floor(data.wallet * 0.15);
      await eco.removeMoney(interaction.user.id, guildId, Math.min(fine, data.wallet), 'heist-fine').catch(() => {});
      await interaction.editReply({
        embeds: [Embed.error('Heist Failed!', `The police caught your crew! You were fined **$${fine.toLocaleString()}**.\n\nBetter luck next time.`)],
      });
    }
  },
};
