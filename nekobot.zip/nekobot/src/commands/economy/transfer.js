'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { EconomySystem } = require('../../systems/EconomySystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'economy',
  cooldown: 10,
  data: new SlashCommandBuilder()
    .setName('transfer')
    .setDescription('Transfer coins to another user')
    .addUserOption(o => o.setName('user').setDescription('User to transfer to').setRequired(true))
    .addIntegerOption(o => o.setName('amount').setDescription('Amount to transfer').setMinValue(1).setRequired(true)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');
    if (target.id === interaction.user.id) return interaction.reply({ embeds: [Embed.error('Error', 'Cannot transfer to yourself.')], ephemeral: true });
    if (target.bot) return interaction.reply({ embeds: [Embed.error('Error', 'Cannot transfer to a bot.')], ephemeral: true });
    await interaction.deferReply();
    const eco = new EconomySystem(client);
    try {
      const { from } = await eco.transfer(interaction.user.id, target.id, interaction.guild.id, amount);
      await interaction.editReply({ embeds: [Embed.economy('Transfer Successful!').setDescription(`You transferred **${amount.toLocaleString()} coins** to ${target}.\n**Your new balance:** ${from.wallet.toLocaleString()} coins`)] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Transfer Failed', e.message)] });
    }
  },
};
