'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { EconomySystem } = require('../../systems/EconomySystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'economy',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('coinflip')
    .setDescription('Bet coins on a coin flip')
    .addStringOption(o => o.setName('side').setDescription('heads or tails').setRequired(true).addChoices({ name: 'Heads', value: 'heads' }, { name: 'Tails', value: 'tails' }))
    .addIntegerOption(o => o.setName('amount').setDescription('Amount to bet').setMinValue(10).setRequired(true)),

  async execute(interaction, client) {
    const side = interaction.options.getString('side');
    const amount = interaction.options.getInteger('amount');
    await interaction.deferReply();
    const eco = new EconomySystem(client);
    const data = await eco.getUser(interaction.user.id, interaction.guild.id);
    if (data.wallet < amount) return interaction.editReply({ embeds: [Embed.error('Insufficient Funds', `You only have **${data.wallet.toLocaleString()}** coins.`)] });
    const result = Math.random() > 0.5 ? 'heads' : 'tails';
    const win = result === side;
    if (win) {
      await eco.addMoney(interaction.user.id, interaction.guild.id, amount, 'coinflip');
    } else {
      await eco.removeMoney(interaction.user.id, interaction.guild.id, amount, 'coinflip');
    }
    const newData = await eco.getUser(interaction.user.id, interaction.guild.id);
    await interaction.editReply({
      embeds: [Embed.economy(win ? '🪙 You Won!' : '🪙 You Lost!')
        .setDescription(`The coin landed on **${result}**! You chose **${side}**.\n${win ? `You won **+${amount.toLocaleString()} coins**!` : `You lost **-${amount.toLocaleString()} coins**.`}`)
        .addFields({ name: '💰 Balance', value: `${newData.wallet.toLocaleString()} coins`, inline: true })
        .setColor(win ? 0x2ECC71 : 0xE74C3C)],
    });
  },
};
