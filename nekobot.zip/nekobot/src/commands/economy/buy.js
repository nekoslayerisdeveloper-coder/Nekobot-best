'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { EconomySystem } = require('../../systems/EconomySystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'economy',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('buy')
    .setDescription('Buy an item from the shop')
    .addStringOption(o => o.setName('item').setDescription('Item ID to buy').setRequired(true).addChoices(
      { name: 'Role Color Change', value: 'role_color' },
      { name: 'VIP Tag', value: 'vip_tag' },
      { name: 'Loot Box', value: 'lootbox' },
      { name: 'Shield', value: 'shield' },
      { name: 'XP Multiplier', value: 'multiplier' },
    )),

  async execute(interaction, client) {
    const itemId = interaction.options.getString('item');
    await interaction.deferReply();
    const eco = new EconomySystem(client);
    try {
      const result = await eco.buyItem(interaction.user.id, interaction.guild.id, itemId);
      let desc = `You bought **${result.item.name}** for **${result.item.price.toLocaleString()} coins**.`;
      if (result.lootboxReward) desc += `\n\n🎰 The loot box contained **${result.lootboxReward.toLocaleString()} coins**!`;
      await interaction.editReply({ embeds: [Embed.economy('Purchase Successful!').setDescription(desc)] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Purchase Failed', e.message)] });
    }
  },
};
