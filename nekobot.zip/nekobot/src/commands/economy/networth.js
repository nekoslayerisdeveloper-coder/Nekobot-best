'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { EconomySystem } = require('../../systems/EconomySystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'economy',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('networth')
    .setDescription("View your or another user's net worth")
    .addUserOption(o => o.setName('user').setDescription('User to check').setRequired(false)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user') || interaction.user;
    const eco = new EconomySystem(client);
    const data = await eco.getUser(target.id, interaction.guild.id);
    const total = (data.wallet || 0) + (data.bank || 0);
    await interaction.reply({
      embeds: [Embed.economy(`💎 ${target.username}'s Net Worth`)
        .setThumbnail(target.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '👛 Wallet', value: `$${(data.wallet || 0).toLocaleString()}`, inline: true },
          { name: '🏦 Bank', value: `$${(data.bank || 0).toLocaleString()}`, inline: true },
          { name: '📊 Total', value: `**$${total.toLocaleString()}**`, inline: true },
          { name: '🏦 Bank Limit', value: `$${(data.bankLimit || 10000).toLocaleString()}`, inline: true },
        )
      ],
    });
  },
};
