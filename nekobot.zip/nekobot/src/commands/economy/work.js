'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { EconomySystem } = require('../../systems/EconomySystem');
const { Embed } = require('../../utils/embed');

const WORK_MESSAGES = [
  'You worked as a {job} and earned **{amount} coins**!',
  'After a long shift as a {job}, you take home **{amount} coins**.',
  'Your skills as a {job} earned you **{amount} coins** today!',
  'Another day, another paycheck! As a {job} you made **{amount} coins**.',
];

module.exports = {
  category: 'economy',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('work')
    .setDescription('Work to earn coins'),

  async execute(interaction, client) {
    await interaction.deferReply();
    const eco = new EconomySystem(client);
    try {
      const { job, earned } = await eco.work(interaction.user.id, interaction.guild.id);
      const msg = WORK_MESSAGES[Math.floor(Math.random() * WORK_MESSAGES.length)]
        .replace('{job}', job.name)
        .replace('{amount}', earned.toLocaleString());
      await interaction.editReply({ embeds: [Embed.economy('Work Complete!').setDescription(msg).addFields({ name: '💼 Job', value: job.name, inline: true }, { name: '💰 Earned', value: `${earned.toLocaleString()} coins`, inline: true })] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Work Failed', e.message)] });
    }
  },
};
