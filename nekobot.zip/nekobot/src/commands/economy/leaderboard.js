'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { EconomySystem } = require('../../systems/EconomySystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'economy',
  cooldown: 10,
  data: new SlashCommandBuilder()
    .setName('richest')
    .setDescription('View the richest members in the server'),

  async execute(interaction, client) {
    await interaction.deferReply();
    const eco = new EconomySystem(client);
    const top = await eco.getLeaderboard(interaction.guild.id, 10);
    if (top.length === 0) return interaction.editReply({ embeds: [Embed.economy('Leaderboard', 'No economy data yet!')] });
    const list = await Promise.all(top.map(async (entry, i) => {
      let tag = entry.userId;
      try { const u = await client.users.fetch(entry.userId); tag = u.username; } catch {}
      const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `**${i + 1}.**`;
      return `${medal} **${tag}** — ${(entry.wallet + entry.bank).toLocaleString()} coins`;
    }));
    await interaction.editReply({ embeds: [Embed.economy('💰 Richest Members').setDescription(list.join('\n'))] });
  },
};
