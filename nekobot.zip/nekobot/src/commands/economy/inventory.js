'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { EconomySystem } = require('../../systems/EconomySystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'economy',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('inventory')
    .setDescription('View your inventory')
    .addUserOption(o => o.setName('user').setDescription('User to check (defaults to you)').setRequired(false)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user') || interaction.user;
    await interaction.deferReply();
    const eco = new EconomySystem(client);
    const data = await eco.getUser(target.id, interaction.guild.id);
    const inv = data.inventory || [];
    if (inv.length === 0) {
      return interaction.editReply({ embeds: [Embed.economy(`${target.username}'s Inventory`, 'Your inventory is empty. Use `/shop` to buy items!')] });
    }
    const itemList = inv.map(item => `**${item.name}** — Bought <t:${Math.floor(item.boughtAt / 1000)}:R>\n> ${item.description}`).join('\n\n');
    await interaction.editReply({ embeds: [Embed.economy(`🎒 ${target.username}'s Inventory`).setDescription(itemList).addFields({ name: 'Total Items', value: `${inv.length}`, inline: true }).setThumbnail(target.displayAvatarURL({ dynamic: true }))] });
  },
};
