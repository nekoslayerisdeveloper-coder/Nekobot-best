'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { EconomySystem } = require('../../systems/EconomySystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'economy',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('Check your or another user\'s balance')
    .addUserOption(o => o.setName('user').setDescription('User to check (defaults to you)').setRequired(false)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user') || interaction.user;
    await interaction.deferReply();
    const eco = new EconomySystem(client);
    const data = await eco.getUser(target.id, interaction.guild.id);
    const total = data.wallet + data.bank;
    await interaction.editReply({
      embeds: [
        Embed.economy(`💰 ${target.username}'s Balance`)
          .addFields(
            { name: '👛 Wallet', value: `**${data.wallet.toLocaleString()}** coins`, inline: true },
            { name: '🏦 Bank', value: `**${data.bank.toLocaleString()}** / **${data.bankLimit.toLocaleString()}** coins`, inline: true },
            { name: '💎 Net Worth', value: `**${total.toLocaleString()}** coins`, inline: true },
            { name: '💼 Job', value: data.job || 'Unemployed', inline: true },
            { name: '🔥 Daily Streak', value: `${data.streak || 0} days`, inline: true },
          )
          .setThumbnail(target.displayAvatarURL({ dynamic: true }))
      ],
    });
  },
};
