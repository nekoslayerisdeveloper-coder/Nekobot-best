'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { EconomySystem } = require('../../systems/EconomySystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'economy',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('daily')
    .setDescription('Claim your daily coins reward'),

  async execute(interaction, client) {
    await interaction.deferReply();
    const eco = new EconomySystem(client);
    try {
      const { amount, streak } = await eco.daily(interaction.user.id, interaction.guild.id);
      const streakBonus = streak >= 7 ? '🔥 x2 bonus!' : streak >= 3 ? '⚡ x1.5 bonus!' : '';
      await interaction.editReply({
        embeds: [Embed.economy('Daily Reward Claimed!')
          .setDescription(`You received **${amount.toLocaleString()} coins**! ${streakBonus}`)
          .addFields(
            { name: '🔥 Streak', value: `${streak} day(s)`, inline: true },
            { name: '⏰ Next Daily', value: '<t:' + Math.floor((Date.now() + 86400000) / 1000) + ':R>', inline: true },
          )
        ],
      });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Daily Failed', e.message)] });
    }
  },
};
