'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { EconomySystem } = require('../../systems/EconomySystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'economy',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('withdraw')
    .setDescription('Withdraw coins from your bank')
    .addStringOption(o => o.setName('amount').setDescription('Amount to withdraw or "all"').setRequired(true)),

  async execute(interaction, client) {
    const amount = interaction.options.getString('amount');
    await interaction.deferReply();
    const eco = new EconomySystem(client);
    try {
      const { withdrawn, data } = await eco.withdraw(interaction.user.id, interaction.guild.id, amount);
      await interaction.editReply({ embeds: [Embed.economy('Withdrawal Successful').addFields({ name: 'Withdrawn', value: `**${withdrawn.toLocaleString()}** coins`, inline: true }, { name: '👛 Wallet', value: `**${data.wallet.toLocaleString()}** coins`, inline: true })] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Withdrawal Failed', e.message)] });
    }
  },
};
