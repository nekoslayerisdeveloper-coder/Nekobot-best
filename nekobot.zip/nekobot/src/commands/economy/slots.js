'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { EconomySystem } = require('../../systems/EconomySystem');
const { Embed } = require('../../utils/embed');

const SYMBOLS = ['🍒', '🍋', '🍊', '🍇', '⭐', '💎', '7️⃣'];
const PAYOUTS = { '💎': 20, '7️⃣': 15, '⭐': 10, '🍇': 5, '🍊': 3, '🍋': 2, '🍒': 1.5 };

module.exports = {
  category: 'economy',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('slots')
    .setDescription('Spin the slot machine')
    .addIntegerOption(o => o.setName('amount').setDescription('Amount to bet').setMinValue(10).setRequired(true)),

  async execute(interaction, client) {
    const amount = interaction.options.getInteger('amount');
    await interaction.deferReply();
    const eco = new EconomySystem(client);
    const data = await eco.getUser(interaction.user.id, interaction.guild.id);
    if (data.wallet < amount) return interaction.editReply({ embeds: [Embed.error('Insufficient Funds', `You only have **${data.wallet.toLocaleString()}** coins.`)] });

    const spin = () => SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
    const reels = [spin(), spin(), spin()];
    let winnings = 0;
    let resultText = '';

    if (reels[0] === reels[1] && reels[1] === reels[2]) {
      const multiplier = PAYOUTS[reels[0]] || 2;
      winnings = Math.floor(amount * multiplier);
      resultText = `🎰 JACKPOT! Three ${reels[0]}! You win **+${winnings.toLocaleString()} coins**!`;
      await eco.addMoney(interaction.user.id, interaction.guild.id, winnings, 'slots');
    } else if (reels[0] === reels[1] || reels[1] === reels[2]) {
      winnings = Math.floor(amount * 0.5);
      resultText = `Two of a kind! You win back **+${winnings.toLocaleString()} coins**.`;
      await eco.addMoney(interaction.user.id, interaction.guild.id, winnings - amount, 'slots');
    } else {
      resultText = `No match. You lost **-${amount.toLocaleString()} coins**.`;
      await eco.removeMoney(interaction.user.id, interaction.guild.id, amount, 'slots');
    }

    const newData = await eco.getUser(interaction.user.id, interaction.guild.id);
    await interaction.editReply({
      embeds: [Embed.economy('🎰 Slot Machine')
        .setDescription(`\`\`\`\n[ ${reels.join(' | ')} ]\n\`\`\`\n${resultText}`)
        .addFields({ name: '💰 Balance', value: `${newData.wallet.toLocaleString()} coins`, inline: true })
        .setColor(winnings > 0 ? 0x2ECC71 : 0xE74C3C)],
    });
  },
};
