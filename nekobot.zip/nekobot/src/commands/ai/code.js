'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { AISystem } = require('../../systems/AISystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'ai',
  cooldown: 15,
  data: new SlashCommandBuilder()
    .setName('code')
    .setDescription('Generate or debug code with AI')
    .addStringOption(o => o.setName('prompt').setDescription('What code to generate or debug').setRequired(true))
    .addStringOption(o => o.setName('language').setDescription('Programming language').setRequired(false)
      .addChoices(
        { name: 'JavaScript', value: 'javascript' }, { name: 'Python', value: 'python' },
        { name: 'TypeScript', value: 'typescript' }, { name: 'Java', value: 'java' },
        { name: 'C++', value: 'cpp' }, { name: 'Rust', value: 'rust' },
        { name: 'Go', value: 'go' }, { name: 'SQL', value: 'sql' },
      )),

  async execute(interaction, client) {
    const prompt = interaction.options.getString('prompt');
    const lang = interaction.options.getString('language') || 'javascript';
    await interaction.deferReply();
    try {
      const ai = new AISystem(client);
      const response = await ai.code(interaction.user, prompt, lang);
      const truncated = response.length > 3900 ? response.slice(0, 3900) + '\n...(truncated)' : response;
      await interaction.editReply({
        embeds: [Embed.ai(`💻 Code Generation — ${lang}`)
          .setDescription(`\`\`\`${lang}\n${truncated}\n\`\`\``)
          .setFooter({ text: `Powered by GPT-4o` })
        ],
      });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Code Failed', e.message)] });
    }
  },
};
