'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { AISystem } = require('../../systems/AISystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'ai',
  cooldown: 10,
  data: new SlashCommandBuilder()
    .setName('ai')
    .setDescription('Chat with the AI assistant')
    .addStringOption(o => o.setName('prompt').setDescription('Your message to the AI').setRequired(true))
    .addStringOption(o => o.setName('model').setDescription('AI model to use').setRequired(false)
      .addChoices(
        { name: 'GPT-4o (Default)', value: 'gpt-4o' },
        { name: 'GPT-4o Mini (Fast)', value: 'gpt-4o-mini' },
      )),

  async execute(interaction, client) {
    const prompt = interaction.options.getString('prompt');
    const model = interaction.options.getString('model') || 'gpt-4o';
    await interaction.deferReply();
    try {
      const ai = new AISystem(client);
      const response = await ai.chat(interaction.user, prompt, model);
      const embed = Embed.ai('🤖 AI Response')
        .setDescription(response.length > 4000 ? response.slice(0, 4000) + '...' : response)
        .setFooter({ text: `Model: ${model} | Tokens used: ${response.tokenCount || '?'}` });
      await interaction.editReply({ embeds: [embed] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('AI Error', e.message)] });
    }
  },
};
