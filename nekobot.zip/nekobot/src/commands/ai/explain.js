'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { AISystem } = require('../../systems/AISystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'ai',
  cooldown: 10,
  data: new SlashCommandBuilder()
    .setName('explain')
    .setDescription('Have AI explain a concept or piece of code')
    .addStringOption(o => o.setName('topic').setDescription('Concept or code to explain').setRequired(true))
    .addStringOption(o => o.setName('level').setDescription('Explanation level').setRequired(false)
      .addChoices({ name: 'Beginner', value: 'beginner' }, { name: 'Intermediate', value: 'intermediate' }, { name: 'Expert', value: 'expert' })),

  async execute(interaction, client) {
    const topic = interaction.options.getString('topic');
    const level = interaction.options.getString('level') || 'intermediate';
    await interaction.deferReply();
    try {
      const ai = new AISystem(client);
      const response = await ai.explain(interaction.user, topic, level);
      const truncated = response.length > 4000 ? response.slice(0, 4000) + '...' : response;
      await interaction.editReply({ embeds: [Embed.ai(`📖 Explanation — ${level} level`).setDescription(truncated)] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Explain Failed', e.message)] });
    }
  },
};
