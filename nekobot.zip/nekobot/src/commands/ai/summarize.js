'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { AISystem } = require('../../systems/AISystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'ai',
  cooldown: 10,
  data: new SlashCommandBuilder()
    .setName('summarize')
    .setDescription('Summarize a long text using AI')
    .addStringOption(o => o.setName('text').setDescription('Text to summarize').setRequired(true))
    .addStringOption(o => o.setName('format').setDescription('Output format').setRequired(false)
      .addChoices({ name: 'Paragraph', value: 'paragraph' }, { name: 'Bullet Points', value: 'bullets' }, { name: 'One Sentence', value: 'oneliner' })),

  async execute(interaction, client) {
    const text = interaction.options.getString('text');
    const format = interaction.options.getString('format') || 'paragraph';
    await interaction.deferReply();
    try {
      const ai = new AISystem(client);
      const summary = await ai.summarize(interaction.user, text, format);
      await interaction.editReply({ embeds: [Embed.ai('📝 Summary').setDescription(summary.length > 4000 ? summary.slice(0, 4000) + '...' : summary).setFooter({ text: `Format: ${format}` })] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Summarize Failed', e.message)] });
    }
  },
};
