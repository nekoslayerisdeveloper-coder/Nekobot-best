'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { PremiumSystem } = require('../../systems/PremiumSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'premium',
  cooldown: 10,
  data: new SlashCommandBuilder()
    .setName('redeem')
    .setDescription('Redeem a premium key')
    .addStringOption(o => o.setName('key').setDescription('Your premium key').setRequired(true)),

  async execute(interaction, client) {
    const key = interaction.options.getString('key').trim();
    await interaction.deferReply({ ephemeral: true });
    const ps = new PremiumSystem(client);
    try {
      const result = await ps.redeemKey(interaction.user.id, key);
      await interaction.editReply({
        embeds: [Embed.success('💎 Premium Activated!', `Your **${result.tier}** premium has been activated!\n\n${result.duration === 0 ? '🌟 Duration: **Lifetime**' : `⏰ Expires: <t:${Math.floor((Date.now() + result.duration * 86400000) / 1000)}:R>`}\n\nUse \`/premium\` to view your benefits.`)
          .setColor(0xF1C40F)
        ],
      });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Redeem Failed', e.message)] });
    }
  },
};
