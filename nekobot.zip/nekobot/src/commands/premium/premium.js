'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { PremiumSystem } = require('../../systems/PremiumSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'premium',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('premium')
    .setDescription('View your premium status and benefits'),

  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });
    const ps = new PremiumSystem(client);
    const info = await ps.getUserPremium(interaction.user.id);

    if (!info || !info.active) {
      return interaction.editReply({
        embeds: [Embed.info('💎 NekoBot Premium')
          .setDescription('You do not have premium. Use `/redeem <key>` to activate a key.\n\nPremium benefits:')
          .addFields(
            { name: '✨ Basic', value: '• 2x XP multiplier\n• Priority tickets\n• Custom color\n• +500 daily bonus', inline: true },
            { name: '🚀 Pro', value: '• All Basic perks\n• AI premium models\n• Economy perks\n• Custom commands', inline: true },
            { name: '💎 Enterprise', value: '• All Pro perks\n• Unlimited features\n• White-label\n• Dedicated support', inline: true },
          )
        ],
      });
    }

    const expiry = info.expiresAt === 0 ? 'Never (Lifetime)' : `<t:${Math.floor(info.expiresAt / 1000)}:F>`;
    await interaction.editReply({
      embeds: [Embed.info('💎 Your Premium Status')
        .addFields(
          { name: '🏅 Tier', value: info.tier.charAt(0).toUpperCase() + info.tier.slice(1), inline: true },
          { name: '⏰ Expires', value: expiry, inline: true },
          { name: '📅 Activated', value: `<t:${Math.floor(info.activatedAt / 1000)}:R>`, inline: true },
        )
        .setColor(0xF1C40F)
      ],
    });
  },
};
