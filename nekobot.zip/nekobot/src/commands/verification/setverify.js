'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'verification',
  permissions: ['Administrator'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('setverify')
    .setDescription('Configure the verification system')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(s => s.setName('role').setDescription('Set the verified role').addRoleOption(o => o.setName('role').setDescription('Role to assign on verify').setRequired(true)))
    .addSubcommand(s => s.setName('channel').setDescription('Set verification channel').addChannelOption(o => o.setName('channel').setDescription('Channel').setRequired(true)))
    .addSubcommand(s => s.setName('type').setDescription('Set verification type').addStringOption(o => o.setName('type').setDescription('Type').setRequired(true).addChoices({ name: 'Button', value: 'button' }, { name: 'Captcha', value: 'captcha' }, { name: 'Reaction', value: 'reaction' })))
    .addSubcommand(s => s.setName('toggle').setDescription('Enable/disable verification').addBooleanOption(o => o.setName('enabled').setDescription('Enable?').setRequired(true))),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply({ ephemeral: true });
    const guildData = client.db.guild.get(interaction.guild.id) || {};
    const verCfg = guildData.verifyConfig || {};

    switch (sub) {
      case 'role': verCfg.roleId = interaction.options.getRole('role').id; break;
      case 'channel': verCfg.channelId = interaction.options.getChannel('channel').id; break;
      case 'type': verCfg.type = interaction.options.getString('type'); break;
      case 'toggle': verCfg.enabled = interaction.options.getBoolean('enabled'); break;
    }

    guildData.verifyConfig = verCfg;
    client.db.guild.set(interaction.guild.id, guildData);
    await interaction.editReply({ embeds: [Embed.success('Verification Config Updated', `Updated \`${sub}\` setting.`)] });
  },
};
