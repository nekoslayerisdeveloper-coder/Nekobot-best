'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { VerificationSystem } = require('../../systems/VerificationSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'verification',
  cooldown: 10,
  data: new SlashCommandBuilder()
    .setName('verify')
    .setDescription('Verify yourself to gain access'),

  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });
    try {
      const vs = new VerificationSystem(client);
      await vs.verifyUser(interaction.member, interaction.guild);
      await interaction.editReply({ embeds: [Embed.success('Verified!', 'You have been successfully verified and can now access the server.')] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Verification Failed', e.message)] });
    }
  },
};
