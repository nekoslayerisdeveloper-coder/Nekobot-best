'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { AutoResponseSystem } = require('../../systems/AutoResponseSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'admin',
  permissions: ['ManageGuild'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('autorespond')
    .setDescription('Configure automatic responses to messages')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(s => s.setName('add').setDescription('Add an auto-response')
      .addStringOption(o => o.setName('trigger').setDescription('Trigger word/phrase').setRequired(true))
      .addStringOption(o => o.setName('response').setDescription('Response message').setRequired(true))
      .addBooleanOption(o => o.setName('exact').setDescription('Exact match only?').setRequired(false)))
    .addSubcommand(s => s.setName('remove').setDescription('Remove an auto-response').addStringOption(o => o.setName('trigger').setDescription('Trigger to remove').setRequired(true)))
    .addSubcommand(s => s.setName('list').setDescription('List all auto-responses'))
    .addSubcommand(s => s.setName('toggle').setDescription('Enable/disable auto-responses').addBooleanOption(o => o.setName('enabled').setDescription('Enable?').setRequired(true))),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply({ ephemeral: true });
    const ars = new AutoResponseSystem(client);

    switch (sub) {
      case 'add': {
        const trigger = interaction.options.getString('trigger');
        const response = interaction.options.getString('response');
        const exact = interaction.options.getBoolean('exact') ?? false;
        await ars.add(interaction.guild.id, trigger, response, exact);
        await interaction.editReply({ embeds: [Embed.success('Auto-Response Added', `Trigger: \`${trigger}\`\nResponse: \`${response}\``)] });
        break;
      }
      case 'remove': {
        const trigger = interaction.options.getString('trigger');
        await ars.remove(interaction.guild.id, trigger);
        await interaction.editReply({ embeds: [Embed.success('Auto-Response Removed', `Removed trigger: \`${trigger}\``)] });
        break;
      }
      case 'list': {
        const list = await ars.list(interaction.guild.id);
        if (!list.length) return interaction.editReply({ embeds: [Embed.info('Auto-Responses', 'No auto-responses configured.')] });
        const desc = list.map(r => `\`${r.trigger}\` → ${r.response.slice(0, 50)}`).join('\n');
        await interaction.editReply({ embeds: [Embed.info(`Auto-Responses (${list.length})`).setDescription(desc)] });
        break;
      }
      case 'toggle': {
        const gd = client.db.guild.get(interaction.guild.id) || {};
        gd.autoResponseEnabled = interaction.options.getBoolean('enabled');
        client.db.guild.set(interaction.guild.id, gd);
        await interaction.editReply({ embeds: [Embed.success('Updated', `Auto-responses ${gd.autoResponseEnabled ? 'enabled' : 'disabled'}.`)] });
        break;
      }
    }
  },
};
