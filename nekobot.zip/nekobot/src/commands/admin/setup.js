'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'admin',
  permissions: ['Administrator'],
  cooldown: 10,
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('Interactive setup wizard for NekoBot')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(s => s.setName('run').setDescription('Run the full setup wizard'))
    .addSubcommand(s => s.setName('status').setDescription('View current configuration status')),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply();

    if (sub === 'status') {
      const gd = client.db.guild.get(interaction.guild.id) || {};
      const checks = [
        ['Welcome Channel', gd.welcomeConfig?.channelId ? '✅' : '❌'],
        ['Log Channel', gd.logConfig?.channelId ? '✅' : '❌'],
        ['Mod Role', gd.modRole ? '✅' : '❌'],
        ['Mute Role', gd.muteRole ? '✅' : '❌'],
        ['Ticket System', gd.ticketConfig?.enabled ? '✅' : '❌'],
        ['Leveling', gd.levelConfig?.enabled !== false ? '✅' : '❌'],
        ['AutoMod', gd.autoMod?.enabled ? '✅' : '❌'],
        ['Verification', gd.verifyConfig?.enabled ? '✅' : '❌'],
        ['Suggestion Channel', gd.suggestionChannelId ? '✅' : '❌'],
      ];
      const desc = checks.map(([name, status]) => `${status} **${name}**`).join('\n');
      return interaction.editReply({ embeds: [Embed.info('⚙️ Setup Status').setDescription(desc)] });
    }

    const gd = client.db.guild.get(interaction.guild.id) || {};

    await interaction.editReply({
      embeds: [Embed.info('🛠️ NekoBot Setup Wizard')
        .setDescription('Welcome! Use the commands below to configure NekoBot:\n\n' +
          '`/setlog channel:#channel` — Set logging channel\n' +
          '`/setwelcome channel:#channel` — Set welcome channel\n' +
          '`/autorole role:@role` — Set auto-role on join\n' +
          '`/automod toggle:true` — Enable auto-moderation\n' +
          '`/ticket setup` — Set up ticket system\n' +
          '`/setverify role:@role` — Set verification role\n' +
          '`/levelconfig toggle:true` — Enable leveling\n\n' +
          'Run `/setup status` to see your current configuration.'
        )
      ],
    });
  },
};
