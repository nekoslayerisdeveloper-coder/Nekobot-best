'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { CustomCommandSystem } = require('../../systems/CustomCommandSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'admin',
  permissions: ['ManageGuild'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('customcmd')
    .setDescription('Manage custom commands')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(s => s.setName('add').setDescription('Add a custom command')
      .addStringOption(o => o.setName('name').setDescription('Command name (no spaces)').setRequired(true))
      .addStringOption(o => o.setName('response').setDescription('Response message').setRequired(true))
      .addBooleanOption(o => o.setName('ephemeral').setDescription('Only visible to user?').setRequired(false)))
    .addSubcommand(s => s.setName('remove').setDescription('Remove a custom command').addStringOption(o => o.setName('name').setDescription('Command name').setRequired(true)))
    .addSubcommand(s => s.setName('list').setDescription('List all custom commands'))
    .addSubcommand(s => s.setName('edit').setDescription('Edit a custom command')
      .addStringOption(o => o.setName('name').setDescription('Command name').setRequired(true))
      .addStringOption(o => o.setName('response').setDescription('New response').setRequired(true))),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply({ ephemeral: true });
    const ccs = new CustomCommandSystem(client);

    switch (sub) {
      case 'add': {
        const name = interaction.options.getString('name').toLowerCase().replace(/\s+/g, '-');
        const response = interaction.options.getString('response');
        const ephemeral = interaction.options.getBoolean('ephemeral') ?? false;
        await ccs.add(interaction.guild.id, name, response, ephemeral);
        await interaction.editReply({ embeds: [Embed.success('Custom Command Added', `Command \`${name}\` will respond with the configured message.`)] });
        break;
      }
      case 'remove': {
        const name = interaction.options.getString('name').toLowerCase();
        await ccs.remove(interaction.guild.id, name);
        await interaction.editReply({ embeds: [Embed.success('Custom Command Removed', `Command \`${name}\` deleted.`)] });
        break;
      }
      case 'list': {
        const list = await ccs.list(interaction.guild.id);
        if (!list.length) return interaction.editReply({ embeds: [Embed.info('Custom Commands', 'No custom commands configured.')] });
        const desc = list.map(c => `\`${c.name}\` — ${c.response.slice(0, 60)}`).join('\n');
        await interaction.editReply({ embeds: [Embed.info(`Custom Commands (${list.length})`).setDescription(desc)] });
        break;
      }
      case 'edit': {
        const name = interaction.options.getString('name').toLowerCase();
        const response = interaction.options.getString('response');
        await ccs.edit(interaction.guild.id, name, response);
        await interaction.editReply({ embeds: [Embed.success('Command Updated', `Command \`${name}\` updated.`)] });
        break;
      }
    }
  },
};
