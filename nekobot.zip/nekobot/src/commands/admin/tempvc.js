'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { TempVCSystem } = require('../../systems/TempVCSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'admin',
  permissions: ['ManageChannels'],
  cooldown: 10,
  data: new SlashCommandBuilder()
    .setName('tempvc')
    .setDescription('Configure the Temp Voice Channel system')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addSubcommand(s => s.setName('setup').setDescription('Set the trigger voice channel').addChannelOption(o => o.setName('channel').setDescription('Voice channel users join to create a temp VC').addChannelTypes(ChannelType.GuildVoice).setRequired(true)))
    .addSubcommand(s => s.setName('disable').setDescription('Disable temp VCs'))
    .addSubcommand(s => s.setName('status').setDescription('Show temp VC status')),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const tvc = new TempVCSystem(client);
    const guildId = interaction.guild.id;

    switch (sub) {
      case 'setup': {
        const channel = interaction.options.getChannel('channel');
        tvc.setTrigger(guildId, channel.id);
        await interaction.reply({ embeds: [Embed.success('Temp VC Setup', `Users who join ${channel} will get their own temporary voice channel.`)] });
        break;
      }
      case 'disable': {
        tvc.setTrigger(guildId, null);
        await interaction.reply({ embeds: [Embed.success('Temp VC Disabled', 'Temporary voice channels have been disabled.')] });
        break;
      }
      case 'status': {
        const guildData = client.db.guild.get(guildId) || {};
        const trigger = guildData.tempVCTrigger;
        const active = Object.keys(guildData.tempVCs || {}).length;
        await interaction.reply({ embeds: [Embed.info('Temp VC Status').addFields({ name: 'Trigger Channel', value: trigger ? `<#${trigger}>` : 'Not set', inline: true }, { name: 'Active Temp VCs', value: `${active}`, inline: true })] });
        break;
      }
    }
  },
};
