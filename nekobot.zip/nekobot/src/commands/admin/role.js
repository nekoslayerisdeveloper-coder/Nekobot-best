'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'admin',
  permissions: ['ManageRoles'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('role')
    .setDescription('Add or remove a role from a user')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand(s => s.setName('add').setDescription('Add a role to a user').addUserOption(o => o.setName('user').setDescription('User').setRequired(true)).addRoleOption(o => o.setName('role').setDescription('Role to add').setRequired(true)).addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false)))
    .addSubcommand(s => s.setName('remove').setDescription('Remove a role from a user').addUserOption(o => o.setName('user').setDescription('User').setRequired(true)).addRoleOption(o => o.setName('role').setDescription('Role to remove').setRequired(true)).addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false))),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const target = interaction.options.getMember('user');
    const role = interaction.options.getRole('role');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    if (!target) return interaction.reply({ embeds: [Embed.error('Not Found', 'Member not found.')], ephemeral: true });
    if (role.managed) return interaction.reply({ embeds: [Embed.error('Managed Role', 'Cannot manage bot/integration roles.')], ephemeral: true });
    if (role.position >= interaction.guild.members.me.roles.highest.position) return interaction.reply({ embeds: [Embed.error('Role Too High', 'That role is above my highest role.')], ephemeral: true });

    if (sub === 'add') {
      if (target.roles.cache.has(role.id)) return interaction.reply({ embeds: [Embed.warning('Already Has Role', `${target.user.username} already has ${role.name}.`)], ephemeral: true });
      await target.roles.add(role, reason);
      await interaction.reply({ embeds: [Embed.success('Role Added', `Added ${role} to ${target.user.username}.\n**Reason:** ${reason}`)] });
    } else {
      if (!target.roles.cache.has(role.id)) return interaction.reply({ embeds: [Embed.warning("Doesn't Have Role", `${target.user.username} doesn't have ${role.name}.`)], ephemeral: true });
      await target.roles.remove(role, reason);
      await interaction.reply({ embeds: [Embed.success('Role Removed', `Removed ${role} from ${target.user.username}.\n**Reason:** ${reason}`)] });
    }
  },
};
