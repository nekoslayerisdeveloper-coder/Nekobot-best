'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'admin',
  permissions: ['Administrator'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('automod')
    .setDescription('Configure AutoMod settings')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(s => s.setName('toggle').setDescription('Enable/disable AutoMod').addBooleanOption(o => o.setName('enabled').setDescription('Enable?').setRequired(true)))
    .addSubcommand(s => s.setName('antispam').setDescription('Configure anti-spam').addBooleanOption(o => o.setName('enabled').setDescription('Enable?').setRequired(true)).addIntegerOption(o => o.setName('threshold').setDescription('Messages per 5s before action').setMinValue(3).setMaxValue(20).setRequired(false)))
    .addSubcommand(s => s.setName('antilink').setDescription('Block links').addBooleanOption(o => o.setName('enabled').setDescription('Enable?').setRequired(true)))
    .addSubcommand(s => s.setName('antiraid').setDescription('Configure anti-raid').addBooleanOption(o => o.setName('enabled').setDescription('Enable?').setRequired(true)).addIntegerOption(o => o.setName('join_threshold').setDescription('Joins per minute to trigger lockdown').setMinValue(5).setMaxValue(100).setRequired(false)))
    .addSubcommand(s => s.setName('badwords').setDescription('Add a bad word').addStringOption(o => o.setName('word').setDescription('Word to block').setRequired(true)))
    .addSubcommand(s => s.setName('view').setDescription('View automod config')),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply({ ephemeral: true });
    const gd = client.db.guild.get(interaction.guild.id) || {};
    const am = gd.autoMod || {};

    switch (sub) {
      case 'toggle': am.enabled = interaction.options.getBoolean('enabled'); break;
      case 'antispam':
        am.antispam = { enabled: interaction.options.getBoolean('enabled'), threshold: interaction.options.getInteger('threshold') || am.antispam?.threshold || 8 };
        break;
      case 'antilink': am.antilink = { enabled: interaction.options.getBoolean('enabled') }; break;
      case 'antiraid':
        am.antiraid = { enabled: interaction.options.getBoolean('enabled'), joinThreshold: interaction.options.getInteger('join_threshold') || am.antiraid?.joinThreshold || 10 };
        break;
      case 'badwords':
        am.badWords = am.badWords || [];
        am.badWords.push(interaction.options.getString('word').toLowerCase());
        break;
      case 'view':
        return interaction.editReply({
          embeds: [Embed.info('🛡️ AutoMod Config')
            .addFields(
              { name: 'Enabled', value: am.enabled ? '✅' : '❌', inline: true },
              { name: 'Anti-Spam', value: am.antispam?.enabled ? `✅ (${am.antispam.threshold}/5s)` : '❌', inline: true },
              { name: 'Anti-Link', value: am.antilink?.enabled ? '✅' : '❌', inline: true },
              { name: 'Anti-Raid', value: am.antiraid?.enabled ? `✅ (${am.antiraid.joinThreshold}/min)` : '❌', inline: true },
              { name: 'Bad Words', value: `${(am.badWords || []).length} words`, inline: true },
            )
          ],
        });
    }

    gd.autoMod = am;
    client.db.guild.set(interaction.guild.id, gd);
    await interaction.editReply({ embeds: [Embed.success('AutoMod Updated', `AutoMod \`${sub}\` updated.`)] });
  },
};
