'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'admin',
  permissions: ['Administrator'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('setwelcome')
    .setDescription('Configure the welcome system')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(s => s.setName('channel').setDescription('Set welcome channel').addChannelOption(o => o.setName('channel').setDescription('Welcome channel').setRequired(true)))
    .addSubcommand(s => s.setName('message').setDescription('Set welcome message').addStringOption(o => o.setName('message').setDescription('Use {user}, {server}, {count} placeholders').setRequired(true)))
    .addSubcommand(s => s.setName('toggle').setDescription('Enable/disable welcome').addBooleanOption(o => o.setName('enabled').setDescription('Enable?').setRequired(true)))
    .addSubcommand(s => s.setName('embed').setDescription('Toggle embed welcome message').addBooleanOption(o => o.setName('use_embed').setDescription('Use embed?').setRequired(true)))
    .addSubcommand(s => s.setName('test').setDescription('Test the welcome message')),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply({ ephemeral: true });
    const gd = client.db.guild.get(interaction.guild.id) || {};
    const wc = gd.welcomeConfig || {};

    switch (sub) {
      case 'channel': wc.channelId = interaction.options.getChannel('channel').id; break;
      case 'message': wc.message = interaction.options.getString('message'); break;
      case 'toggle': wc.enabled = interaction.options.getBoolean('enabled'); break;
      case 'embed': wc.useEmbed = interaction.options.getBoolean('use_embed'); break;
      case 'test': {
        const ch = wc.channelId ? interaction.guild.channels.cache.get(wc.channelId) : interaction.channel;
        const msg = (wc.message || 'Welcome, {user}! You are member #{count}!')
          .replace('{user}', interaction.member.toString())
          .replace('{server}', interaction.guild.name)
          .replace('{count}', interaction.guild.memberCount);
        if (ch) await ch.send({ content: wc.useEmbed ? undefined : msg, embeds: wc.useEmbed ? [Embed.success('👋 Welcome!', msg)] : [] });
        return interaction.editReply({ embeds: [Embed.success('Test Sent', 'Test welcome message sent.')] });
      }
    }

    gd.welcomeConfig = wc;
    client.db.guild.set(interaction.guild.id, gd);
    await interaction.editReply({ embeds: [Embed.success('Welcome Config Updated', `Welcome \`${sub}\` updated.`)] });
  },
};
