'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'admin',
  permissions: ['Administrator'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('antinuke')
    .setDescription('Configure the anti-nuke system')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(s => s.setName('enable').setDescription('Enable anti-nuke protection'))
    .addSubcommand(s => s.setName('disable').setDescription('Disable anti-nuke protection'))
    .addSubcommand(s => s.setName('status').setDescription('View anti-nuke status'))
    .addSubcommand(s => s.setName('threshold').setDescription('Set action threshold')
      .addIntegerOption(o => o.setName('actions').setDescription('Max actions per 10 seconds before punishment').setMinValue(1).setMaxValue(20).setRequired(true))),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const guildData = client.db.guild.get(guildId) || {};
    const an = guildData.antinuke || { enabled: false, threshold: 5 };

    switch (sub) {
      case 'enable':
        an.enabled = true;
        guildData.antinuke = an;
        client.db.guild.set(guildId, guildData);
        await interaction.reply({ embeds: [Embed.success('Anti-Nuke Enabled', '🛡️ Anti-nuke protection is now active. Suspicious mass actions will be blocked and the actor will be banned.')] });
        break;
      case 'disable':
        an.enabled = false;
        guildData.antinuke = an;
        client.db.guild.set(guildId, guildData);
        await interaction.reply({ embeds: [Embed.warning('Anti-Nuke Disabled', 'Anti-nuke protection has been disabled.')] });
        break;
      case 'status':
        await interaction.reply({
          embeds: [Embed.info('Anti-Nuke Status')
            .addFields({ name: 'Status', value: an.enabled ? '✅ Enabled' : '❌ Disabled', inline: true }, { name: 'Threshold', value: `${an.threshold} actions / 10s`, inline: true })
          ],
        });
        break;
      case 'threshold':
        an.threshold = interaction.options.getInteger('actions');
        guildData.antinuke = an;
        client.db.guild.set(guildId, guildData);
        await interaction.reply({ embeds: [Embed.success('Threshold Updated', `Anti-nuke threshold set to **${an.threshold}** actions per 10 seconds.`)] });
        break;
    }
  },
};
