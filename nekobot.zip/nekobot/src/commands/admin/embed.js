'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'admin',
  permissions: ['ManageMessages'],
  cooldown: 10,
  data: new SlashCommandBuilder()
    .setName('embed')
    .setDescription('Send a custom embed to a channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addStringOption(o => o.setName('title').setDescription('Embed title').setRequired(true))
    .addStringOption(o => o.setName('description').setDescription('Embed description').setRequired(true))
    .addChannelOption(o => o.setName('channel').setDescription('Channel to send to').setRequired(false))
    .addStringOption(o => o.setName('color').setDescription('Hex color (e.g. #7C3AED)').setRequired(false))
    .addStringOption(o => o.setName('footer').setDescription('Footer text').setRequired(false))
    .addStringOption(o => o.setName('image').setDescription('Image URL').setRequired(false)),

  async execute(interaction) {
    const title = interaction.options.getString('title');
    const description = interaction.options.getString('description');
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    const colorStr = interaction.options.getString('color') || '#7C3AED';
    const footer = interaction.options.getString('footer');
    const imageUrl = interaction.options.getString('image');
    const color = parseInt(colorStr.replace('#', ''), 16) || 0x7C3AED;
    const em = Embed.custom(color, title, description);
    if (footer) em.setFooter({ text: footer });
    if (imageUrl) em.setImage(imageUrl);
    await channel.send({ embeds: [em] });
    await interaction.reply({ content: `✅ Embed sent to ${channel}.`, ephemeral: true });
  },
};
