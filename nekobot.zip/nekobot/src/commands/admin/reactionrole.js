'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { ReactionRoleSystem } = require('../../systems/ReactionRoleSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'admin',
  permissions: ['ManageRoles'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('reactionrole')
    .setDescription('Configure reaction roles')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand(s => s.setName('add').setDescription('Add a reaction role')
      .addStringOption(o => o.setName('message_id').setDescription('Message ID').setRequired(true))
      .addStringOption(o => o.setName('emoji').setDescription('Emoji to react with').setRequired(true))
      .addRoleOption(o => o.setName('role').setDescription('Role to give').setRequired(true)))
    .addSubcommand(s => s.setName('remove').setDescription('Remove a reaction role')
      .addStringOption(o => o.setName('message_id').setDescription('Message ID').setRequired(true))
      .addStringOption(o => o.setName('emoji').setDescription('Emoji to remove').setRequired(true)))
    .addSubcommand(s => s.setName('list').setDescription('List all reaction roles'))
    .addSubcommand(s => s.setName('create').setDescription('Create a reaction role embed')
      .addStringOption(o => o.setName('title').setDescription('Embed title').setRequired(true))
      .addStringOption(o => o.setName('description').setDescription('Embed description').setRequired(true))),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply({ ephemeral: true });
    const rrs = new ReactionRoleSystem(client);

    switch (sub) {
      case 'add': {
        const msgId = interaction.options.getString('message_id');
        const emoji = interaction.options.getString('emoji');
        const role = interaction.options.getRole('role');
        await rrs.add(interaction.channel, msgId, emoji, role.id);
        await interaction.editReply({ embeds: [Embed.success('Reaction Role Added', `Emoji ${emoji} → ${role} on message \`${msgId}\`.`)] });
        break;
      }
      case 'remove': {
        const msgId = interaction.options.getString('message_id');
        const emoji = interaction.options.getString('emoji');
        await rrs.remove(interaction.guild.id, msgId, emoji);
        await interaction.editReply({ embeds: [Embed.success('Reaction Role Removed')] });
        break;
      }
      case 'list': {
        const list = await rrs.list(interaction.guild.id);
        if (!list.length) return interaction.editReply({ embeds: [Embed.info('Reaction Roles', 'No reaction roles configured.')] });
        const desc = list.map(r => `**${r.emoji}** → <@&${r.roleId}> on \`${r.messageId}\``).join('\n');
        await interaction.editReply({ embeds: [Embed.info('Reaction Roles').setDescription(desc)] });
        break;
      }
      case 'create': {
        const title = interaction.options.getString('title');
        const description = interaction.options.getString('description');
        const msg = await interaction.channel.send({ embeds: [Embed.info(title).setDescription(description)] });
        await interaction.editReply({ embeds: [Embed.success('Panel Created', `Use \`/reactionrole add ${msg.id}\` to add reactions.`)] });
        break;
      }
    }
  },
};
