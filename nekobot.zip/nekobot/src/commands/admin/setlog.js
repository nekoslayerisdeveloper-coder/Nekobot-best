'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'admin',
  permissions: ['Administrator'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('setlog')
    .setDescription('Configure logging channels')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(s => s.setName('channel').setDescription('Set the main log channel').addChannelOption(o => o.setName('channel').setDescription('Log channel').setRequired(true)))
    .addSubcommand(s => s.setName('modlog').setDescription('Set moderation log channel').addChannelOption(o => o.setName('channel').setDescription('Mod log channel').setRequired(true)))
    .addSubcommand(s => s.setName('joinlog').setDescription('Set join/leave log channel').addChannelOption(o => o.setName('channel').setDescription('Join log channel').setRequired(true)))
    .addSubcommand(s => s.setName('messagelog').setDescription('Set message log channel').addChannelOption(o => o.setName('channel').setDescription('Message log channel').setRequired(true)))
    .addSubcommand(s => s.setName('toggle').setDescription('Enable/disable all logging').addBooleanOption(o => o.setName('enabled').setDescription('Enable logging?').setRequired(true))),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply({ ephemeral: true });
    const gd = client.db.guild.get(interaction.guild.id) || {};
    const logConfig = gd.logConfig || {};

    switch (sub) {
      case 'channel': logConfig.channelId = interaction.options.getChannel('channel').id; break;
      case 'modlog': logConfig.modLogId = interaction.options.getChannel('channel').id; break;
      case 'joinlog': logConfig.joinLogId = interaction.options.getChannel('channel').id; break;
      case 'messagelog': logConfig.messageLogId = interaction.options.getChannel('channel').id; break;
      case 'toggle': logConfig.enabled = interaction.options.getBoolean('enabled'); break;
    }

    gd.logConfig = logConfig;
    client.db.guild.set(interaction.guild.id, gd);
    await interaction.editReply({ embeds: [Embed.success('Logging Updated', `Logging \`${sub}\` configured successfully.`)] });
  },
};
