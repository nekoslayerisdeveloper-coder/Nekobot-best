'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { ServerStatsSystem } = require('../../systems/ServerStatsSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'admin',
  permissions: ['ManageGuild'],
  cooldown: 10,
  data: new SlashCommandBuilder()
    .setName('statschannel')
    .setDescription('Configure automatic stat channels')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(s => s.setName('setup').setDescription('Auto-create all stat channels in a category'))
    .addSubcommand(s => s.setName('add').setDescription('Add a custom stat channel')
      .addStringOption(o => o.setName('type').setDescription('Stat type').setRequired(true).addChoices(
        { name: 'Total Members', value: 'members' }, { name: 'Online Members', value: 'online' },
        { name: 'Bots', value: 'bots' }, { name: 'Channels', value: 'channels' },
        { name: 'Roles', value: 'roles' }, { name: 'Boosts', value: 'boosts' },
      ))
      .addStringOption(o => o.setName('format').setDescription('Name format, use {value} as placeholder').setRequired(true)))
    .addSubcommand(s => s.setName('remove').setDescription('Remove stat tracking for a channel').addChannelOption(o => o.setName('channel').setDescription('Channel').setRequired(true)))
    .addSubcommand(s => s.setName('list').setDescription('List all stat channels')),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply({ ephemeral: true });
    const ss = new ServerStatsSystem(client);

    switch (sub) {
      case 'setup': {
        const channels = await ss.setupAll(interaction.guild);
        await interaction.editReply({ embeds: [Embed.success('Stat Channels Created', `Created ${channels.length} stat channels.`)] });
        break;
      }
      case 'add': {
        const type = interaction.options.getString('type');
        const format = interaction.options.getString('format');
        await ss.addStatChannel(interaction.guild, type, format);
        await interaction.editReply({ embeds: [Embed.success('Stat Channel Added', `Created stat channel for **${type}**.`)] });
        break;
      }
      case 'remove': {
        const ch = interaction.options.getChannel('channel');
        await ss.removeStatChannel(interaction.guild.id, ch.id);
        await interaction.editReply({ embeds: [Embed.success('Removed', `Stat tracking removed for ${ch}.`)] });
        break;
      }
      case 'list': {
        const list = await ss.listStatChannels(interaction.guild.id);
        if (!list.length) return interaction.editReply({ embeds: [Embed.info('Stat Channels', 'No stat channels configured.')] });
        const desc = list.map(s => `**${s.type}** → <#${s.channelId}> — \`${s.format}\``).join('\n');
        await interaction.editReply({ embeds: [Embed.info('📊 Stat Channels').setDescription(desc)] });
        break;
      }
    }
  },
};
