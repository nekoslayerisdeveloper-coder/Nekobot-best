'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'admin',
  permissions: ['Administrator'],
  cooldown: 60,
  data: new SlashCommandBuilder()
    .setName('massrole')
    .setDescription('Add or remove a role from all members')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(s => s.setName('add').setDescription('Add role to all members').addRoleOption(o => o.setName('role').setDescription('Role to add').setRequired(true)))
    .addSubcommand(s => s.setName('remove').setDescription('Remove role from all members').addRoleOption(o => o.setName('role').setDescription('Role to remove').setRequired(true))),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const role = interaction.options.getRole('role');
    if (role.managed) return interaction.reply({ embeds: [Embed.error('Managed Role', 'Cannot mass-manage bot/integration roles.')], ephemeral: true });
    if (role.position >= interaction.guild.members.me.roles.highest.position) return interaction.reply({ embeds: [Embed.error('Role Too High', 'That role is above my highest role.')], ephemeral: true });

    await interaction.deferReply();
    await interaction.guild.members.fetch();
    const members = [...interaction.guild.members.cache.values()].filter(m => !m.user.bot);
    let count = 0, failed = 0;

    await interaction.editReply({ embeds: [Embed.info('Mass Role', `Processing ${members.length} members... This may take a while.`)] });

    for (const member of members) {
      try {
        if (sub === 'add') { if (!member.roles.cache.has(role.id)) { await member.roles.add(role); count++; } }
        else { if (member.roles.cache.has(role.id)) { await member.roles.remove(role); count++; } }
        await new Promise(r => setTimeout(r, 300)); // Rate limit protection
      } catch { failed++; }
    }

    await interaction.editReply({ embeds: [Embed.success('Mass Role Complete', `**${sub === 'add' ? 'Added' : 'Removed'}** ${role} ${sub === 'add' ? 'to' : 'from'} **${count}** members.\n${failed > 0 ? `❌ Failed for ${failed} members.` : ''}`)] });
  },
};
