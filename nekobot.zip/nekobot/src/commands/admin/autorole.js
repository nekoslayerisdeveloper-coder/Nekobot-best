'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'admin',
  permissions: ['ManageGuild'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('autorole')
    .setDescription('Configure auto-role on member join')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(s => s.setName('add').setDescription('Add an auto-role').addRoleOption(o => o.setName('role').setDescription('Role to add on join').setRequired(true)))
    .addSubcommand(s => s.setName('remove').setDescription('Remove an auto-role').addRoleOption(o => o.setName('role').setDescription('Role to remove').setRequired(true)))
    .addSubcommand(s => s.setName('list').setDescription('List all auto-roles'))
    .addSubcommand(s => s.setName('botadd').setDescription('Add an auto-role for bots').addRoleOption(o => o.setName('role').setDescription('Role to add to bots on join').setRequired(true))),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply({ ephemeral: true });
    const gd = client.db.guild.get(interaction.guild.id) || {};
    gd.autoRoles = gd.autoRoles || [];
    gd.botAutoRoles = gd.botAutoRoles || [];

    switch (sub) {
      case 'add': {
        const role = interaction.options.getRole('role');
        if (!gd.autoRoles.includes(role.id)) gd.autoRoles.push(role.id);
        client.db.guild.set(interaction.guild.id, gd);
        await interaction.editReply({ embeds: [Embed.success('Auto-Role Added', `${role} will now be given to all members on join.`)] });
        break;
      }
      case 'remove': {
        const role = interaction.options.getRole('role');
        gd.autoRoles = gd.autoRoles.filter(r => r !== role.id);
        client.db.guild.set(interaction.guild.id, gd);
        await interaction.editReply({ embeds: [Embed.success('Auto-Role Removed', `${role} removed from auto-roles.`)] });
        break;
      }
      case 'list': {
        const roles = gd.autoRoles.map(r => `<@&${r}>`).join(', ') || 'None';
        const botRoles = gd.botAutoRoles.map(r => `<@&${r}>`).join(', ') || 'None';
        await interaction.editReply({ embeds: [Embed.info('Auto-Roles').addFields({ name: 'Member Roles', value: roles }, { name: 'Bot Roles', value: botRoles })] });
        break;
      }
      case 'botadd': {
        const role = interaction.options.getRole('role');
        if (!gd.botAutoRoles.includes(role.id)) gd.botAutoRoles.push(role.id);
        client.db.guild.set(interaction.guild.id, gd);
        await interaction.editReply({ embeds: [Embed.success('Bot Auto-Role Added', `${role} will now be given to bots on join.`)] });
        break;
      }
    }
  },
};
