'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { LevelSystem } = require('../../systems/LevelSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'leveling',
  permissions: ['Administrator'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('setxp')
    .setDescription('Set a user\'s XP')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addUserOption(o => o.setName('user').setDescription('Target user').setRequired(true))
    .addIntegerOption(o => o.setName('xp').setDescription('XP amount').setMinValue(0).setRequired(true)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user');
    const xp = interaction.options.getInteger('xp');
    await interaction.deferReply();
    const ls = new LevelSystem(client);
    const result = await ls.setXp(interaction.guild.id, target.id, xp);
    await interaction.editReply({ embeds: [Embed.success('XP Set', `Set **${target.username}**'s XP to **${xp.toLocaleString()}** (Level **${result.level}**).`)] });
  },
};
