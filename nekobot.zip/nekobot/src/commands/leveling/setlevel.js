'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { LevelSystem } = require('../../systems/LevelSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'leveling',
  permissions: ['Administrator'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('setlevel')
    .setDescription("Set a user's level")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addUserOption(o => o.setName('user').setDescription('Target user').setRequired(true))
    .addIntegerOption(o => o.setName('level').setDescription('Level to set').setMinValue(0).setMaxValue(1000).setRequired(true)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user');
    const level = interaction.options.getInteger('level');
    await interaction.deferReply();
    const ls = new LevelSystem(client);
    // Calculate cumulative XP required to reach this level
    let totalXp = 0;
    for (let i = 0; i < level; i++) totalXp += ls.getXpForLevel(i);
    const result = await ls.setXp(interaction.guild.id, target.id, totalXp);
    await interaction.editReply({ embeds: [Embed.success('Level Set', `Set **${target.username}**'s level to **${result.level}** (${totalXp.toLocaleString()} XP).`)] });
  },
};
