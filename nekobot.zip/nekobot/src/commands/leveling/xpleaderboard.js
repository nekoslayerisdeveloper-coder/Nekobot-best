'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { LevelSystem } = require('../../systems/LevelSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'leveling',
  cooldown: 10,
  data: new SlashCommandBuilder()
    .setName('xpleaderboard')
    .setDescription('View the XP leaderboard for this server'),

  async execute(interaction, client) {
    await interaction.deferReply();
    const ls = new LevelSystem(client);
    const top = await ls.getLeaderboard(interaction.guild.id, 10);
    if (!top.length) return interaction.editReply({ embeds: [Embed.level('XP Leaderboard', 'No XP data yet! Start chatting to earn XP.')] });
    const list = await Promise.all(top.map(async (entry, i) => {
      const userId = entry.userId || (entry.id && entry.id.split(':')[1]);
      let tag = userId || 'Unknown';
      try { const u = await client.users.fetch(userId); tag = u.username; } catch {}
      const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `**${i + 1}.**`;
      return `${medal} **${tag}** — Lv. **${entry.level || 0}** | **${(entry.xp || 0).toLocaleString()}** XP`;
    }));
    await interaction.editReply({ embeds: [Embed.level('⭐ XP Leaderboard').setDescription(list.join('\n'))] });
  },
};
