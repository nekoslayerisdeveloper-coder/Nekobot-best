'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { LevelSystem } = require('../../systems/LevelSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'leveling',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription('View your or another user\'s rank card')
    .addUserOption(o => o.setName('user').setDescription('User to check').setRequired(false)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user') || interaction.user;
    await interaction.deferReply();
    const ls = new LevelSystem(client);

    const key = `${interaction.guild.id}:${target.id}`;
    const data = client.db.user.get(key) || { xp: 0, level: 0, messages: 0, vcTime: 0 };
    const rank = await ls.getRank(interaction.guild.id, target.id);
    const progress = ls.getProgressToNextLevel(data.xp || 0);
    const bar = '█'.repeat(Math.floor(progress.percentage / 10)) + '░'.repeat(10 - Math.floor(progress.percentage / 10));

    await interaction.editReply({
      embeds: [Embed.level(`📊 ${target.username}'s Rank`)
        .setThumbnail(target.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '🏅 Rank', value: rank ? `#${rank}` : 'Unranked', inline: true },
          { name: '📈 Level', value: `${data.level || 0}`, inline: true },
          { name: '⭐ XP', value: `${(data.xp || 0).toLocaleString()} total`, inline: true },
          { name: '📊 Progress', value: `\`[${bar}]\` ${progress.percentage}%\n${progress.currentLevelXp}/${progress.neededXp} XP`, inline: false },
          { name: '📨 Messages', value: `${(data.messages || 0).toLocaleString()}`, inline: true },
          { name: '⏱️ Time in VC', value: `${Math.floor((data.vcTime || 0) / 60)} min`, inline: true },
        )
      ],
    });
  },
};
