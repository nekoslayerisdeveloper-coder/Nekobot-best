'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { LevelSystem } = require('../../systems/LevelSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'leveling',
  permissions: ['Administrator'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('resetxp')
    .setDescription('Reset a user\'s XP and level to 0')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addUserOption(o => o.setName('user').setDescription('Target user').setRequired(true)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user');
    await interaction.deferReply();
    const ls = new LevelSystem(client);
    await ls.setXp(interaction.guild.id, target.id, 0);
    await interaction.editReply({ embeds: [Embed.success('XP Reset', `Reset **${target.username}**'s XP and level to 0.`)] });
  },
};
