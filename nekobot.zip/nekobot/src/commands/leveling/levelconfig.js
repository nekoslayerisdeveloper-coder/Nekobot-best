'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'leveling',
  permissions: ['Administrator'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('levelconfig')
    .setDescription('Configure the leveling system')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(s => s.setName('toggle').setDescription('Enable or disable leveling').addBooleanOption(o => o.setName('enabled').setDescription('Enable?').setRequired(true)))
    .addSubcommand(s => s.setName('channel').setDescription('Set levelup announcement channel').addChannelOption(o => o.setName('channel').setDescription('Channel').setRequired(true)))
    .addSubcommand(s => s.setName('multiplier').setDescription('Set XP multiplier (0.1 - 5.0)').addNumberOption(o => o.setName('value').setDescription('Multiplier').setMinValue(0.1).setMaxValue(5.0).setRequired(true)))
    .addSubcommand(s => s.setName('message').setDescription('Set levelup message').addStringOption(o => o.setName('text').setDescription('Use {user} {level} {xp} placeholders').setRequired(true)))
    .addSubcommand(s => s.setName('nochannel').setDescription('Disable XP in a channel').addChannelOption(o => o.setName('channel').setDescription('Channel to ignore').setRequired(true)))
    .addSubcommand(s => s.setName('view').setDescription('View current configuration')),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply();
    const guildData = client.db.guild.get(interaction.guild.id) || {};
    const lvlCfg = guildData.levelConfig || {};

    switch (sub) {
      case 'toggle': {
        const enabled = interaction.options.getBoolean('enabled');
        lvlCfg.enabled = enabled;
        break;
      }
      case 'channel': {
        const ch = interaction.options.getChannel('channel');
        lvlCfg.channel = ch.id;
        break;
      }
      case 'multiplier': {
        const val = interaction.options.getNumber('value');
        lvlCfg.multiplier = val;
        break;
      }
      case 'message': {
        const text = interaction.options.getString('text');
        lvlCfg.message = text;
        break;
      }
      case 'nochannel': {
        const ch = interaction.options.getChannel('channel');
        lvlCfg.ignoredChannels = lvlCfg.ignoredChannels || [];
        if (!lvlCfg.ignoredChannels.includes(ch.id)) lvlCfg.ignoredChannels.push(ch.id);
        break;
      }
      case 'view': {
        const embed = Embed.info('Level Config')
          .addFields(
            { name: 'Enabled', value: lvlCfg.enabled !== false ? '✅ Yes' : '❌ No', inline: true },
            { name: 'Channel', value: lvlCfg.channel ? `<#${lvlCfg.channel}>` : 'Not set', inline: true },
            { name: 'Multiplier', value: `${lvlCfg.multiplier || 1}x`, inline: true },
            { name: 'Message', value: lvlCfg.message || 'Default', inline: false },
            { name: 'Ignored Channels', value: (lvlCfg.ignoredChannels || []).map(id => `<#${id}>`).join(', ') || 'None', inline: false },
          );
        return interaction.editReply({ embeds: [embed] });
      }
    }

    guildData.levelConfig = lvlCfg;
    client.db.guild.set(interaction.guild.id, guildData);
    await interaction.editReply({ embeds: [Embed.success('Config Updated', `Level config \`${sub}\` updated successfully.`)] });
  },
};
