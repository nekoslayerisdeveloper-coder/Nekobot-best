'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { PremiumSystem } = require('../../systems/PremiumSystem');
const { LicenseSystem } = require('../../systems/LicenseSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'owner',
  ownerOnly: true,
  cooldown: 0,
  data: new SlashCommandBuilder()
    .setName('premiumkey')
    .setDescription('[OWNER] Generate or manage premium keys')
    .addSubcommand(s => s.setName('generate').setDescription('Generate a premium key')
      .addStringOption(o => o.setName('tier').setDescription('Premium tier').setRequired(true).addChoices(
        { name: 'Basic', value: 'basic' }, { name: 'Pro', value: 'pro' }, { name: 'Enterprise', value: 'enterprise' }
      ))
      .addIntegerOption(o => o.setName('duration').setDescription('Duration in days (0 = lifetime)').setMinValue(0).setRequired(true))
      .addIntegerOption(o => o.setName('count').setDescription('Number of keys').setMinValue(1).setMaxValue(100).setRequired(false)))
    .addSubcommand(s => s.setName('revoke').setDescription('Revoke a premium key').addStringOption(o => o.setName('key').setDescription('Key to revoke').setRequired(true)))
    .addSubcommand(s => s.setName('info').setDescription('Get info about a key').addStringOption(o => o.setName('key').setDescription('Key to check').setRequired(true)))
    .addSubcommand(s => s.setName('grant').setDescription('Grant premium directly to a user')
      .addUserOption(o => o.setName('user').setDescription('User to grant premium').setRequired(true))
      .addStringOption(o => o.setName('tier').setDescription('Tier').setRequired(true).addChoices({ name: 'Basic', value: 'basic' }, { name: 'Pro', value: 'pro' }, { name: 'Enterprise', value: 'enterprise' }))
      .addIntegerOption(o => o.setName('days').setDescription('Days (0 = lifetime)').setMinValue(0).setRequired(true))),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply({ ephemeral: true });
    const ps = new PremiumSystem(client);

    switch (sub) {
      case 'generate': {
        const tier = interaction.options.getString('tier');
        const duration = interaction.options.getInteger('duration');
        const count = interaction.options.getInteger('count') || 1;
        const keys = [];
        for (let i = 0; i < count; i++) {
          const key = await ps.generateKey(tier, duration, interaction.user.id);
          keys.push(key);
        }
        const keyList = keys.join('\n');
        await interaction.editReply({ embeds: [Embed.success(`Generated ${count} Key(s)`, `**Tier:** ${tier}\n**Duration:** ${duration === 0 ? 'Lifetime' : duration + ' days'}\n\n\`\`\`\n${keyList}\n\`\`\``)] });
        break;
      }
      case 'revoke': {
        const key = interaction.options.getString('key');
        await ps.revokeKey(key);
        await interaction.editReply({ embeds: [Embed.success('Key Revoked', `Key \`${key}\` revoked.`)] });
        break;
      }
      case 'info': {
        const key = interaction.options.getString('key');
        const info = await ps.getKeyInfo(key);
        if (!info) return interaction.editReply({ embeds: [Embed.error('Not Found', 'Key not found.')] });
        await interaction.editReply({ embeds: [Embed.info('Key Info').addFields({ name: 'Tier', value: info.tier, inline: true }, { name: 'Duration', value: info.duration === 0 ? 'Lifetime' : `${info.duration} days`, inline: true }, { name: 'Status', value: info.used ? `Used by \`${info.usedBy}\`` : 'Available', inline: true })] });
        break;
      }
      case 'grant': {
        const user = interaction.options.getUser('user');
        const tier = interaction.options.getString('tier');
        const days = interaction.options.getInteger('days');
        await ps.grantPremium(user.id, tier, days);
        await interaction.editReply({ embeds: [Embed.success('Premium Granted', `Granted **${tier}** premium to **${user.tag}** for **${days === 0 ? 'Lifetime' : days + ' days'}**.`)] });
        break;
      }
    }
  },
};
