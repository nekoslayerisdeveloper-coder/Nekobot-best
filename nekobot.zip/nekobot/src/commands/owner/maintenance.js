'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'owner',
  ownerOnly: true,
  cooldown: 0,
  data: new SlashCommandBuilder()
    .setName('maintenance')
    .setDescription('[OWNER] Toggle maintenance mode')
    .addBooleanOption(o => o.setName('enabled').setDescription('Enable maintenance mode?').setRequired(true))
    .addStringOption(o => o.setName('message').setDescription('Maintenance message').setRequired(false)),

  async execute(interaction, client) {
    const enabled = interaction.options.getBoolean('enabled');
    const message = interaction.options.getString('message') || 'The bot is currently undergoing maintenance. Please try again later.';
    await interaction.deferReply({ ephemeral: true });
    client.maintenance = enabled;
    client.maintenanceMessage = message;
    client.db.global.set('maintenance', { enabled, message, since: Date.now() });
    if (enabled) {
      await client.user.setPresence({ activities: [{ name: '🔧 Maintenance Mode', type: 4 }], status: 'dnd' });
    } else {
      await client.user.setPresence({ activities: [{ name: '/help | NekoBot', type: 3 }], status: 'online' });
    }
    await interaction.editReply({ embeds: [Embed.success('Maintenance Mode', `Maintenance mode **${enabled ? 'enabled' : 'disabled'}**.${enabled ? `\n**Message:** ${message}` : ''}`)] });
  },
};
