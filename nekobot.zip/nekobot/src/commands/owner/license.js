'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { LicenseSystem } = require('../../systems/LicenseSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'owner',
  ownerOnly: true,
  cooldown: 0,
  data: new SlashCommandBuilder()
    .setName('license')
    .setDescription('[OWNER] Manage bot licenses')
    .addSubcommand(s => s.setName('generate').setDescription('Generate a new license key')
      .addStringOption(o => o.setName('type').setDescription('License type').setRequired(true).addChoices({ name: 'Trial', value: 'trial' }, { name: 'Standard', value: 'standard' }, { name: 'Lifetime', value: 'lifetime' }))
      .addIntegerOption(o => o.setName('duration').setDescription('Duration in days').setMinValue(1).setRequired(false)))
    .addSubcommand(s => s.setName('verify').setDescription('Verify a license key').addStringOption(o => o.setName('key').setDescription('License key').setRequired(true)))
    .addSubcommand(s => s.setName('revoke').setDescription('Revoke a license key').addStringOption(o => o.setName('key').setDescription('License key').setRequired(true)))
    .addSubcommand(s => s.setName('list').setDescription('List all licenses')),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply({ ephemeral: true });
    const ls = new LicenseSystem(client);

    switch (sub) {
      case 'generate': {
        const type = interaction.options.getString('type');
        const duration = interaction.options.getInteger('duration') || (type === 'trial' ? 7 : type === 'lifetime' ? 0 : 30);
        const key = await ls.generate(type, duration, interaction.user.id);
        await interaction.editReply({ embeds: [Embed.success('License Generated', `**Type:** ${type}\n**Duration:** ${duration === 0 ? 'Lifetime' : duration + ' days'}\n\n\`\`\`\n${key}\n\`\`\``)] });
        break;
      }
      case 'verify': {
        const key = interaction.options.getString('key');
        const info = await ls.verify(key);
        if (!info) return interaction.editReply({ embeds: [Embed.error('Invalid', 'License key not found.')] });
        await interaction.editReply({ embeds: [Embed.info('License Info').addFields({ name: 'Type', value: info.type, inline: true }, { name: 'Status', value: info.active ? '✅ Active' : '❌ Expired/Revoked', inline: true }, { name: 'Expires', value: info.duration === 0 ? 'Lifetime' : `<t:${Math.floor(info.expiresAt / 1000)}:R>`, inline: true })] });
        break;
      }
      case 'revoke': {
        await ls.revoke(interaction.options.getString('key'));
        await interaction.editReply({ embeds: [Embed.success('Revoked', 'License key revoked.')] });
        break;
      }
      case 'list': {
        const list = await ls.list();
        const desc = list.slice(0, 20).map(l => `\`${l.key}\` — ${l.type} — ${l.active ? '✅' : '❌'}`).join('\n');
        await interaction.editReply({ embeds: [Embed.info(`Licenses (${list.length})`).setDescription(desc || 'None')] });
        break;
      }
    }
  },
};
