'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'owner',
  ownerOnly: true,
  cooldown: 0,
  data: new SlashCommandBuilder()
    .setName('blacklist')
    .setDescription('[OWNER] Blacklist a user or guild from using the bot')
    .addSubcommand(s => s.setName('add').setDescription('Blacklist a user or guild')
      .addStringOption(o => o.setName('type').setDescription('Type').setRequired(true).addChoices({ name: 'User', value: 'user' }, { name: 'Guild', value: 'guild' }))
      .addStringOption(o => o.setName('id').setDescription('User or Guild ID').setRequired(true))
      .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(false)))
    .addSubcommand(s => s.setName('remove').setDescription('Remove from blacklist')
      .addStringOption(o => o.setName('id').setDescription('ID to remove').setRequired(true)))
    .addSubcommand(s => s.setName('list').setDescription('View all blacklisted IDs')),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply({ ephemeral: true });
    const data = client.db.global.get('blacklist') || { users: {}, guilds: {} };

    switch (sub) {
      case 'add': {
        const type = interaction.options.getString('type');
        const id = interaction.options.getString('id');
        const reason = interaction.options.getString('reason') || 'No reason provided';
        data[type === 'user' ? 'users' : 'guilds'][id] = { reason, addedAt: Date.now(), addedBy: interaction.user.id };
        client.db.global.set('blacklist', data);
        if (type === 'guild') { try { await client.guilds.cache.get(id)?.leave(); } catch {} }
        await interaction.editReply({ embeds: [Embed.success('Blacklisted', `${type === 'user' ? 'User' : 'Guild'} \`${id}\` blacklisted.\n**Reason:** ${reason}`)] });
        break;
      }
      case 'remove': {
        const id = interaction.options.getString('id');
        delete data.users[id]; delete data.guilds[id];
        client.db.global.set('blacklist', data);
        await interaction.editReply({ embeds: [Embed.success('Removed', `\`${id}\` removed from blacklist.`)] });
        break;
      }
      case 'list': {
        const users = Object.entries(data.users).map(([id, v]) => `User \`${id}\` — ${v.reason}`);
        const guilds = Object.entries(data.guilds).map(([id, v]) => `Guild \`${id}\` — ${v.reason}`);
        const all = [...users, ...guilds];
        await interaction.editReply({ embeds: [Embed.info(`Blacklist (${all.length})`).setDescription(all.join('\n') || 'Empty')] });
        break;
      }
    }
  },
};
