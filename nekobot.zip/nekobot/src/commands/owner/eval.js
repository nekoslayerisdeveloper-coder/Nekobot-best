'use strict';

const { SlashCommandBuilder, codeBlock } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'owner',
  ownerOnly: true,
  cooldown: 0,
  data: new SlashCommandBuilder()
    .setName('eval')
    .setDescription('[OWNER] Evaluate JavaScript code')
    .addStringOption(o => o.setName('code').setDescription('Code to evaluate').setRequired(true))
    .addBooleanOption(o => o.setName('async').setDescription('Wrap in async function?').setRequired(false))
    .addBooleanOption(o => o.setName('silent').setDescription('Silent output?').setRequired(false)),

  async execute(interaction, client) {
    const code = interaction.options.getString('code');
    const useAsync = interaction.options.getBoolean('async') ?? true;
    const silent = interaction.options.getBoolean('silent') ?? false;
    await interaction.deferReply({ ephemeral: true });

    const wrappedCode = useAsync ? `(async () => { ${code} })()` : code;
    let output, type, success;
    const start = Date.now();

    try {
      let result = eval(wrappedCode);
      if (result instanceof Promise) result = await result;
      output = typeof result === 'object' ? JSON.stringify(result, null, 2) : String(result);
      type = typeof result;
      success = true;
    } catch (e) {
      output = e.stack || e.message;
      type = 'error';
      success = false;
    }

    const elapsed = Date.now() - start;
    if (output.length > 3000) output = output.slice(0, 3000) + '\n... (truncated)';

    if (silent && success) return interaction.editReply({ embeds: [Embed.success('Eval', 'Code executed silently.')] });

    await interaction.editReply({
      embeds: [(success ? Embed.success : Embed.error)(`${success ? '✅' : '❌'} Eval`, ' ')
        .addFields(
          { name: '📥 Input', value: codeBlock('js', code.slice(0, 1000)), inline: false },
          { name: '📤 Output', value: codeBlock(type === 'error' ? 'bash' : 'js', output), inline: false },
          { name: 'Type', value: type, inline: true },
          { name: 'Time', value: `${elapsed}ms`, inline: true },
        )
      ],
    });
  },
};
