'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'owner',
  ownerOnly: true,
  cooldown: 0,
  data: new SlashCommandBuilder()
    .setName('announce')
    .setDescription('[OWNER] Send a global announcement to all servers')
    .addStringOption(o => o.setName('message').setDescription('Announcement message').setRequired(true))
    .addStringOption(o => o.setName('type').setDescription('Announcement type').setRequired(false)
      .addChoices({ name: 'Info', value: 'info' }, { name: 'Warning', value: 'warning' }, { name: 'Update', value: 'update' })),

  async execute(interaction, client) {
    const message = interaction.options.getString('message');
    const type = interaction.options.getString('type') || 'info';
    await interaction.deferReply({ ephemeral: true });

    const color = { info: 0x3498DB, warning: 0xF39C12, update: 0x2ECC71 }[type];
    const emoji = { info: '📢', warning: '⚠️', update: '🆕' }[type];

    const embed = Embed.info(`${emoji} NekoBot Announcement`)
      .setDescription(message)
      .setColor(color)
      .setTimestamp()
      .setFooter({ text: 'NekoBot | Global Announcement' });

    let success = 0, failed = 0;
    for (const guild of client.guilds.cache.values()) {
      const systemChannel = guild.systemChannel || guild.channels.cache
        .filter(c => c.type === 0 && c.permissionsFor(guild.members.me).has('SendMessages'))
        .sort((a, b) => a.position - b.position)
        .first();
      if (systemChannel) {
        try { await systemChannel.send({ embeds: [embed] }); success++; } catch { failed++; }
      } else { failed++; }
    }

    await interaction.editReply({ embeds: [Embed.success('Announcement Sent', `✅ Sent to **${success}** servers\n❌ Failed in **${failed}** servers`)] });
  },
};
