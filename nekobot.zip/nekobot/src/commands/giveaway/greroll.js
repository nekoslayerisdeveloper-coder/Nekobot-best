'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { GiveawaySystem } = require('../../systems/GiveawaySystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'giveaway',
  permissions: ['ManageGuild'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('greroll')
    .setDescription('Reroll a giveaway winner')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption(o => o.setName('message_id').setDescription('Message ID of the giveaway').setRequired(true))
    .addIntegerOption(o => o.setName('count').setDescription('Number of new winners').setMinValue(1).setMaxValue(20).setRequired(false)),

  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });
    const messageId = interaction.options.getString('message_id');
    const count = interaction.options.getInteger('count') || 1;
    try {
      const gs = new GiveawaySystem(client);
      const newWinners = await gs.rerollGiveaway(messageId, interaction.guild.id, count);
      const winText = newWinners.length > 0 ? newWinners.map(w => `<@${w}>`).join(', ') : 'No eligible entries';
      await interaction.editReply({ embeds: [Embed.success('Giveaway Rerolled', `New winner(s): ${winText}`)] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Reroll Error', e.message)] });
    }
  },
};
