'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { GiveawaySystem } = require('../../systems/GiveawaySystem');
const { Embed } = require('../../utils/embed');
const { parseMs } = require('../../utils/ms');

module.exports = {
  category: 'giveaway',
  permissions: ['ManageGuild'],
  cooldown: 10,
  data: new SlashCommandBuilder()
    .setName('gcreate')
    .setDescription('Create a giveaway')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption(o => o.setName('duration').setDescription('Duration (e.g. 1h, 30m, 1d)').setRequired(true))
    .addIntegerOption(o => o.setName('winners').setDescription('Number of winners').setMinValue(1).setMaxValue(20).setRequired(true))
    .addStringOption(o => o.setName('prize').setDescription('Prize to give away').setRequired(true))
    .addChannelOption(o => o.setName('channel').setDescription('Channel to host giveaway').setRequired(false))
    .addRoleOption(o => o.setName('required_role').setDescription('Required role to enter').setRequired(false)),

  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });
    const durationStr = interaction.options.getString('duration');
    const duration = parseMs(durationStr);
    if (!duration || duration < 10000) return interaction.editReply({ embeds: [Embed.error('Invalid Duration', 'Duration must be at least 10 seconds.')] });
    const winners = interaction.options.getInteger('winners');
    const prize = interaction.options.getString('prize');
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    const requiredRole = interaction.options.getRole('required_role');

    try {
      const gs = new GiveawaySystem(client);
      await gs.create({
        channelId: channel.id,
        guildId: interaction.guild.id,
        hostId: interaction.user.id,
        prize,
        winnerCount: winners,
        duration,
        requirements: requiredRole ? { roleId: requiredRole.id } : {},
      });
      await interaction.editReply({ embeds: [Embed.success('Giveaway Created', `Giveaway for **${prize}** started in ${channel}!`)] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Giveaway Error', e.message)] });
    }
  },
};
