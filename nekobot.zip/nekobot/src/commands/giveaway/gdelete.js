'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { GiveawaySystem } = require('../../systems/GiveawaySystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'giveaway',
  permissions: ['ManageGuild'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('gdelete')
    .setDescription('Delete a giveaway')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption(o => o.setName('message_id').setDescription('Message ID of the giveaway').setRequired(true)),

  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });
    const messageId = interaction.options.getString('message_id');
    try {
      const gs = new GiveawaySystem(client);
      await gs.delete(messageId, interaction.guild.id);
      await interaction.editReply({ embeds: [Embed.success('Giveaway Deleted', 'The giveaway has been deleted.')] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Delete Error', e.message)] });
    }
  },
};
