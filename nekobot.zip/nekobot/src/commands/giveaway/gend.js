'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { GiveawaySystem } = require('../../systems/GiveawaySystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'giveaway',
  permissions: ['ManageGuild'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('gend')
    .setDescription('End a giveaway early')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption(o => o.setName('message_id').setDescription('Message ID of the giveaway').setRequired(true)),

  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });
    const messageId = interaction.options.getString('message_id');
    try {
      const gs = new GiveawaySystem(client);
      const key = `${interaction.guild.id}:${messageId}`;
      const g = client.db.giveaways.get(key);
      if (!g) return interaction.editReply({ embeds: [Embed.error('Not Found', 'Giveaway not found.')] });
      await gs.endGiveaway(messageId, g.channelId, interaction.guild.id);
      await interaction.editReply({ embeds: [Embed.success('Giveaway Ended', 'The giveaway has been ended and winners selected.')] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('End Error', e.message)] });
    }
  },
};
