'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { GiveawaySystem } = require('../../systems/GiveawaySystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'giveaway',
  permissions: ['ManageGuild'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('glist')
    .setDescription('List all active giveaways')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction, client) {
    await interaction.deferReply();
    const gs = new GiveawaySystem(client);
    const all = gs.list(interaction.guild.id);
    const active = all.filter(g => !g.ended);
    if (!active.length) return interaction.editReply({ embeds: [Embed.info('Giveaways', 'No active giveaways.')] });
    const desc = active.map(g =>
      `**${g.prize}** — ${g.winnerCount} winner(s) — Ends <t:${Math.floor(g.endsAt / 1000)}:R>\n> [Jump](https://discord.com/channels/${interaction.guild.id}/${g.channelId}/${g.messageId})`
    ).join('\n\n');
    await interaction.editReply({ embeds: [Embed.info(`🎉 Active Giveaways (${active.length})`).setDescription(desc)] });
  },
};
