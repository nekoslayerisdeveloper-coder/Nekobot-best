'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'utility',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('tag')
    .setDescription('Create and manage text tags/snippets')
    .addSubcommand(s => s.setName('get').setDescription('Get a tag').addStringOption(o => o.setName('name').setDescription('Tag name').setRequired(true)))
    .addSubcommand(s => s.setName('create').setDescription('Create a tag').setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages).addStringOption(o => o.setName('name').setDescription('Tag name').setRequired(true)).addStringOption(o => o.setName('content').setDescription('Tag content').setRequired(true)))
    .addSubcommand(s => s.setName('delete').setDescription('Delete a tag').setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages).addStringOption(o => o.setName('name').setDescription('Tag name').setRequired(true)))
    .addSubcommand(s => s.setName('list').setDescription('List all tags')),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const guildData = client.db.guild.get(guildId) || {};
    const tags = guildData.tags || {};

    switch (sub) {
      case 'get': {
        const name = interaction.options.getString('name').toLowerCase();
        if (!tags[name]) return interaction.reply({ embeds: [Embed.error('Not Found', `Tag \`${name}\` not found.`)], ephemeral: true });
        await interaction.reply({ embeds: [Embed.primary(`🏷️ ${name}`).setDescription(tags[name].content)] });
        break;
      }
      case 'create': {
        const name = interaction.options.getString('name').toLowerCase();
        const content = interaction.options.getString('content');
        if (tags[name]) return interaction.reply({ embeds: [Embed.error('Already Exists', `Tag \`${name}\` already exists. Delete it first.`)], ephemeral: true });
        tags[name] = { content, author: interaction.user.id, createdAt: Date.now() };
        guildData.tags = tags;
        client.db.guild.set(guildId, guildData);
        await interaction.reply({ embeds: [Embed.success('Tag Created', `Tag \`${name}\` created successfully.`)] });
        break;
      }
      case 'delete': {
        const name = interaction.options.getString('name').toLowerCase();
        if (!tags[name]) return interaction.reply({ embeds: [Embed.error('Not Found', `Tag \`${name}\` not found.`)], ephemeral: true });
        delete tags[name];
        guildData.tags = tags;
        client.db.guild.set(guildId, guildData);
        await interaction.reply({ embeds: [Embed.success('Tag Deleted', `Tag \`${name}\` deleted.`)] });
        break;
      }
      case 'list': {
        const list = Object.keys(tags);
        if (!list.length) return interaction.reply({ embeds: [Embed.info('Tags', 'No tags created yet.')] });
        await interaction.reply({ embeds: [Embed.primary('🏷️ Server Tags').setDescription(list.map(t => `\`${t}\``).join(', '))] });
        break;
      }
    }
  },
};
