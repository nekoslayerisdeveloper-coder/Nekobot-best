'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { BirthdaySystem } = require('../../systems/BirthdaySystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'utility',
  cooldown: 10,
  data: new SlashCommandBuilder()
    .setName('birthday')
    .setDescription('Set and view birthdays')
    .addSubcommand(s => s.setName('set').setDescription('Set your birthday').addStringOption(o => o.setName('date').setDescription('Your birthday (YYYY-MM-DD)').setRequired(true)))
    .addSubcommand(s => s.setName('check').setDescription('Check a user\'s birthday').addUserOption(o => o.setName('user').setDescription('User to check').setRequired(false)))
    .addSubcommand(s => s.setName('upcoming').setDescription('View upcoming birthdays (next 7 days)'))
    .addSubcommand(s => s.setName('channel').setDescription('Set birthday announcement channel').setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild).addChannelOption(o => o.setName('channel').setDescription('Channel').setRequired(true))),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const bs = new BirthdaySystem(client);

    switch (sub) {
      case 'set': {
        const date = interaction.options.getString('date');
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || isNaN(new Date(date))) return interaction.reply({ embeds: [Embed.error('Invalid Date', 'Use format YYYY-MM-DD (e.g. 1999-03-15)')], ephemeral: true });
        await bs.setBirthday(interaction.guild.id, interaction.user.id, date);
        await interaction.reply({ embeds: [Embed.success('Birthday Set!', `Your birthday has been set to **${date}**! 🎂`)], ephemeral: true });
        break;
      }
      case 'check': {
        const target = interaction.options.getUser('user') || interaction.user;
        const bd = await bs.getBirthday(interaction.guild.id, target.id);
        if (!bd) return interaction.reply({ embeds: [Embed.info('No Birthday', `${target.username} hasn't set their birthday yet.`)] });
        const [, month, day] = bd.date.split('-');
        const next = new Date(`${new Date().getFullYear()}-${month}-${day}`);
        if (next < new Date()) next.setFullYear(next.getFullYear() + 1);
        await interaction.reply({ embeds: [Embed.info(`🎂 ${target.username}'s Birthday`).addFields({ name: 'Date', value: bd.date, inline: true }, { name: 'Next Birthday', value: `<t:${Math.floor(next / 1000)}:R>`, inline: true })] });
        break;
      }
      case 'upcoming': {
        await interaction.deferReply();
        const list = await bs.getUpcoming(interaction.guild.id, 7);
        if (!list.length) return interaction.editReply({ embeds: [Embed.info('Upcoming Birthdays', 'No birthdays in the next 7 days.')] });
        const desc = list.map(e => `<@${e.userId}> — **${e.date}** (in **${e.daysUntil}** day${e.daysUntil !== 1 ? 's' : ''})`).join('\n');
        await interaction.editReply({ embeds: [Embed.info('🎂 Upcoming Birthdays (7 days)').setDescription(desc)] });
        break;
      }
      case 'channel': {
        const channel = interaction.options.getChannel('channel');
        await bs.setChannel(interaction.guild.id, channel.id);
        await interaction.reply({ embeds: [Embed.success('Birthday Channel Set', `Birthday announcements will be sent in ${channel}.`)] });
        break;
      }
    }
  },
};
