'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'utility',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('View detailed info about a user')
    .addUserOption(o => o.setName('user').setDescription('User to look up').setRequired(false)),

  async execute(interaction, client) {
    const member = interaction.options.getMember('user') || interaction.member;
    const user = member.user;
    await user.fetch();
    const roles = member.roles.cache
      .filter(r => r.id !== interaction.guild.id)
      .sort((a, b) => b.position - a.position)
      .map(r => r.toString())
      .slice(0, 10);

    const flags = user.flags?.toArray() || [];
    const badges = flags.map(f => {
      const map = { Staff: '👨‍💼', Partner: '🤝', Hypesquad: '🏅', BugHunterLevel1: '🐛', BugHunterLevel2: '🐛', HypeSquadOnlineHouse1: '🏠', HypeSquadOnlineHouse2: '🏠', HypeSquadOnlineHouse3: '🏠', PremiumEarlySupporter: '⭐', ActiveDeveloper: '🔨', CertifiedModerator: '🛡️' };
      return map[f] || f;
    }).join(' ') || 'None';

    await interaction.reply({
      embeds: [Embed.info(`👤 ${user.username}`)
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '🆔 ID', value: user.id, inline: true },
          { name: '📛 Username', value: user.tag, inline: true },
          { name: '🤖 Bot', value: user.bot ? 'Yes' : 'No', inline: true },
          { name: '📅 Account Created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },
          { name: '📥 Joined Server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
          { name: '🚀 Boosting', value: member.premiumSince ? `<t:${Math.floor(member.premiumSinceTimestamp / 1000)}:R>` : 'No', inline: true },
          { name: '🎭 Roles', value: roles.join(', ') || 'None', inline: false },
          { name: '🏅 Badges', value: badges, inline: false },
          { name: '💬 Nickname', value: member.nickname || 'None', inline: true },
          { name: '🔇 Timeout', value: member.isCommunicationDisabled() ? `<t:${Math.floor(member.communicationDisabledUntilTimestamp / 1000)}:R>` : 'No', inline: true },
        )
      ],
    });
  },
};
