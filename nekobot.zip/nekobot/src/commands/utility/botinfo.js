'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');
const os = require('os');

module.exports = {
  category: 'utility',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('botinfo')
    .setDescription('View detailed info about NekoBot'),

  async execute(interaction, client) {
    const memUsage = process.memoryUsage();
    const cpuUsage = os.loadavg()[0];
    const totalMem = (os.totalmem() / 1024 / 1024).toFixed(0);
    const usedMem = (memUsage.rss / 1024 / 1024).toFixed(1);
    const uptime = process.uptime();
    const d = Math.floor(uptime / 86400), h = Math.floor(uptime % 86400 / 3600), m = Math.floor(uptime % 3600 / 60);

    await interaction.reply({
      embeds: [Embed.info('🐱 NekoBot Info')
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '👤 Owner', value: 'NekoSlayer', inline: true },
          { name: '🆔 Client ID', value: client.user.id, inline: true },
          { name: '📌 Version', value: '1.0.0', inline: true },
          { name: '📦 discord.js', value: require('discord.js').version, inline: true },
          { name: '⚙️ Node.js', value: process.version, inline: true },
          { name: '🖥️ Platform', value: `${os.platform()} ${os.arch()}`, inline: true },
          { name: '⏱️ Uptime', value: `${d}d ${h}h ${m}m`, inline: true },
          { name: '💾 RAM', value: `${usedMem}MB / ${totalMem}MB`, inline: true },
          { name: '🔥 CPU Load', value: `${cpuUsage.toFixed(2)}%`, inline: true },
          { name: '🏠 Servers', value: `${client.guilds.cache.size}`, inline: true },
          { name: '👥 Users', value: `${client.guilds.cache.reduce((a, g) => a + g.memberCount, 0).toLocaleString()}`, inline: true },
          { name: '📜 Commands', value: `${client.commands.size}`, inline: true },
          { name: '📡 Ping', value: `${client.ws.ping}ms`, inline: true },
          { name: '🗃️ Cache', value: `${client.users.cache.size} users`, inline: true },
        )
      ],
    });
  },
};
