'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { SuggestionSystem } = require('../../systems/SuggestionSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'utility',
  cooldown: 30,
  data: new SlashCommandBuilder()
    .setName('suggest')
    .setDescription('Submit a suggestion')
    .addStringOption(o => o.setName('suggestion').setDescription('Your suggestion').setRequired(true).setMaxLength(1000))
    .addAttachmentOption(o => o.setName('image').setDescription('Optional supporting image').setRequired(false)),

  async execute(interaction, client) {
    const suggestion = interaction.options.getString('suggestion');
    const image = interaction.options.getAttachment('image');
    await interaction.deferReply({ ephemeral: true });
    const ss = new SuggestionSystem(client);
    try {
      await ss.submit({ guild: interaction.guild, author: interaction.member, suggestion, imageUrl: image?.url });
      await interaction.editReply({ embeds: [Embed.success('Suggestion Submitted!', 'Your suggestion has been posted in the suggestions channel.')] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Suggestion Error', e.message)] });
    }
  },
};
