'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { ReminderSystem } = require('../../systems/ReminderSystem');
const { Embed } = require('../../utils/embed');
const ms = require('../../utils/ms');

module.exports = {
  category: 'utility',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('remind')
    .setDescription('Set a reminder')
    .addSubcommand(s => s.setName('set').setDescription('Set a reminder')
      .addStringOption(o => o.setName('time').setDescription('When to remind (e.g. 10m, 1h, 2d)').setRequired(true))
      .addStringOption(o => o.setName('message').setDescription('What to remind you about').setRequired(true)))
    .addSubcommand(s => s.setName('list').setDescription('View your reminders'))
    .addSubcommand(s => s.setName('cancel').setDescription('Cancel a reminder').addStringOption(o => o.setName('id').setDescription('Reminder ID').setRequired(true))),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply({ ephemeral: true });
    const rs = new ReminderSystem(client);

    switch (sub) {
      case 'set': {
        const time = ms(interaction.options.getString('time'));
        if (!time || time < 10000) return interaction.editReply({ embeds: [Embed.error('Invalid Time', 'Minimum reminder time is 10 seconds.')] });
        if (time > 2592000000) return interaction.editReply({ embeds: [Embed.error('Too Long', 'Maximum reminder time is 30 days.')] });
        const message = interaction.options.getString('message');
        const id = await rs.set(interaction.user.id, interaction.channel.id, message, time);
        await interaction.editReply({ embeds: [Embed.success('Reminder Set!', `I'll remind you about: **${message}**\n⏰ <t:${Math.floor((Date.now() + time) / 1000)}:R>\n\nID: \`${id}\``)] });
        break;
      }
      case 'list': {
        const list = await rs.list(interaction.user.id);
        if (!list.length) return interaction.editReply({ embeds: [Embed.info('No Reminders', 'You have no active reminders.')] });
        const desc = list.map(r => `\`${r.id}\` — **${r.message}**\n> <t:${Math.floor(r.remindAt / 1000)}:R>`).join('\n\n');
        await interaction.editReply({ embeds: [Embed.info('⏰ Your Reminders').setDescription(desc)] });
        break;
      }
      case 'cancel': {
        const id = interaction.options.getString('id');
        await rs.cancel(interaction.user.id, id);
        await interaction.editReply({ embeds: [Embed.success('Cancelled', `Reminder \`${id}\` cancelled.`)] });
        break;
      }
    }
  },
};
