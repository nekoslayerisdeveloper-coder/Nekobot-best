'use strict';

const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'utility',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription("View a user's avatar")
    .addUserOption(o => o.setName('user').setDescription('User to get avatar of (defaults to you)').setRequired(false))
    .addStringOption(o => o.setName('type').setDescription('Avatar type').setRequired(false)
      .addChoices({ name: 'Server Avatar', value: 'guild' }, { name: 'Global Avatar', value: 'global' })),

  async execute(interaction, client) {
    const target = interaction.options.getMember('user') || interaction.member;
    const type = interaction.options.getString('type') || 'global';
    const user = target.user || target;
    const guildAvatar = target.displayAvatarURL?.({ dynamic: true, size: 4096 });
    const globalAvatar = user.displayAvatarURL({ dynamic: true, size: 4096 });
    const url = type === 'guild' && guildAvatar ? guildAvatar : globalAvatar;

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setLabel('PNG').setStyle(ButtonStyle.Link).setURL(url + '&format=png'),
      new ButtonBuilder().setLabel('JPG').setStyle(ButtonStyle.Link).setURL(url + '&format=jpg'),
      new ButtonBuilder().setLabel('WEBP').setStyle(ButtonStyle.Link).setURL(url),
    );

    await interaction.reply({
      embeds: [Embed.info(`🖼️ ${user.username}'s Avatar`).setImage(url)],
      components: [row],
    });
  },
};
