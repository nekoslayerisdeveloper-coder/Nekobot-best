'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'utility',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('View detailed information about this server'),

  async execute(interaction, client) {
    const guild = interaction.guild;
    await guild.fetch();
    const owner = await guild.fetchOwner();
    const textChannels = guild.channels.cache.filter(c => c.type === 0).size;
    const voiceChannels = guild.channels.cache.filter(c => c.type === 2).size;
    const categories = guild.channels.cache.filter(c => c.type === 4).size;
    const roles = guild.roles.cache.size - 1;
    const bots = guild.members.cache.filter(m => m.user.bot).size;
    const emojis = guild.emojis.cache.size;
    const boosts = guild.premiumSubscriptionCount || 0;
    const boostTier = guild.premiumTier;

    await interaction.reply({
      embeds: [Embed.info(`🏠 ${guild.name}`)
        .setThumbnail(guild.iconURL({ dynamic: true }))
        .setImage(guild.bannerURL({ size: 2048 }))
        .addFields(
          { name: '👑 Owner', value: `${owner.user.tag}`, inline: true },
          { name: '🆔 ID', value: guild.id, inline: true },
          { name: '📅 Created', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`, inline: true },
          { name: '👥 Members', value: `${guild.memberCount} (${bots} bots)`, inline: true },
          { name: '📊 Channels', value: `${textChannels} text, ${voiceChannels} voice, ${categories} categories`, inline: true },
          { name: '🎭 Roles', value: `${roles}`, inline: true },
          { name: '😀 Emojis', value: `${emojis}`, inline: true },
          { name: '🚀 Boosts', value: `${boosts} (Tier ${boostTier})`, inline: true },
          { name: '🔒 Verification', value: `${guild.verificationLevel}`, inline: true },
          { name: '📌 Description', value: guild.description || 'No description', inline: false },
        )
        .setFooter({ text: `Shard: ${client.shard?.ids[0] || 0}` })
      ],
    });
  },
};
