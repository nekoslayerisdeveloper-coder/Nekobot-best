'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

function formatUptime(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const d = Math.floor(h / 24);
  return `${d}d ${h % 24}h ${m % 60}m ${s % 60}s`;
}

module.exports = {
  category: 'utility',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('uptime')
    .setDescription('Check how long the bot has been online'),

  async execute(interaction, client) {
    const uptime = client.uptime;
    await interaction.reply({
      embeds: [Embed.info('⏱️ Uptime')
        .addFields(
          { name: 'Uptime', value: formatUptime(uptime), inline: true },
          { name: 'Online Since', value: `<t:${Math.floor((Date.now() - uptime) / 1000)}:F>`, inline: true },
          { name: 'Servers', value: `${client.guilds.cache.size}`, inline: true },
          { name: 'Users', value: `${client.guilds.cache.reduce((a, g) => a + g.memberCount, 0).toLocaleString()}`, inline: true },
          { name: 'Commands', value: `${client.commands.size}`, inline: true },
        )
      ],
    });
  },
};
