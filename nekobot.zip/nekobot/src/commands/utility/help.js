'use strict';

const { SlashCommandBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

const CATEGORIES = {
  moderation: { emoji: '🔨', label: 'Moderation', desc: 'Server moderation tools' },
  economy: { emoji: '💰', label: 'Economy', desc: 'Currency and economy commands' },
  leveling: { emoji: '⭐', label: 'Leveling', desc: 'XP and rank commands' },
  music: { emoji: '🎵', label: 'Music', desc: 'Music player commands' },
  ai: { emoji: '🤖', label: 'AI', desc: 'AI-powered commands' },
  tickets: { emoji: '🎫', label: 'Tickets', desc: 'Support ticket system' },
  giveaway: { emoji: '🎉', label: 'Giveaways', desc: 'Giveaway management' },
  verification: { emoji: '✅', label: 'Verification', desc: 'User verification' },
  utility: { emoji: '🛠️', label: 'Utility', desc: 'General utility commands' },
  admin: { emoji: '⚙️', label: 'Admin', desc: 'Server administration' },
  premium: { emoji: '💎', label: 'Premium', desc: 'Premium features' },
};

module.exports = {
  category: 'utility',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('View all commands and help')
    .addStringOption(o => o.setName('command').setDescription('Get help for a specific command').setRequired(false)),

  async execute(interaction, client) {
    const specificCmd = interaction.options.getString('command');

    if (specificCmd) {
      const cmd = client.commands.get(specificCmd);
      if (!cmd) return interaction.reply({ embeds: [Embed.error('Not Found', `No command named \`${specificCmd}\` found.`)], ephemeral: true });
      const embed = Embed.info(`Help — /${cmd.data.name}`)
        .setDescription(cmd.data.description)
        .addFields(
          { name: 'Category', value: CATEGORIES[cmd.category]?.label || cmd.category, inline: true },
          { name: 'Cooldown', value: `${cmd.cooldown || 3}s`, inline: true },
          { name: 'Premium', value: cmd.premium ? '✅ Yes' : '❌ No', inline: true },
          { name: 'Permissions', value: (cmd.permissions || []).join(', ') || 'None', inline: true },
        );
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const embed = Embed.info('🐱 NekoBot Help')
      .setDescription('Select a category below to view its commands.\n\nNekoBot is a fully-featured Discord bot with **100+ commands** across multiple categories.')
      .addFields(Object.entries(CATEGORIES).map(([key, cat]) => {
        const cmds = [...client.commands.values()].filter(c => c.category === key);
        return { name: `${cat.emoji} ${cat.label}`, value: `${cmds.length} commands — ${cat.desc}`, inline: true };
      }));

    const menu = new StringSelectMenuBuilder()
      .setCustomId('help_category')
      .setPlaceholder('Select a category...')
      .addOptions(Object.entries(CATEGORIES).map(([key, cat]) => ({
        label: cat.label, description: cat.desc, value: key, emoji: cat.emoji,
      })));

    await interaction.reply({
      embeds: [embed],
      components: [new ActionRowBuilder().addComponents(menu)],
      ephemeral: true,
    });
  },
};
