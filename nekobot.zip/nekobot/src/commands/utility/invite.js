'use strict';

const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'utility',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('invite')
    .setDescription('Get the bot invite link'),

  async execute(interaction, client) {
    const inviteUrl = `https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`;
    const supportUrl = 'https://discord.gg/nekobot';
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setLabel('Invite NekoBot').setStyle(ButtonStyle.Link).setURL(inviteUrl).setEmoji('🐱'),
      new ButtonBuilder().setLabel('Support Server').setStyle(ButtonStyle.Link).setURL(supportUrl).setEmoji('💬'),
    );
    await interaction.reply({
      embeds: [Embed.info('🐱 Invite NekoBot').setDescription('Click the buttons below to invite NekoBot or join the support server.')],
      components: [row],
      ephemeral: true,
    });
  },
};
