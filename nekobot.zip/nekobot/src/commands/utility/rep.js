'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { ReputationSystem } = require('../../systems/ReputationSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'utility',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('rep')
    .setDescription('Give reputation to a user or check rep')
    .addSubcommand(s => s.setName('give').setDescription('Give +1 rep to a user (12h cooldown)').addUserOption(o => o.setName('user').setDescription('User to give rep').setRequired(true)))
    .addSubcommand(s => s.setName('check').setDescription("Check a user's rep").addUserOption(o => o.setName('user').setDescription('User to check').setRequired(false)))
    .addSubcommand(s => s.setName('leaderboard').setDescription('View the rep leaderboard')),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const rs = new ReputationSystem(client);

    switch (sub) {
      case 'give': {
        const target = interaction.options.getUser('user');
        try {
          const newRep = await rs.giveRep(interaction.user.id, target.id, interaction.guild.id);
          await interaction.reply({ embeds: [Embed.success('Rep Given!', `You gave +1 rep to **${target.username}**!\nThey now have **${newRep}** rep. ⭐`)] });
        } catch (e) {
          await interaction.reply({ embeds: [Embed.error('Cannot Give Rep', e.message)], ephemeral: true });
        }
        break;
      }
      case 'check': {
        const target = interaction.options.getUser('user') || interaction.user;
        const rep = rs.getReputation(target.id, interaction.guild.id);
        await interaction.reply({ embeds: [Embed.info(`⭐ ${target.username}'s Rep`).setThumbnail(target.displayAvatarURL({ dynamic: true })).addFields({ name: 'Reputation', value: `**${rep}** ⭐`, inline: true })] });
        break;
      }
      case 'leaderboard': {
        const lb = rs.getLeaderboard(interaction.guild.id, 10);
        if (!lb.length) return interaction.reply({ embeds: [Embed.info('Rep Leaderboard', 'No reputation data yet!')] });
        const list = lb.map((e, i) => `${i + 1}. <@${e.userId}> — **${e.rep}** ⭐`).join('\n');
        await interaction.reply({ embeds: [Embed.info('⭐ Rep Leaderboard').setDescription(list)] });
        break;
      }
    }
  },
};
