'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'utility',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('translate')
    .setDescription('Translate text using LibreTranslate')
    .addStringOption(o => o.setName('text').setDescription('Text to translate').setRequired(true))
    .addStringOption(o => o.setName('to').setDescription('Target language code (e.g. es, fr, de, ja)').setRequired(true))
    .addStringOption(o => o.setName('from').setDescription('Source language code (default: auto)').setRequired(false)),

  async execute(interaction, client) {
    await interaction.deferReply();
    const text = interaction.options.getString('text');
    const to = interaction.options.getString('to').toLowerCase();
    const from = interaction.options.getString('from')?.toLowerCase() || 'auto';

    try {
      const axios = require('axios');
      const resp = await axios.post('https://translate.argosopentech.com/translate', { q: text, source: from, target: to, format: 'text' }, { timeout: 10000 });
      const translated = resp.data?.translatedText;
      if (!translated) throw new Error('No translation returned');
      await interaction.editReply({ embeds: [Embed.info('🌐 Translation').addFields({ name: `Source (${from})`, value: text.slice(0, 512) }, { name: `Translation (${to})`, value: translated.slice(0, 512) })] });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Translation Failed', `Could not translate: ${e.message}`)] });
    }
  },
};
