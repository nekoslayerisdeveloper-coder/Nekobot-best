'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

function safeMath(expr) {
  const safe = expr.replace(/[^0-9+\-*/().\s%]/g, '');
  if (!safe.trim()) throw new Error('Empty expression');
  return Function(`'use strict'; return (${safe})`)();
}

module.exports = {
  category: 'utility',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('math')
    .setDescription('Evaluate a mathematical expression')
    .addStringOption(o => o.setName('expression').setDescription('Expression (e.g. 2+2, 10*5, (3+7)/2)').setRequired(true)),

  async execute(interaction) {
    const expression = interaction.options.getString('expression');
    try {
      const result = safeMath(expression);
      if (!isFinite(result)) throw new Error('Result is not finite');
      await interaction.reply({ embeds: [Embed.success('Calculator', `**Expression:** \`${expression}\`\n**Result:** \`${result}\``)] });
    } catch {
      await interaction.reply({ embeds: [Embed.error('Invalid Expression', `Could not evaluate: \`${expression}\``)], ephemeral: true });
    }
  },
};
