'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

const RESPONSES = [
  { text: 'It is certain.', type: 'positive' },
  { text: 'Without a doubt.', type: 'positive' },
  { text: 'Yes, definitely.', type: 'positive' },
  { text: 'You may rely on it.', type: 'positive' },
  { text: 'Most likely.', type: 'positive' },
  { text: 'Outlook good.', type: 'positive' },
  { text: 'Yes.', type: 'positive' },
  { text: 'Signs point to yes.', type: 'positive' },
  { text: 'Reply hazy, try again.', type: 'neutral' },
  { text: 'Ask again later.', type: 'neutral' },
  { text: 'Better not tell you now.', type: 'neutral' },
  { text: 'Cannot predict now.', type: 'neutral' },
  { text: 'Concentrate and ask again.', type: 'neutral' },
  { text: "Don't count on it.", type: 'negative' },
  { text: 'My reply is no.', type: 'negative' },
  { text: 'My sources say no.', type: 'negative' },
  { text: 'Outlook not so good.', type: 'negative' },
  { text: 'Very doubtful.', type: 'negative' },
];

module.exports = {
  category: 'utility',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('8ball')
    .setDescription('Ask the magic 8-ball a question')
    .addStringOption(o => o.setName('question').setDescription('Your question').setRequired(true)),

  async execute(interaction) {
    const question = interaction.options.getString('question');
    const response = RESPONSES[Math.floor(Math.random() * RESPONSES.length)];
    const color = response.type === 'positive' ? 0x2ECC71 : response.type === 'negative' ? 0xE74C3C : 0xF39C12;
    const emoji = response.type === 'positive' ? '✅' : response.type === 'negative' ? '❌' : '🔮';
    await interaction.reply({
      embeds: [Embed.custom(color, '🎱 Magic 8-Ball', null)
        .addFields({ name: '❓ Question', value: question }, { name: `${emoji} Answer`, value: `**${response.text}**` })
      ],
    });
  },
};
