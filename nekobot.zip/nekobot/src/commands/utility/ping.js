'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'utility',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Check the bot\'s latency'),

  async execute(interaction, client) {
    const sent = await interaction.reply({ embeds: [Embed.info('🏓 Pinging...')], fetchReply: true });
    const roundtrip = sent.createdTimestamp - interaction.createdTimestamp;
    const wsLatency = client.ws.ping;
    await interaction.editReply({
      embeds: [Embed.info('🏓 Pong!')
        .addFields(
          { name: '📡 API Latency', value: `\`${roundtrip}ms\``, inline: true },
          { name: '💓 WebSocket Ping', value: `\`${wsLatency}ms\``, inline: true },
          { name: '⚡ Status', value: wsLatency < 100 ? '🟢 Excellent' : wsLatency < 200 ? '🟡 Good' : '🔴 Poor', inline: true },
        )
      ],
    });
  },
};
