'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'utility',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('choose')
    .setDescription('Choose between multiple options')
    .addStringOption(o => o.setName('options').setDescription('Options separated by commas (e.g. pizza, sushi, tacos)').setRequired(true)),

  async execute(interaction) {
    const input = interaction.options.getString('options');
    const choices = input.split(',').map(s => s.trim()).filter(Boolean);
    if (choices.length < 2) return interaction.reply({ embeds: [Embed.error('Too Few Options', 'Please provide at least 2 options separated by commas.')], ephemeral: true });
    const chosen = choices[Math.floor(Math.random() * choices.length)];
    await interaction.reply({
      embeds: [Embed.primary('🎲 I choose...')
        .addFields({ name: 'Options', value: choices.map((c, i) => `${i + 1}. ${c}`).join('\n') }, { name: '✨ My Choice', value: `**${chosen}**` })
      ],
    });
  },
};
