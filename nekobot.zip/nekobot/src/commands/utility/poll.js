'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { PollSystem } = require('../../systems/PollSystem');
const { Embed } = require('../../utils/embed');
const ms = require('../../utils/ms');

module.exports = {
  category: 'utility',
  cooldown: 15,
  data: new SlashCommandBuilder()
    .setName('poll')
    .setDescription('Create a poll')
    .addStringOption(o => o.setName('question').setDescription('Poll question').setRequired(true))
    .addStringOption(o => o.setName('options').setDescription('Options separated by | (e.g. Yes|No|Maybe)').setRequired(true))
    .addStringOption(o => o.setName('duration').setDescription('Poll duration (e.g. 1h, 30m)').setRequired(false))
    .addBooleanOption(o => o.setName('anonymous').setDescription('Hide who voted').setRequired(false)),

  async execute(interaction, client) {
    const question = interaction.options.getString('question');
    const optionStr = interaction.options.getString('options');
    const durationStr = interaction.options.getString('duration');
    const anonymous = interaction.options.getBoolean('anonymous') ?? false;
    const options = optionStr.split('|').map(o => o.trim()).filter(o => o.length > 0);
    if (options.length < 2 || options.length > 10) return interaction.reply({ embeds: [Embed.error('Invalid Options', 'You need 2-10 options separated by |.')], ephemeral: true });
    const duration = durationStr ? ms(durationStr) : null;
    await interaction.deferReply();
    const ps = new PollSystem(client);
    await ps.create({ channel: interaction.channel, author: interaction.user, question, options, duration, anonymous });
    await interaction.editReply({ embeds: [Embed.success('Poll Created', `Your poll has been posted in ${interaction.channel}.`)] });
  },
};
