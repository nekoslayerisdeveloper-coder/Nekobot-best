'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { InviteTrackerSystem } = require('../../systems/InviteTrackerSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'utility',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('invites')
    .setDescription('Check invite stats for a user')
    .addUserOption(o => o.setName('user').setDescription('User to check (defaults to you)').setRequired(false)),

  async execute(interaction, client) {
    const target = interaction.options.getUser('user') || interaction.user;
    await interaction.deferReply();
    const its = new InviteTrackerSystem(client);
    const data = await its.getUserStats(target.id, interaction.guild.id);
    await interaction.editReply({
      embeds: [Embed.info(`📨 ${target.username}'s Invites`)
        .setThumbnail(target.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '✅ Total', value: `${data.total}`, inline: true },
          { name: '✔️ Regular', value: `${data.regular}`, inline: true },
          { name: '🎟️ Bonus', value: `${data.bonus}`, inline: true },
          { name: '❌ Left', value: `${data.left}`, inline: true },
          { name: '🚫 Fake', value: `${data.fake}`, inline: true },
          { name: '📊 Real', value: `${data.total - data.left - data.fake}`, inline: true },
        )
      ],
    });
  },
};
