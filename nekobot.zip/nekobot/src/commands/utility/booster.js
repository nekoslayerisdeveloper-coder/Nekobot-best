'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { BoosterSystem } = require('../../systems/BoosterSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'utility',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('booster')
    .setDescription('View booster perks and info')
    .addSubcommand(s => s.setName('info').setDescription('View booster perks'))
    .addSubcommand(s => s.setName('color').setDescription('Set a custom role color (booster perk)').addStringOption(o => o.setName('hex').setDescription('Hex color (e.g. #FF0000)').setRequired(true)))
    .addSubcommand(s => s.setName('list').setDescription('List all server boosters')),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply();
    const bs = new BoosterSystem(client);

    switch (sub) {
      case 'info': {
        const isBooster = interaction.member.premiumSince;
        await interaction.editReply({
          embeds: [Embed.info('🚀 Server Booster Perks')
            .setDescription(isBooster ? '✅ You are currently boosting this server!' : '❌ You are not currently boosting this server.')
            .addFields(
              { name: '🎨 Custom Role Color', value: 'Set a custom color for your role', inline: true },
              { name: '🏷️ Custom Role Name', value: 'Set a custom display name', inline: true },
              { name: '💎 Bonus XP', value: '2x XP multiplier', inline: true },
              { name: '💰 Daily Bonus', value: '+500 bonus coins daily', inline: true },
              { name: '🎫 Ticket Priority', value: 'Priority ticket support', inline: true },
            )
          ],
        });
        break;
      }
      case 'color': {
        const hex = interaction.options.getString('hex');
        try {
          await bs.setColor(interaction.member, interaction.guild, hex);
          await interaction.editReply({ embeds: [Embed.success('Color Set', `Your role color has been set to \`${hex}\`.`)] });
        } catch (e) {
          await interaction.editReply({ embeds: [Embed.error('Color Error', e.message)] });
        }
        break;
      }
      case 'list': {
        const boosters = interaction.guild.members.cache.filter(m => m.premiumSince);
        const list = boosters.map(m => `${m} — boosting since <t:${Math.floor(m.premiumSinceTimestamp / 1000)}:R>`).join('\n');
        await interaction.editReply({ embeds: [Embed.info(`🚀 Boosters (${boosters.size})`).setDescription(list || 'No boosters.')] });
        break;
      }
    }
  },
};
