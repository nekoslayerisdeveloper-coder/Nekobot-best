'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'utility',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('afk')
    .setDescription('Set or clear your AFK status')
    .addStringOption(o => o.setName('reason').setDescription('AFK reason').setRequired(false)),

  async execute(interaction, client) {
    const reason = interaction.options.getString('reason') || 'AFK';
    const key = `${interaction.guild.id}:${interaction.user.id}`;
    const afkData = client.db.user.get(key) || {};

    if (afkData.afk) {
      delete afkData.afk;
      client.db.user.set(key, afkData);
      return interaction.reply({ embeds: [Embed.success('AFK Removed', 'Welcome back! Your AFK status has been cleared.')], ephemeral: true });
    }

    afkData.afk = { reason, since: Date.now() };
    client.db.user.set(key, afkData);

    try {
      const nick = interaction.member.nickname || interaction.user.username;
      if (!nick.startsWith('[AFK]')) await interaction.member.setNickname(`[AFK] ${nick}`.slice(0, 32)).catch(() => {});
    } catch {}

    await interaction.reply({ embeds: [Embed.info('AFK Set', `You are now AFK: **${reason}**`)] });
  },
};
