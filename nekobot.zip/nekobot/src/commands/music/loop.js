'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { RepeatMode } = require('distube');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'music',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('loop')
    .setDescription('Set loop mode')
    .addStringOption(o => o.setName('mode').setDescription('Loop mode').setRequired(true)
      .addChoices({ name: 'Off', value: 'off' }, { name: 'Song', value: 'song' }, { name: 'Queue', value: 'queue' })),

  async execute(interaction, client) {
    const queue = client.distube.getQueue(interaction.guildId);
    if (!queue) return interaction.reply({ embeds: [Embed.error('No Music', 'Nothing is playing.')], ephemeral: true });
    const mode = interaction.options.getString('mode');
    const modeMap = { off: RepeatMode.DISABLED, song: RepeatMode.SONG, queue: RepeatMode.QUEUE };
    const labels = { off: '🔇 Loop Off', song: '🔂 Song Loop', queue: '🔁 Queue Loop' };
    queue.setRepeatMode(modeMap[mode]);
    await interaction.reply({ embeds: [Embed.music('Loop Mode', `Loop mode set to **${labels[mode]}**.`)] });
  },
};
