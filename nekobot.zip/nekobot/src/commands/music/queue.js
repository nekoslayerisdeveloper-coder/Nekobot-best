'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'music',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('queue')
    .setDescription('View the current music queue')
    .addIntegerOption(o => o.setName('page').setDescription('Page number').setMinValue(1).setRequired(false)),

  async execute(interaction, client) {
    const queue = client.distube.getQueue(interaction.guildId);
    if (!queue) return interaction.reply({ embeds: [Embed.error('No Music', 'Nothing is in the queue.')], ephemeral: true });

    const page = (interaction.options.getInteger('page') || 1) - 1;
    const perPage = 10;
    const songs = queue.songs;
    const totalPages = Math.ceil(songs.length / perPage);
    const slice = songs.slice(page * perPage, (page + 1) * perPage);

    const desc = slice.map((s, i) => {
      const num = page * perPage + i;
      const prefix = num === 0 ? '▶️' : `\`${num}.\``;
      return `${prefix} **[${s.name}](${s.url})** — \`${s.formattedDuration}\` by ${s.member}`;
    }).join('\n');

    await interaction.reply({
      embeds: [Embed.music(`🎵 Queue — Page ${page + 1}/${totalPages}`)
        .setDescription(desc)
        .addFields(
          { name: 'Duration', value: queue.formattedDuration, inline: true },
          { name: 'Songs', value: `${songs.length}`, inline: true },
          { name: 'Loop', value: queue.repeatMode === 2 ? '🔁 Queue' : queue.repeatMode === 1 ? '🔂 Song' : 'Off', inline: true },
        )
      ],
    });
  },
};
