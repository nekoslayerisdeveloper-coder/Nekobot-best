'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'music',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('stop')
    .setDescription('Stop music and clear the queue'),

  async execute(interaction, client) {
    const queue = client.distube.getQueue(interaction.guildId);
    if (!queue) return interaction.reply({ embeds: [Embed.error('No Music', 'There is nothing playing.')], ephemeral: true });
    queue.stop();
    await interaction.reply({ embeds: [Embed.music('⏹️ Stopped', 'Music stopped and queue cleared.')] });
  },
};
