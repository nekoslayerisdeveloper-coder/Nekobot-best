'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'music',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('nowplaying')
    .setDescription('Show the currently playing song'),

  async execute(interaction, client) {
    const queue = client.distube.getQueue(interaction.guildId);
    if (!queue) return interaction.reply({ embeds: [Embed.error('No Music', 'Nothing is playing.')], ephemeral: true });
    const song = queue.songs[0];
    const current = Math.floor(queue.currentTime);
    const total = song.duration;
    const barLen = 20;
    const filled = Math.round((current / total) * barLen);
    const bar = '▓'.repeat(filled) + '░'.repeat(barLen - filled);

    await interaction.reply({
      embeds: [Embed.music('🎵 Now Playing')
        .setDescription(`**[${song.name}](${song.url})**`)
        .setThumbnail(song.thumbnail)
        .addFields(
          { name: 'Duration', value: `\`${queue.formattedCurrentTime} / ${song.formattedDuration}\``, inline: true },
          { name: 'Requested by', value: `${song.member}`, inline: true },
          { name: 'Loop', value: queue.repeatMode === 2 ? '🔁 Queue' : queue.repeatMode === 1 ? '🔂 Song' : 'Off', inline: true },
          { name: 'Volume', value: `${queue.volume}%`, inline: true },
          { name: 'Progress', value: `\`[${bar}]\``, inline: false },
        )
      ],
    });
  },
};
