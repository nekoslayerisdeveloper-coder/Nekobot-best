'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'music',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('Play a song or playlist')
    .addStringOption(o => o.setName('query').setDescription('Song name or URL').setRequired(true)),

  async execute(interaction, client) {
    if (!interaction.member.voice.channel)
      return interaction.reply({ embeds: [Embed.error('Not in Voice', 'You must be in a voice channel!')], ephemeral: true });

    await interaction.deferReply();
    try {
      const queue = await client.distube.play(interaction.member.voice.channel, interaction.options.getString('query'), {
        member: interaction.member,
        textChannel: interaction.channel,
        interaction,
      });
    } catch (e) {
      await interaction.editReply({ embeds: [Embed.error('Play Failed', `${e.message}`)] });
    }
  },
};
