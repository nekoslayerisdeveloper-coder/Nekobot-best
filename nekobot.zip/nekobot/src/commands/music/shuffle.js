'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'music',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('shuffle')
    .setDescription('Shuffle the music queue'),

  async execute(interaction, client) {
    const queue = client.distube.getQueue(interaction.guildId);
    if (!queue) return interaction.reply({ embeds: [Embed.error('No Music', 'Nothing is playing.')], ephemeral: true });
    await queue.shuffle();
    await interaction.reply({ embeds: [Embed.music('🔀 Queue Shuffled', `Shuffled **${queue.songs.length}** songs.`)] });
  },
};
