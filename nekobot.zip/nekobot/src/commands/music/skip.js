'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'music',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('skip')
    .setDescription('Skip the current song'),

  async execute(interaction, client) {
    const queue = client.distube.getQueue(interaction.guildId);
    if (!queue) return interaction.reply({ embeds: [Embed.error('No Music', 'Nothing is playing.')], ephemeral: true });
    try {
      await queue.skip();
      await interaction.reply({ embeds: [Embed.music('⏭️ Skipped', 'Skipped to the next song.')] });
    } catch (e) {
      await interaction.reply({ embeds: [Embed.error('Skip Failed', e.message)] });
    }
  },
};
