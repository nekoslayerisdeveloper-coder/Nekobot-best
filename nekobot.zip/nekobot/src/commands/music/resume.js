'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'music',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('resume')
    .setDescription('Resume the paused song'),

  async execute(interaction, client) {
    const queue = client.distube.getQueue(interaction.guildId);
    if (!queue) return interaction.reply({ embeds: [Embed.error('No Music', 'Nothing is in the queue.')], ephemeral: true });
    if (!queue.paused) return interaction.reply({ embeds: [Embed.error('Not Paused', 'Music is already playing.')], ephemeral: true });
    queue.resume();
    await interaction.reply({ embeds: [Embed.music('▶️ Resumed', 'Music has been resumed.')] });
  },
};
