'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'music',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('volume')
    .setDescription('Set the music volume')
    .addIntegerOption(o => o.setName('level').setDescription('Volume 1-200').setMinValue(1).setMaxValue(200).setRequired(true)),

  async execute(interaction, client) {
    const queue = client.distube.getQueue(interaction.guildId);
    if (!queue) return interaction.reply({ embeds: [Embed.error('No Music', 'Nothing is playing.')], ephemeral: true });
    const level = interaction.options.getInteger('level');
    queue.setVolume(level);
    await interaction.reply({ embeds: [Embed.music('🔊 Volume', `Volume set to **${level}%**.`)] });
  },
};
