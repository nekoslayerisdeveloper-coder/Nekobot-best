'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'music',
  cooldown: 3,
  data: new SlashCommandBuilder()
    .setName('pause')
    .setDescription('Pause the current song'),

  async execute(interaction, client) {
    const queue = client.distube.getQueue(interaction.guildId);
    if (!queue) return interaction.reply({ embeds: [Embed.error('No Music', 'Nothing is playing.')], ephemeral: true });
    if (queue.paused) return interaction.reply({ embeds: [Embed.error('Already Paused', 'Music is already paused. Use `/resume`.')], ephemeral: true });
    queue.pause();
    await interaction.reply({ embeds: [Embed.music('⏸️ Paused', 'Music has been paused.')] });
  },
};
