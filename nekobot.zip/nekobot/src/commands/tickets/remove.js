'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'tickets',
  permissions: ['ManageChannels'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('remove')
    .setDescription('Remove a user from the current ticket')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addUserOption(o => o.setName('user').setDescription('User to remove').setRequired(true)),

  async execute(interaction, client) {
    const ticketData = client.db.tickets.get(interaction.channel.id);
    if (!ticketData) return interaction.reply({ embeds: [Embed.error('Not a Ticket', 'This is not a ticket channel.')], ephemeral: true });
    const target = interaction.options.getUser('user');
    if (target.id === ticketData.userId) return interaction.reply({ embeds: [Embed.error('Cannot Remove', 'You cannot remove the ticket owner.')], ephemeral: true });
    await interaction.channel.permissionOverwrites.edit(target.id, { ViewChannel: false });
    await interaction.reply({ embeds: [Embed.success('User Removed', `${target} has been removed from this ticket.`)] });
  },
};
