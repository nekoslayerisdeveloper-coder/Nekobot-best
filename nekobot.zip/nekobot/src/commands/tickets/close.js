'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { TicketSystem } = require('../../systems/TicketSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'tickets',
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('close')
    .setDescription('Close the current support ticket')
    .addStringOption(o => o.setName('reason').setDescription('Reason for closing').setRequired(false)),

  async execute(interaction, client) {
    const ts = new TicketSystem(client);
    const reason = interaction.options.getString('reason') || 'Resolved';
    const ticketData = client.db.tickets.get(interaction.channel.id);
    if (!ticketData || ticketData.status === 'closed') {
      return interaction.reply({ embeds: [Embed.error('Not a Ticket', 'This command can only be used in an open ticket channel.')], ephemeral: true });
    }
    if (ticketData.userId !== interaction.user.id && !interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
      return interaction.reply({ embeds: [Embed.error('Permission Denied', 'Only the ticket owner or staff can close this ticket.')], ephemeral: true });
    }
    await interaction.reply({ embeds: [Embed.info('Closing Ticket', `This ticket will be closed in 5 seconds.\n**Reason:** ${reason}`)] });
    setTimeout(async () => { await ts.closeTicket(interaction.channel.id, interaction.user.id, reason).catch(() => {}); }, 5000);
  },
};
