'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, AttachmentBuilder } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'tickets',
  permissions: ['ManageChannels'],
  cooldown: 10,
  data: new SlashCommandBuilder()
    .setName('transcript')
    .setDescription('Generate a transcript of the current ticket')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction, client) {
    const ticketData = client.db.tickets.get(interaction.channel.id);
    if (!ticketData) return interaction.reply({ embeds: [Embed.error('Not a Ticket', 'This is not a ticket channel.')], ephemeral: true });
    await interaction.deferReply({ ephemeral: true });

    const messages = await interaction.channel.messages.fetch({ limit: 100 });
    const sorted = [...messages.values()].sort((a, b) => a.createdTimestamp - b.createdTimestamp);
    const lines = sorted.map(m => `[${new Date(m.createdTimestamp).toISOString()}] ${m.author.tag}: ${m.content || (m.embeds.length ? '[embed]' : '[attachment]')}`).join('\n');
    const header = `TICKET TRANSCRIPT\nTicket ID: ${interaction.channel.id}\nCreated By: ${ticketData.userId}\nGuild: ${interaction.guild.name}\nChannel: ${interaction.channel.name}\nGenerated: ${new Date().toISOString()}\n${'='.repeat(60)}\n\n`;
    const content = header + lines;
    const attachment = new AttachmentBuilder(Buffer.from(content, 'utf-8'), { name: `transcript-${interaction.channel.name}.txt` });
    await interaction.editReply({ content: '✅ Transcript generated!', files: [attachment] });
  },
};
