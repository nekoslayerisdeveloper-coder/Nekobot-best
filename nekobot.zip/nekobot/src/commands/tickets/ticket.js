'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { TicketSystem } = require('../../systems/TicketSystem');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'tickets',
  cooldown: 30,
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Ticket management')
    .addSubcommand(s => s.setName('create').setDescription('Create a new support ticket').addStringOption(o => o.setName('reason').setDescription('Reason for ticket').setRequired(false)))
    .addSubcommand(s => s.setName('close').setDescription('Close the current ticket').addStringOption(o => o.setName('reason').setDescription('Close reason').setRequired(false)))
    .addSubcommand(s => s.setName('setup').setDescription('Setup the ticket panel').setDefaultMemberPermissions(PermissionFlagsBits.Administrator))
    .addSubcommand(s => s.setName('add').setDescription('Add a user to the ticket').addUserOption(o => o.setName('user').setDescription('User to add').setRequired(true)))
    .addSubcommand(s => s.setName('remove').setDescription('Remove a user from the ticket').addUserOption(o => o.setName('user').setDescription('User to remove').setRequired(true)))
    .addSubcommand(s => s.setName('transcript').setDescription('Generate a ticket transcript')),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    await interaction.deferReply({ ephemeral: sub !== 'setup' });
    const ts = new TicketSystem(client);

    switch (sub) {
      case 'create': {
        const reason = interaction.options.getString('reason') || 'No reason provided';
        try {
          const channel = await ts.createTicket(interaction.guild, interaction.member, reason);
          await interaction.editReply({ embeds: [Embed.success('Ticket Created', `Your ticket has been created: ${channel}`)] });
        } catch (e) {
          await interaction.editReply({ embeds: [Embed.error('Ticket Error', e.message)] });
        }
        break;
      }
      case 'close': {
        const reason = interaction.options.getString('reason') || 'No reason provided';
        try {
          await ts.closeTicket(interaction.channel, interaction.member, reason);
          await interaction.editReply({ embeds: [Embed.success('Ticket Closed', 'This ticket will be closed shortly.')] });
        } catch (e) {
          await interaction.editReply({ embeds: [Embed.error('Close Error', e.message)] });
        }
        break;
      }
      case 'setup': {
        try {
          await ts.setup(interaction.guild, interaction.channel);
          await interaction.editReply({ embeds: [Embed.success('Ticket Panel', 'Ticket panel has been set up in this channel.')] });
        } catch (e) {
          await interaction.editReply({ embeds: [Embed.error('Setup Error', e.message)] });
        }
        break;
      }
      case 'add': {
        const user = interaction.options.getMember('user');
        await interaction.channel.permissionOverwrites.edit(user, { ViewChannel: true, SendMessages: true });
        await interaction.editReply({ embeds: [Embed.success('User Added', `${user} has been added to this ticket.`)] });
        break;
      }
      case 'remove': {
        const user = interaction.options.getMember('user');
        await interaction.channel.permissionOverwrites.edit(user, { ViewChannel: false });
        await interaction.editReply({ embeds: [Embed.success('User Removed', `${user} has been removed from this ticket.`)] });
        break;
      }
      case 'transcript': {
        try {
          const transcript = await ts.generateTranscript(interaction.channel);
          await interaction.editReply({ embeds: [Embed.success('Transcript', 'Transcript generated and sent to your DMs.')], files: [transcript] });
        } catch (e) {
          await interaction.editReply({ embeds: [Embed.error('Transcript Error', e.message)] });
        }
        break;
      }
    }
  },
};
