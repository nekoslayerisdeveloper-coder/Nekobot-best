'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { Embed } = require('../../utils/embed');

module.exports = {
  category: 'tickets',
  permissions: ['ManageChannels'],
  cooldown: 5,
  data: new SlashCommandBuilder()
    .setName('add')
    .setDescription('Add a user to the current ticket')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addUserOption(o => o.setName('user').setDescription('User to add').setRequired(true)),

  async execute(interaction, client) {
    const ticketData = client.db.tickets.get(interaction.channel.id);
    if (!ticketData) return interaction.reply({ embeds: [Embed.error('Not a Ticket', 'This is not a ticket channel.')], ephemeral: true });
    const target = interaction.options.getUser('user');
    await interaction.channel.permissionOverwrites.edit(target.id, { ViewChannel: true, SendMessages: true });
    await interaction.reply({ embeds: [Embed.success('User Added', `${target} has been added to this ticket.`)] });
  },
};
