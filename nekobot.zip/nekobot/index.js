/**
 * NekoBot - Ultra Advanced Enterprise Discord Bot
 * Owner: NekoSlayer
 * Version: 3.0.0
 */

'use strict';

// Load environment variables
require('dotenv').config();

const chalk = require('chalk');
const figlet = require('figlet');
const { NekoClient } = require('./src/bot');
const { Logger } = require('./src/utils/logger');
const { SecuritySystem } = require('./src/systems/SecuritySystem');

// Global error handlers (Anti-Crash)
process.on('uncaughtException', (error) => {
  Logger.error('UncaughtException', error);
  SecuritySystem.handleCrash(error);
});

process.on('unhandledRejection', (reason, promise) => {
  Logger.error('UnhandledRejection', { reason, promise: promise.toString() });
  SecuritySystem.handleCrash(reason);
});

process.on('warning', (warning) => {
  Logger.warn('ProcessWarning', warning.message);
});

// Graceful shutdown
process.on('SIGINT', async () => {
  Logger.info('Shutdown', 'Received SIGINT, shutting down gracefully...');
  await client.destroy();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  Logger.info('Shutdown', 'Received SIGTERM, shutting down gracefully...');
  await client.destroy();
  process.exit(0);
});

async function bootstrap() {
  // Print banner
  console.log(chalk.magenta(figlet.textSync('NekoBot', { font: 'Big' })));
  console.log(chalk.cyan('  Ultra Advanced Enterprise Discord Bot'));
  console.log(chalk.gray('  Owner: NekoSlayer | Version: 3.0.0\n'));

  // Validate required environment variables
  const required = ['DISCORD_TOKEN', 'CLIENT_ID', 'OWNER_ID', 'DB_ENCRYPTION_KEY'];
  const missing = required.filter(k => !process.env[k]);
  if (missing.length > 0) {
    Logger.error('Bootstrap', `Missing required environment variables: ${missing.join(', ')}`);
    Logger.error('Bootstrap', 'Copy .env.example to .env and fill in the values.');
    process.exit(1);
  }

  try {
    // Initialize the bot
    const client = new NekoClient();
    global.client = client;

    await client.initialize();
    await client.login(process.env.DISCORD_TOKEN);
  } catch (error) {
    Logger.error('Bootstrap', 'Failed to start NekoBot:', error);
    process.exit(1);
  }
}

bootstrap();
